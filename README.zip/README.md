# Budget Management System — Angular + ASP.NET Core + SQL Server

A Budget / Estimation / Actual management app.

- **No authentication** — every endpoint is open, plain JSON in / JSON out.
- **API**: ASP.NET Core 8, **plain ADO.NET** (`Microsoft.Data.SqlClient`) — no Entity
  Framework, no LINQ-to-SQL. Every database call is a parameterized `SqlCommand`
  invoking a **real stored procedure** defined in `/database/03_StoredProcedures.sql`.
  There is no SQL text embedded as C# strings anywhere in this project.
- **Database**: real, standalone `.sql` script files under `/database` — table DDL,
  stored procedures, and seed data — runnable by hand in SSMS/sqlcmd, or
  automatically by the API on first startup.
- **UI**: Angular 17 (standalone components), with:
  - A product-wise **Budget grid** with search + filters (Product, Financial Year,
    Quarter, Stage)
  - A **View** button on every row: quarter-wise **Budget vs. Estimation vs. Actual**
    for that Budget Code, with a lock icon on any quarter whose Actual is booked
  - A **New Entry** modal for adding a single Budget / Estimation / Actual record
  - An **Upload Excel** modal:
    - **Download Blank Template** — an empty template to fill in a brand-new Budget
    - **Extract [Budget/Estimation] data** — pulls every existing Budget Code's
      current figures into the *same* template format, ready to edit and upload as
      Estimation or Actual (see "Extract → edit → upload" below)
    - Client-side parse + validate (SheetJS), red-highlighted error rows, then
      submit to the API, which re-validates everything server-side before saving

```
budget-management/
  database/         Real .sql scripts: schema, stored procedures, seed data
  api/               ASP.NET Core 8 Web API (source only — install .NET 8 SDK to run)
  angular-client/   Angular 17 app (install Node.js 18+ to run)
```

---

## 1. Set up SQL Server

You need SQL Server (Developer/Express edition is fine, local or remote).

**Easiest path:** do nothing — the API creates the database, tables, stored
procedures and seed data automatically on first run (see step 2). Just make sure
the connection string in `api/appsettings.json` points at your instance:

```
Server=localhost;Database=BudgetManagementDb;Trusted_Connection=True;TrustServerCertificate=True;
```

**Or run it yourself:** see `database/README.md` — run the four `.sql` files in
order with SSMS or `sqlcmd`, then set `"SkipDbInitOnStartup": true` in
`api/appsettings.json` so the API doesn't also try to run them.

## 2. Run the API

Requires the **.NET 8 SDK**.

```bash
cd api
dotnet restore
dotnet run
```

- Starts on **http://localhost:5080**. Swagger UI opens automatically at
  `http://localhost:5080/swagger` — use it to try every endpoint directly.
- On first run it creates the `BudgetManagementDb` database, runs
  `database/02_Tables.sql` and `03_StoredProcedures.sql`, then seeds sample data
  from `04_SeedData.sql` (3 sample Budget Codes across different products/stages).
- To reset all data: run `database/05_DropAll.sql`, then restart the API (or re-run
  02/03/04 by hand).
- Data access lives in `api/Data/BudgetRepository.cs` (ADO.NET calls to stored
  procedures only) and `api/Services/BudgetService.cs` (all business rules and
  validation — no SQL here at all).

## 3. Run the Angular app

Requires **Node.js 18+**.

```bash
cd angular-client
npm install
npm start
```

Opens on **http://localhost:4200**. The API base URL is set in
`src/app/services/budget.service.ts` (`API_BASE_URL`) — update it if your API runs
on a different host/port.

## 4. Try it

1. Open http://localhost:4200 — the grid loads with the 3 seeded Budget Codes.
2. Click **View** on `BUD-FY2026-00001` — quarter-wise Budget / Estimation / Actual.
   Q1 shows a 🔒 next to it because an Actual has already been booked there.
3. **+ New Entry** → **Budget**, leave Budget Code blank (auto-generated), fill in
   Product / Project / deal size / Q1–Q4 fees, save.
4. **+ New Entry** → **Estimation**, type in the Budget Code you just created,
   change a couple of numbers, save. Fields left blank are carried forward from the
   Budget automatically.
5. **Upload Excel** → **Budget** → **Download Blank Template**, fill in a few rows,
   upload, fix any red rows, Submit.
6. **Upload Excel** → **Estimation** → **Extract Budget data** — downloads an Excel
   file already filled with every Budget Code's current figures for the quarter you
   picked. Edit the numbers you want to change, then use the same file picker to
   upload it back — it submits as Estimation rows. **Upload Excel** → **Actual**
   works the same way, extracting from the latest Estimation (or Budget, if that
   quarter was never estimated).

---

## Business rules (server-side, in `api/Services/BudgetService.cs`)

- **One Budget Code = one Budget entry, ever, for its financial year.** The Budget
  is entered for exactly one quarter, chosen freely (any of Q1–Q4). A second Budget
  entry for the same code is rejected — both by the app and by a filtered unique
  index in the database (`UX_BudgetEntries_OneActiveBudgetPerCode`).
- **The first entry ever made for a Budget Code is always a Budget.** Estimation and
  Actual both require an existing Budget baseline first.
- **After the Budget, every further entry for any quarter is an Estimation** — until
  an Actual is recorded for that specific quarter, at which point that quarter's
  Estimation is **locked** (no further edits).
- **Actual sequencing:**
  - The **first** Actual ever recorded for a Budget Code may be entered **directly
    against the Budget** — no Estimation required yet.
  - **Every Actual recorded after that first one** requires an **Estimation to
    already exist for that specific quarter**. In other words: once a Budget Code
    has had its first Actual booked, every further quarter must be estimated before
    its Actual can be entered.
- Re-submitting the same stage + quarter (an edit) **supersedes** the previous
  version (`IsActive = 0`, kept for history) rather than overwriting it.
- Fields left blank on an Estimation/Actual entry are **imported from the previous
  stage's saved values** (Estimation ← Budget; Actual ← Estimation ← Budget) —
  the same "extract → edit → upload" resolution logic is reused by the Excel
  extract endpoint, so what you download always matches what a blank field would
  default to.
- Bulk Excel upload (and the single-entry form) validate **everything first**; if
  anything fails, **nothing is saved** and every row's error is reported.

## Extract → edit → upload (Estimation / Actual via Excel)

`GET /api/budgets/export?entryType=2|3&fyCode=..&quarterCode=..` returns every
Budget Code in that Financial Year, pre-filled in the exact same row shape as the
upload template:

- `entryType=2` (preparing Estimation): each row's figures come from that Budget
  Code's existing Estimation for the chosen quarter if one exists (so you're editing
  a prior estimate), otherwise from its Budget (first estimate of that quarter).
- `entryType=3` (preparing Actual): each row's figures come from that Budget Code's
  Estimation for the chosen quarter if one exists, otherwise its Budget.

The Angular Upload modal turns this JSON into an `.xlsx` file with SheetJS (same
`TEMPLATE_HEADERS` as the blank template), the user edits it in Excel, and uploads
it back through the exact same file picker / `POST /api/budgets/upload` flow used
for a brand-new Budget upload — no separate "import" endpoint needed.

## What's simplified vs. a full production system

This is a self-contained, runnable demo, not a full enterprise rollout. Left out —
add these if you need them for production:

- Financial Year / Quarter **Open / Frozen / Closed** status gating.
- Role-based **Maker/Checker/Controller** permissions and authentication.
- **Audit trail** logging (beyond the built-in supersede/version history).
- Auto-creation of new Project/Company/Industry master rows on the fly — this demo
  stores those as free text directly on the entry.
