import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  BudgetDetail,
  BudgetEntryInput,
  BudgetExportResponse,
  BudgetExportWithReferenceResponse,
  BudgetGridRow,
  BulkUploadRequest,
  BulkUploadResponse,
  Lookup,
  SaveResult
} from '../models/budget.models';

// Update this if the API runs on a different host/port.
export const API_BASE_URL = 'http://localhost:5080/api';

@Injectable({ providedIn: 'root' })
export class BudgetService {
  constructor(private http: HttpClient) {}

  getGrid(filters: { search?: string; productCode?: number | null; fyCode?: number | null; quarterCode?: number | null; stage?: string | null; }): Observable<BudgetGridRow[]> {
    let params = new HttpParams();
    if (filters.search) params = params.set('search', filters.search);
    if (filters.productCode) params = params.set('productCode', filters.productCode);
    if (filters.fyCode) params = params.set('fyCode', filters.fyCode);
    if (filters.quarterCode) params = params.set('quarterCode', filters.quarterCode);
    if (filters.stage) params = params.set('stage', filters.stage);
    return this.http.get<BudgetGridRow[]>(`${API_BASE_URL}/budgets`, { params });
  }

  getDetail(budgetCode: string): Observable<BudgetDetail> {
    return this.http.get<BudgetDetail>(`${API_BASE_URL}/budgets/${encodeURIComponent(budgetCode)}`);
  }

  saveEntry(input: BudgetEntryInput): Observable<SaveResult> {
    return this.http.post<SaveResult>(`${API_BASE_URL}/budgets/entry`, input);
  }

  bulkUpload(request: BulkUploadRequest): Observable<BulkUploadResponse> {
    return this.http.post<BulkUploadResponse>(`${API_BASE_URL}/budgets/upload`, request);
  }

  /**
   * Extract all Budget Codes for a Financial Year in template format, pre-filled with
   * their current best-known figures — Estimation source for entryType=2 (Budget
   * carried forward, or the existing Estimation for that quarter if already entered),
   * Actual source for entryType=3 (Estimation carried forward, or Budget if none).
   * Used to build the "extract -> edit in Excel -> upload" workflow.
   */
  exportTemplate(entryType: number, fyCode: number, quarterCode: number): Observable<BudgetExportResponse> {
    const params = new HttpParams()
      .set('entryType', entryType)
      .set('fyCode', fyCode)
      .set('quarterCode', quarterCode);
    return this.http.get<BudgetExportResponse>(`${API_BASE_URL}/budgets/export`, { params });
  }

  getProducts(): Observable<Lookup[]> {
    return this.http.get<Lookup[]>(`${API_BASE_URL}/lookups/products`);
  }

  getIssueTypes(): Observable<Lookup[]> {
    return this.http.get<Lookup[]>(`${API_BASE_URL}/lookups/issue-types`);
  }

  getIndustryGroups(): Observable<Lookup[]> {
    return this.http.get<Lookup[]>(`${API_BASE_URL}/lookups/industry-groups`);
  }

  getFinancialYears(): Observable<Lookup[]> {
    return this.http.get<Lookup[]>(`${API_BASE_URL}/lookups/financial-years`);
  }
  exportTemplateWithReference(entryType: number, fyCode: number, quarterCode: number): Observable<BudgetExportWithReferenceResponse> {
    const params = new HttpParams()
      .set('entryType', entryType)
      .set('fyCode', fyCode)
      .set('quarterCode', quarterCode);
    return this.http.get<BudgetExportWithReferenceResponse>(`${API_BASE_URL}/budgets/export-with-reference`, { params });
  }
}
