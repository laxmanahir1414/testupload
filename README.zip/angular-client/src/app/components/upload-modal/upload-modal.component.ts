import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import * as XLSX from 'xlsx';
import { BudgetService } from '../../services/budget.service';
import { BulkUploadRow,BulkUploadRowWithReference, Lookup } from '../../models/budget.models';


const TEMPLATE_HEADERS = [
  'Sr No', 'Budget Code', 'Indus Coverage Group', 'Pitched / Is Mandated',
  'Project Name', 'Mandated Company', 'Industry', 'Product', 'Issue Type',
  'Indicative Deal Size (Rs Cr)', 'Estimated Fee Pool (%)', 'Total Fees (Rs Cr)',
  'No. of BRLMs', 'JMF Keep Rate (%)', 'JMF Gross Fee (Rs Cr)',
  'Deal Probability (%)', 'JM Probability (%)', 'Expected Closure',
  'Q1', 'Q2', 'Q3', 'Q4', 'Total', 'Quarter', 'Amount'
];

const REFERENCE_HEADERS = [
  'Budget Q1', 'Budget Q2', 'Budget Q3', 'Budget Q4', 'Budget Total',
  'Estimation Q1', 'Estimation Q2', 'Estimation Q3', 'Estimation Q4', 'Estimation Total',
  'Actual Q1', 'Actual Q2', 'Actual Q3', 'Actual Q4', 'Actual Total'
];

@Component({
  selector: 'app-upload-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './upload-modal.component.html',
  styleUrls: ['./upload-modal.component.css']
})
export class UploadModalComponent implements OnInit, OnChanges {
  @Input() open = false;
  @Output() closed = new EventEmitter<void>();
  @Output() saved = new EventEmitter<void>();

  entryType = 1;          // 1 Budget / 2 Estimation / 3 Actual
  quarterCode = 1;
  fyCode = 0;

  financialYears: Lookup[] = [];

  rows: BulkUploadRow[] = [];
  fileName: string | null = null;

  submitting = false;
  serverMessage: string | null = null;
  serverSuccess = false;

  extracting = false;
  extractError: string | null = null;

  extractingWithReference = false;
  extractWithReferenceError: string | null = null;

  constructor(private budgetService: BudgetService) {}

  ngOnInit(): void {
    this.budgetService.getFinancialYears().subscribe(fy => {
      this.financialYears = fy;
      if (fy.length) this.fyCode = fy[0].code;
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['open'] && this.open) {
      this.rows = [];
      this.fileName = null;
      this.serverMessage = null;
      this.serverSuccess = false;
      this.extractError = null;
      this.extractWithReferenceError = null;
      this.extractingWithReference = false;
      this.extracting = false;
    }
  }

  get hasClientErrors(): boolean {
    return this.rows.some(r => !!r.clientError);
  }

  get canSubmit(): boolean {
    return this.rows.length > 0 && !this.hasClientErrors && !this.submitting;
  }

  downloadTemplate(): void {
    const sample = {
      'Sr No': 1,
      'Budget Code': this.entryType === 1 ? 'BUD-FY26-00001' : '(existing budget code)',
      'Indus Coverage Group': 'Consumer',
      'Pitched / Is Mandated': 'Pitched',
      'Project Name': 'Sample Project',
      'Mandated Company': '',
      'Industry': 'Digital Marketing',
      'Product': 'Capital Market',
      'Issue Type': 'IPO',
      'Indicative Deal Size (Rs Cr)': 500,
      'Estimated Fee Pool (%)': 25,
      'Total Fees (Rs Cr)': 125,
      'No. of BRLMs': 4,
      'JMF Keep Rate (%)': 25,
      'JMF Gross Fee (Rs Cr)': 31.25,
      'Deal Probability (%)': 90,
      'JM Probability (%)': 80,
      'Expected Closure': 'Q2',
      'Q1': 5, 'Q2': 17.5, 'Q3': 0, 'Q4': 0, 'Total': 22.5,
      'Quarter': 'Q' + this.quarterCode,
      'Amount': 5
    };
    const ws = XLSX.utils.json_to_sheet([sample], { header: TEMPLATE_HEADERS });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Budget Upload');
    XLSX.writeFile(wb, 'budget-upload-template.xlsx');
  }

  /**
   * Extract-to-Excel: pulls every Budget Code's current best-known figures from the
   * database (Budget/Estimation for entryType=2, Estimation/Budget for entryType=3),
   * in the SAME template row shape as downloadTemplate(), and triggers a download.
   * The user edits the figures in Excel and uploads the same file back via
   * onFileSelected() / submit() — no separate "import" step needed.
   */
  extractTemplate(): void {
    if (this.entryType !== 2 && this.entryType !== 3) return;
    this.extracting = true;
    this.extractError = null;

    this.budgetService.exportTemplate(this.entryType, this.fyCode, this.quarterCode).subscribe({
      next: response => {
        this.extracting = false;
        if (!response.rows || response.rows.length === 0) {
          this.extractError = response.message || 'Nothing to extract yet — add a Budget entry first.';
          return;
        }

        const sheetRows = response.rows.map((row, i) => this.rowToSheetRow(row, i + 1));
        const ws = XLSX.utils.json_to_sheet(sheetRows, { header: TEMPLATE_HEADERS });
        const wb = XLSX.utils.book_new();
        const stage = this.entryType === 2 ? 'Estimation' : 'Actual';
        XLSX.utils.book_append_sheet(wb, ws, `${stage} Upload`);
        XLSX.writeFile(wb, `${stage.toLowerCase()}-extract-q${this.quarterCode}.xlsx`);
      },
      error: err => {
        this.extracting = false;
        this.extractError = err?.error?.message || 'Extract failed. Is the API running?';
      }
    });
  }

  private rowToSheetRow(row: BulkUploadRow, srNo: number): any {
    return {
      'Sr No': srNo,
      'Budget Code': row.budgetCode ?? '',
      'Indus Coverage Group': row.indusCoverageGroup ?? '',
      'Pitched / Is Mandated': row.pitchedOrMandated ?? '',
      'Project Name': row.projectName ?? '',
      'Mandated Company': row.mandatedCompany ?? '',
      'Industry': row.industry ?? '',
      'Product': row.product ?? '',
      'Issue Type': row.issueType ?? '',
      'Indicative Deal Size (Rs Cr)': row.indicativeDealSize ?? '',
      'Estimated Fee Pool (%)': row.estimatedFeePool ?? '',
      'Total Fees (Rs Cr)': row.totalFees ?? '',
      'No. of BRLMs': row.noOfBRLMs ?? '',
      'JMF Keep Rate (%)': row.jmfKeepRate ?? '',
      'JMF Gross Fee (Rs Cr)': row.jmfGrossFee ?? '',
      'Deal Probability (%)': row.dealProbability ?? '',
      'JM Probability (%)': row.jmProbability ?? '',
      'Expected Closure': row.expectedClosure ?? '',
      'Q1': row.q1 ?? '',
      'Q2': row.q2 ?? '',
      'Q3': row.q3 ?? '',
      'Q4': row.q4 ?? '',
      'Total': row.total ?? '',
      'Quarter': row.quarter ?? '',
      'Amount': row.amount ?? ''
    };
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    this.fileName = file.name;
    this.serverMessage = null;

    const reader = new FileReader();
    reader.onload = e => {
      const data = new Uint8Array(e.target?.result as ArrayBuffer);
      const workbook = XLSX.read(data, { type: 'array' });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const json = XLSX.utils.sheet_to_json<any>(sheet, { defval: null });
      this.rows = json.map((raw, i) => this.mapAndValidate(raw, i + 2));
    };
    reader.readAsArrayBuffer(file);
    input.value = '';
  }

  private toNumber(v: any): number | null {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(v);
    return isNaN(n) ? null : n;
  }

  private mapAndValidate(raw: any, rowNumber: number): BulkUploadRow {
    const row: BulkUploadRow = {
      rowNumber,
      budgetCode: raw['Budget Code'] ?? null,
      indusCoverageGroup: raw['Indus Coverage Group'] ?? null,
      pitchedOrMandated: raw['Pitched / Is Mandated'] ?? null,
      projectName: raw['Project Name'] ?? null,
      mandatedCompany: raw['Mandated Company'] ?? null,
      industry: raw['Industry'] ?? null,
      product: raw['Product'] ?? null,
      issueType: raw['Issue Type'] ?? null,
      indicativeDealSize: this.toNumber(raw['Indicative Deal Size (Rs Cr)']),
      estimatedFeePool: this.toNumber(raw['Estimated Fee Pool (%)']),
      totalFees: this.toNumber(raw['Total Fees (Rs Cr)']),
      noOfBRLMs: this.toNumber(raw['No. of BRLMs']),
      jmfKeepRate: this.toNumber(raw['JMF Keep Rate (%)']),
      jmfGrossFee: this.toNumber(raw['JMF Gross Fee (Rs Cr)']),
      dealProbability: this.toNumber(raw['Deal Probability (%)']),
      jmProbability: this.toNumber(raw['JM Probability (%)']),
      expectedClosure: raw['Expected Closure'] ?? null,
      q1: this.toNumber(raw['Q1']),
      q2: this.toNumber(raw['Q2']),
      q3: this.toNumber(raw['Q3']),
      q4: this.toNumber(raw['Q4']),
      total: this.toNumber(raw['Total']),
      quarter: raw['Quarter'] ?? null,
      amount: this.toNumber(raw['Amount']),
      clientError: null
    };

    // ---- lightweight client-side validation (server re-validates everything) ----
    const errors: string[] = [];
    if (!row.budgetCode || !String(row.budgetCode).trim()) errors.push('Budget Code is required');
    if (this.entryType === 1 && !row.product) errors.push('Product is required for Budget');
    if (this.entryType === 1 && !row.projectName && !row.mandatedCompany) errors.push('Project Name or Mandated Company is required');
    if (row.expectedClosure && !/^Q[1-4]$/i.test(String(row.expectedClosure).trim())) errors.push('Expected Closure must be Q1-Q4');
    if (typeof row.dealProbability === 'number' && (row.dealProbability < 0 || row.dealProbability > 100)) errors.push('Deal Probability must be 0-100');
    if (typeof row.jmProbability === 'number' && (row.jmProbability < 0 || row.jmProbability > 100)) errors.push('JM Probability must be 0-100');

    row.clientError = errors.length ? errors.join('; ') : null;
    return row;
  }

  removeFile(): void {
    this.rows = [];
    this.fileName = null;
    this.serverMessage = null;
  }

  submit(): void {
    if (!this.canSubmit) return;
    this.submitting = true;
    this.serverMessage = null;

    const payload = {
      entryType: Number(this.entryType),
      quarterCode: Number(this.quarterCode),
      fyCode: Number(this.fyCode),
      createdBy: 1,
      rows: this.rows.map(({ clientError, ...r }) => r)
    };

    this.budgetService.bulkUpload(payload).subscribe({
      next: response => {
        this.submitting = false;
        this.serverSuccess = response.success;
        this.serverMessage = response.message;

        // merge server-side per-row errors back into the grid (shown red again)
        const byRow = new Map(response.rows.map(r => [r.rowNumber, r]));
        this.rows = this.rows.map(r => {
          const res = byRow.get(r.rowNumber);
          if (res && !res.success) {
            return { ...r, clientError: res.errorMessage || 'Failed' };
          }
          return { ...r, clientError: null };
        });

        if (response.success) {
          this.saved.emit();
          setTimeout(() => this.close(), 1200);
        }
      },
      error: err => {
        this.submitting = false;
        this.serverSuccess = false;
        this.serverMessage = err?.error?.message || 'Upload failed. Is the API running?';
      }
    });
  }

  close(): void {
    this.open = false;
    this.closed.emit();
  }

  onBackdropClick(event: MouseEvent): void {
    if (event.target === event.currentTarget) this.close();
  }

  extractTemplateWithReference(): void {
    if (this.entryType !== 2 && this.entryType !== 3) return;
    this.extractingWithReference = true;
    this.extractWithReferenceError = null;

    this.budgetService.exportTemplateWithReference(this.entryType, this.fyCode, this.quarterCode).subscribe({
      next: response => {
        this.extractingWithReference = false;
        if (!response.rows || response.rows.length === 0) {
          this.extractWithReferenceError = response.message || 'Nothing to extract yet — add a Budget entry first.';
          return;
        }

        const sheetRows = response.rows.map((row, i) => this.rowToSheetRowWithReference(row, i + 1));
        const ws = XLSX.utils.json_to_sheet(sheetRows, { header: [...TEMPLATE_HEADERS, ...REFERENCE_HEADERS] });
        const wb = XLSX.utils.book_new();
        const stage = this.entryType === 2 ? 'Estimation' : 'Actual';
        XLSX.utils.book_append_sheet(wb, ws, `${stage} With Reference`);
        XLSX.writeFile(wb, `${stage.toLowerCase()}-with-reference-q${this.quarterCode}.xlsx`);
      },
      error: err => {
        this.extractingWithReference = false;
        this.extractWithReferenceError = err?.error?.message || 'Extract failed. Is the API running?';
      }
    });
  }

  private rowToSheetRowWithReference(row: BulkUploadRowWithReference, srNo: number): any {
    return {
      ...this.rowToSheetRow(row, srNo),
      'Budget Q1': row.refBudgetQ1 ?? '',
      'Budget Q2': row.refBudgetQ2 ?? '',
      'Budget Q3': row.refBudgetQ3 ?? '',
      'Budget Q4': row.refBudgetQ4 ?? '',
      'Budget Total': row.refBudgetTotal ?? '',
      'Estimation Q1': row.refEstimationQ1 ?? '',
      'Estimation Q2': row.refEstimationQ2 ?? '',
      'Estimation Q3': row.refEstimationQ3 ?? '',
      'Estimation Q4': row.refEstimationQ4 ?? '',
      'Estimation Total': row.refEstimationTotal ?? '',
      'Actual Q1': row.refActualQ1 ?? '',
      'Actual Q2': row.refActualQ2 ?? '',
      'Actual Q3': row.refActualQ3 ?? '',
      'Actual Q4': row.refActualQ4 ?? '',
      'Actual Total': row.refActualTotal ?? ''
    };
  }
}
