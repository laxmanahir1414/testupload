import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BudgetService } from '../../services/budget.service';
import { BudgetGridRow, Lookup } from '../../models/budget.models';

@Component({
  selector: 'app-budget-grid',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './budget-grid.component.html',
  styleUrls: ['./budget-grid.component.css']
})
export class BudgetGridComponent implements OnInit, OnChanges {
  @Input() refreshToken = 0;
  @Output() view = new EventEmitter<string>();
  @Output() addBudget = new EventEmitter<void>();

  rows: BudgetGridRow[] = [];
  loading = false;
  errorMessage: string | null = null;

  products: Lookup[] = [];
  financialYears: Lookup[] = [];

  search = '';
  productCode: number | null = null;
  fyCode: number | null = null;
  quarterCode: number | null = null;
  stage: string | null = null;

  private searchDebounce: ReturnType<typeof setTimeout> | null = null;

  readonly stages: { label: string; value: string | null }[] = [
    { label: 'All', value: null },
    { label: 'Budget', value: 'Budget' },
    { label: 'Estimation', value: 'Estimation' },
    { label: 'Actual', value: 'Actual' }
  ];

  readonly quarters = [1, 2, 3, 4];

  constructor(private budgetService: BudgetService) {}

  ngOnInit(): void {
  this.budgetService.getProducts().subscribe({
    next: p => (this.products = p),
    error: err => console.error('Failed to load products', err)
  });

  this.budgetService.getFinancialYears().subscribe({
    next: fy => {
      this.financialYears = fy;
      if (fy.length && this.fyCode === null) {
        this.fyCode = fy[0].code;
      }
    },
    error: err => console.error('Failed to load financial years', err)
  });

  // Load the grid unconditionally — don't depend on financial years succeeding first.
  this.load();
}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['refreshToken'] && !changes['refreshToken'].firstChange) {
      this.load();
    }
  }

  load(): void {
    this.loading = true;
    this.errorMessage = null;
    this.budgetService
      .getGrid({
        search: this.search || undefined,
        productCode: this.productCode,
        fyCode: this.fyCode,
        quarterCode: this.quarterCode,
        stage: this.stage
      })
      .subscribe({
        next: rows => {
          this.rows = rows;
          this.loading = false;
        },
        error: err => {
          this.loading = false;
          this.errorMessage = 'Could not load budgets. Is the API running on http://localhost:5080?';
          console.error(err);
        }
      });
  }

  onSearchChange(): void {
    if (this.searchDebounce) clearTimeout(this.searchDebounce);
    this.searchDebounce = setTimeout(() => this.load(), 300);
  }

  setStage(stage: string | null): void {
    this.stage = stage;
    this.load();
  }

  resetFilters(): void {
    this.search = '';
    this.productCode = null;
    this.quarterCode = null;
    this.stage = null;
    this.load();
  }

  onView(row: BudgetGridRow): void {
    this.view.emit(row.budgetCode);
  }

  stageBadgeClass(stage: string): string {
    switch (stage) {
      case 'Actual': return 'badge badge-actual';
      case 'Estimation': return 'badge badge-estimation';
      default: return 'badge badge-budget';
    }
  }

  trackByBudgetCode(_index: number, row: BudgetGridRow): string {
    return row.budgetCode;
  }
}
