export interface Lookup {
  code: number;
  name: string;
}

export type Stage = 'Budget' | 'Estimation' | 'Actual';

export interface BudgetGridRow {
  budgetCode: string;
  productName: string;
  issueType: string;
  projectOrCompany: string;
  industryName: string;
  indusCoverageGroupName: string;
  fyName: string;
  isMandated: boolean;
  indicativeDealSize: number;
  dealProbability: number;
  budgetTotal: number;
  estimationTotal: number | null;
  actualTotal: number | null;
  stage: Stage;
}

export interface QuarterFigure {
  quarterCode: number;
  quarterLabel: string;
  budget: number | null;
  estimation: number | null;
  actual: number | null;
  /** True once this quarter has an Actual booked — Estimation for this quarter is locked. */
  isLocked: boolean;
}

export interface BudgetDetail {
  budgetCode: string;
  productName: string;
  issueType: string;
  projectName: string;
  companyName: string;
  industryName: string;
  indusCoverageGroupName: string;
  fyName: string;
  isMandated: boolean;
  indicativeDealSize: number;
  estimatedFeePool: number;
  totalFees: number;
  noOfBRLMs: number;
  jmfKeepRate: number;
  jmfGrossFee: number;
  dealProbability: number;
  jmProbability: number;
  expectedClosure: number;
  quarters: QuarterFigure[];
  budgetTotal: number;
  estimationTotal: number;
  actualTotal: number;
}

export interface BudgetEntryInput {
  budgetCode?: string | null;
  entryType: number;       // 1 Budget / 2 Estimation / 3 Actual
  quarterCode: number;
  fyCode: number;
  createdBy?: number;

  productCode?: number | null;
  prodIssueTypeCode?: number | null;
  indusCGCode?: number | null;

  projectName?: string | null;
  companyName?: string | null;
  industryName?: string | null;

  indicativeDealSize?: number | null;
  estimatedFeePool?: number | null;
  totalFees?: number | null;
  noOfBRLMs?: number | null;
  jmfKeepRate?: number | null;
  jmfGrossFee?: number | null;
  dealProbability?: number | null;
  jmProbability?: number | null;
  expectedClosure?: number | null;

  q1?: number | null;
  q2?: number | null;
  q3?: number | null;
  q4?: number | null;
  amount?: number | null;

  isMandated?: boolean | null;
  remarks?: string | null;
}

export interface SaveResult {
  success: boolean;
  message: string;
  budgetCode?: string | null;
}

export interface BulkUploadRow {
  rowNumber: number;
  budgetCode?: string | null;
  indusCoverageGroup?: string | null;
  pitchedOrMandated?: string | null;
  projectName?: string | null;
  mandatedCompany?: string | null;
  industry?: string | null;
  product?: string | null;
  issueType?: string | null;
  indicativeDealSize?: number | null;
  estimatedFeePool?: number | null;
  totalFees?: number | null;
  noOfBRLMs?: number | null;
  jmfKeepRate?: number | null;
  jmfGrossFee?: number | null;
  dealProbability?: number | null;
  jmProbability?: number | null;
  expectedClosure?: string | null;
  q1?: number | null;
  q2?: number | null;
  q3?: number | null;
  q4?: number | null;
  total?: number | null;
  quarter?: string | null;
  amount?: number | null;

  // client-side only, not sent to API
  clientError?: string | null;
}

export interface BulkUploadRequest {
  entryType: number;
  quarterCode: number;
  fyCode: number;
  createdBy?: number;
  rows: BulkUploadRow[];
}

export interface BulkUploadRowResult {
  rowNumber: number;
  budgetCode?: string | null;
  success: boolean;
  errorMessage?: string | null;
}

export interface BulkUploadResponse {
  success: boolean;
  message: string;
  rows: BulkUploadRowResult[];
}

export interface BudgetExportResponse {
  message: string;
  rows: BulkUploadRow[];
}
export interface BulkUploadRowWithReference extends BulkUploadRow {
  refBudgetQ1?: number | null;
  refBudgetQ2?: number | null;
  refBudgetQ3?: number | null;
  refBudgetQ4?: number | null;
  refBudgetTotal?: number | null;

  refEstimationQ1?: number | null;
  refEstimationQ2?: number | null;
  refEstimationQ3?: number | null;
  refEstimationQ4?: number | null;
  refEstimationTotal?: number | null;

  refActualQ1?: number | null;
  refActualQ2?: number | null;
  refActualQ3?: number | null;
  refActualQ4?: number | null;
  refActualTotal?: number | null;
}

export interface BudgetExportWithReferenceResponse {
  message: string;
  rows: BulkUploadRowWithReference[];
}