/* ============================================================================
   03_StoredProcedures.sql
   Budget Management System — stored procedures used by the ADO.NET data
   access layer (api/Data/BudgetRepository.cs). Every data access call from
   the API goes through one of these; no ad-hoc SQL text is built in C#.

   All procedures use CREATE OR ALTER, so this script is safe/idempotent to
   re-run any time you change a procedure.
   ============================================================================ */

USE [BudgetManagementDb];
GO

-- ============================================================================
-- LOOKUPS
-- ============================================================================

CREATE OR ALTER PROCEDURE dbo.usp_Products_GetAll
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Code, Name FROM dbo.Products ORDER BY Name;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_IssueTypes_GetAll
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Code, Name FROM dbo.IssueTypes ORDER BY Name;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_IndustryGroups_GetAll
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Code, Name FROM dbo.IndustryCoverageGroups ORDER BY Name;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_FinancialYears_GetAll
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Code, Name, IsCurrent FROM dbo.FinancialYears ORDER BY Code DESC;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_FinancialYear_GetByCode
    @FYCode INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Code, Name, IsCurrent FROM dbo.FinancialYears WHERE Code = @FYCode;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_Product_GetByCode
    @Code INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Code, Name FROM dbo.Products WHERE Code = @Code;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_IssueType_GetByCode
    @Code INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Code, Name FROM dbo.IssueTypes WHERE Code = @Code;
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_IndusGroup_GetByCode
    @Code INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Code, Name FROM dbo.IndustryCoverageGroups WHERE Code = @Code;
END;
GO

-- ============================================================================
-- BUDGET ENTRIES — reads
-- ============================================================================

-- All ACTIVE rows (optionally for one BudgetCode). Backs the grid, the detail
-- modal, and the "resolve import source" logic.
CREATE OR ALTER PROCEDURE dbo.usp_BudgetEntries_GetActiveAll
    @BudgetCode NVARCHAR(30) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT *
    FROM dbo.BudgetEntries
    WHERE IsActive = 1
      AND (@BudgetCode IS NULL OR BudgetCode = @BudgetCode)
    ORDER BY CreatedOn ASC;
END;
GO

-- The single newest ACTIVE row for (BudgetCode, EntryType[, QuarterCode]).
CREATE OR ALTER PROCEDURE dbo.usp_BudgetEntries_GetLatest
    @BudgetCode  NVARCHAR(30),
    @EntryType   INT,
    @QuarterCode INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (1) *
    FROM dbo.BudgetEntries
    WHERE BudgetCode = @BudgetCode
      AND EntryType = @EntryType
      AND IsActive = 1
      AND (@QuarterCode IS NULL OR QuarterCode = @QuarterCode)
    ORDER BY CreatedOn DESC, Id DESC;
END;
GO

-- Has ANY Actual (EntryType = 3) ever been recorded for this Budget Code,
-- active or historical? Used to implement:
--   "actual will be entered after budget which is against first entry;
--    once done, next time actual is entered after estimation."
CREATE OR ALTER PROCEDURE dbo.usp_BudgetEntries_HasAnyActualEver
    @BudgetCode NVARCHAR(30)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CASE WHEN EXISTS (
        SELECT 1 FROM dbo.BudgetEntries WHERE BudgetCode = @BudgetCode AND EntryType = 3
    ) THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS HasAnyActual;
END;
GO

-- Next sequence number for a Budget Code prefix within a Financial Year,
-- e.g. prefix 'BUD-FY2026-' -> returns 3 if 00001 and 00002 already exist.
CREATE OR ALTER PROCEDURE dbo.usp_BudgetCode_NextSequence
    @FYCode INT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Prefix NVARCHAR(40) = N'BUD-FY' + CAST(@FYCode AS NVARCHAR(10)) + N'-';
    DECLARE @PrefixLen INT = LEN(@Prefix);

    SELECT ISNULL(MAX(TRY_CAST(SUBSTRING(BudgetCode, @PrefixLen + 1, 10) AS INT)), 0) + 1 AS NextSeq
    FROM dbo.BudgetEntries
    WHERE BudgetCode LIKE @Prefix + N'%'
      AND LEN(BudgetCode) > @PrefixLen;
END;
GO

-- ============================================================================
-- BUDGET ENTRIES — writes
-- ============================================================================

CREATE OR ALTER PROCEDURE dbo.usp_BudgetEntries_Insert
    @BudgetCode              NVARCHAR(30),
    @ProductCode             INT,
    @ProductName             NVARCHAR(200),
    @IssueType                NVARCHAR(200),
    @ProjectName               NVARCHAR(200),
    @CompanyName                NVARCHAR(200),
    @IndustryName                 NVARCHAR(200),
    @IndusCoverageGroupCode         INT,
    @IndusCoverageGroupName          NVARCHAR(200),
    @FYCode                  INT,
    @FYName                  NVARCHAR(50),
    @QuarterCode              INT,
    @EntryType                INT,
    @IsMandated                BIT,
    @IndicativeDealSize        DECIMAL(18,2),
    @EstimatedFeePool          DECIMAL(5,2),
    @TotalFees                 DECIMAL(18,2),
    @NoOfBRLMs                 INT,
    @JMFKeepRate                DECIMAL(5,2),
    @JMFGrossFee                 DECIMAL(18,2),
    @DealProbability            DECIMAL(5,2),
    @JMProbability               DECIMAL(5,2),
    @ExpectedClosure             INT,
    @Q1                       DECIMAL(18,2),
    @Q2                       DECIMAL(18,2),
    @Q3                       DECIMAL(18,2),
    @Q4                       DECIMAL(18,2),
    @Total                    DECIMAL(18,2),
    @Amount                   DECIMAL(18,2),
    @Remarks                  NVARCHAR(400),
    @SupersedesId             INT = NULL,
    @CreatedBy                INT,
    @CreatedOn                DATETIME2,
    @NewId                    INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.BudgetEntries
        (BudgetCode, ProductCode, ProductName, IssueType, ProjectName, CompanyName, IndustryName,
         IndusCoverageGroupCode, IndusCoverageGroupName, FYCode, FYName, QuarterCode, EntryType,
         IsMandated, IndicativeDealSize, EstimatedFeePool, TotalFees, NoOfBRLMs, JMFKeepRate, JMFGrossFee,
         DealProbability, JMProbability, ExpectedClosure, Q1, Q2, Q3, Q4, Total, Amount, Remarks,
         IsActive, SupersedesId, CreatedBy, CreatedOn)
    VALUES
        (@BudgetCode, @ProductCode, @ProductName, @IssueType, @ProjectName, @CompanyName, @IndustryName,
         @IndusCoverageGroupCode, @IndusCoverageGroupName, @FYCode, @FYName, @QuarterCode, @EntryType,
         @IsMandated, @IndicativeDealSize, @EstimatedFeePool, @TotalFees, @NoOfBRLMs, @JMFKeepRate, @JMFGrossFee,
         @DealProbability, @JMProbability, @ExpectedClosure, @Q1, @Q2, @Q3, @Q4, @Total, @Amount, @Remarks,
         1, @SupersedesId, @CreatedBy, @CreatedOn);

    SET @NewId = SCOPE_IDENTITY();
END;
GO

CREATE OR ALTER PROCEDURE dbo.usp_BudgetEntries_Supersede
    @Id INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.BudgetEntries SET IsActive = 0 WHERE Id = @Id;
END;
GO
