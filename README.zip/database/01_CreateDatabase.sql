/* ============================================================================
   01_CreateDatabase.sql
   Budget Management System — database creation script.
   Safe to re-run: only creates the database if it doesn't already exist.
   Run this in SSMS / sqlcmd connected to the SQL Server instance (any DB, e.g. master).
   ============================================================================ */

IF DB_ID(N'BudgetManagementDb') IS NULL
BEGIN
    CREATE DATABASE [BudgetManagementDb];
END;
GO
