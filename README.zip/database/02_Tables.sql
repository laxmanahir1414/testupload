/* ============================================================================
   02_Tables.sql
   Budget Management System — table DDL.
   Every CREATE is guarded with an existence check, so this script is safe to
   run every time (no destructive drops). Run against BudgetManagementDb.
   ============================================================================ */

USE [BudgetManagementDb];
GO

-- ----------------------------------------------------------------------------
-- Master / lookup tables
-- ----------------------------------------------------------------------------

IF OBJECT_ID('dbo.Products', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Products
    (
        Code INT           NOT NULL PRIMARY KEY,
        Name NVARCHAR(200) NOT NULL
    );
END;
GO

IF OBJECT_ID('dbo.IssueTypes', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.IssueTypes
    (
        Code INT           NOT NULL PRIMARY KEY,
        Name NVARCHAR(200) NOT NULL
    );
END;
GO

IF OBJECT_ID('dbo.IndustryCoverageGroups', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.IndustryCoverageGroups
    (
        Code INT           NOT NULL PRIMARY KEY,
        Name NVARCHAR(200) NOT NULL
    );
END;
GO

IF OBJECT_ID('dbo.FinancialYears', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.FinancialYears
    (
        Code      INT          NOT NULL PRIMARY KEY,   -- e.g. 2026 = "FY 2025-26"
        Name      NVARCHAR(50) NOT NULL,
        IsCurrent BIT          NOT NULL DEFAULT (0)
    );
END;
GO

-- ----------------------------------------------------------------------------
-- Transaction table: one row per saved version of a Budget / Estimation /
-- Actual line. EntryType: 1 = Budget, 2 = Estimation, 3 = Actual.
--
-- Versioning: a given (BudgetCode, EntryType, QuarterCode) combination can
-- have many rows over time (re-submits / corrections). Only the newest row
-- has IsActive = 1; the previous one is flipped to IsActive = 0 and kept for
-- history, linked via SupersedesId.
-- ----------------------------------------------------------------------------

IF OBJECT_ID('dbo.BudgetEntries', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.BudgetEntries
    (
        Id                      INT IDENTITY(1,1) NOT NULL PRIMARY KEY,

        BudgetCode              NVARCHAR(30)   NOT NULL,

        ProductCode              INT           NOT NULL,
        ProductName               NVARCHAR(200) NOT NULL,
        IssueType                 NVARCHAR(200) NOT NULL,
        ProjectName                NVARCHAR(200) NOT NULL,
        CompanyName                NVARCHAR(200) NOT NULL,
        IndustryName                NVARCHAR(200) NOT NULL,
        IndusCoverageGroupCode       INT           NOT NULL,
        IndusCoverageGroupName        NVARCHAR(200) NOT NULL,

        FYCode                   INT           NOT NULL,   -- Financial Year this budget code belongs to
        FYName                   NVARCHAR(50)  NOT NULL,
        QuarterCode              INT           NOT NULL,    -- 1-4: which quarter this version was recorded for

        EntryType                INT           NOT NULL,    -- 1 Budget / 2 Estimation / 3 Actual

        IsMandated                BIT          NOT NULL DEFAULT (0),
        IndicativeDealSize        DECIMAL(18,2) NOT NULL DEFAULT (0),
        EstimatedFeePool          DECIMAL(5,2)  NOT NULL DEFAULT (0),
        TotalFees                 DECIMAL(18,2) NOT NULL DEFAULT (0),
        NoOfBRLMs                 INT           NOT NULL DEFAULT (0),
        JMFKeepRate                DECIMAL(5,2)  NOT NULL DEFAULT (0),
        JMFGrossFee                 DECIMAL(18,2) NOT NULL DEFAULT (0),
        DealProbability            DECIMAL(5,2)  NOT NULL DEFAULT (0),
        JMProbability               DECIMAL(5,2)  NOT NULL DEFAULT (0),
        ExpectedClosure             INT           NOT NULL DEFAULT (0),   -- expected closure quarter 1-4

        Q1                        DECIMAL(18,2) NOT NULL DEFAULT (0),
        Q2                        DECIMAL(18,2) NOT NULL DEFAULT (0),
        Q3                        DECIMAL(18,2) NOT NULL DEFAULT (0),
        Q4                        DECIMAL(18,2) NOT NULL DEFAULT (0),
        Total                     DECIMAL(18,2) NOT NULL DEFAULT (0),
        Amount                    DECIMAL(18,2) NOT NULL DEFAULT (0),    -- fee amount actually booked for the quarter (Actual)

        Remarks                   NVARCHAR(400) NOT NULL DEFAULT (''),

        IsActive                  BIT           NOT NULL DEFAULT (1),
        SupersedesId              INT           NULL,

        CreatedBy                 INT           NOT NULL,
        CreatedOn                 DATETIME2     NOT NULL DEFAULT (SYSUTCDATETIME()),

        CONSTRAINT FK_BudgetEntries_Supersedes
            FOREIGN KEY (SupersedesId) REFERENCES dbo.BudgetEntries(Id),
        CONSTRAINT FK_BudgetEntries_FinancialYear
            FOREIGN KEY (FYCode) REFERENCES dbo.FinancialYears(Code),
        CONSTRAINT CK_BudgetEntries_EntryType
            CHECK (EntryType IN (1, 2, 3)),
        CONSTRAINT CK_BudgetEntries_QuarterCode
            CHECK (QuarterCode BETWEEN 1 AND 4)
    );

    -- General lookup index for the versioning queries (BudgetCode + EntryType + Quarter + IsActive)
    CREATE INDEX IX_BudgetEntries_Lookup
        ON dbo.BudgetEntries (BudgetCode, EntryType, QuarterCode, IsActive);

    -- Business rule: "for one financial year a budget code is only one, no
    -- duplicate entry" — enforced at the database level. Only one ACTIVE
    -- Budget (EntryType = 1) row can ever exist per BudgetCode. This is a
    -- filtered unique index, not a plain unique constraint, because
    -- Estimation/Actual rows for the same BudgetCode are expected and the
    -- superseded (IsActive = 0) historical Budget row must not collide with
    -- an edited/re-inserted one.
    CREATE UNIQUE INDEX UX_BudgetEntries_OneActiveBudgetPerCode
        ON dbo.BudgetEntries (BudgetCode)
        WHERE EntryType = 1 AND IsActive = 1;

    -- Business rule: for a given Budget Code + Quarter, only one ACTIVE
    -- Estimation row and only one ACTIVE Actual row may exist at a time.
    CREATE UNIQUE INDEX UX_BudgetEntries_OneActiveEstimationPerCodeQuarter
        ON dbo.BudgetEntries (BudgetCode, QuarterCode)
        WHERE EntryType = 2 AND IsActive = 1;

    CREATE UNIQUE INDEX UX_BudgetEntries_OneActiveActualPerCodeQuarter
        ON dbo.BudgetEntries (BudgetCode, QuarterCode)
        WHERE EntryType = 3 AND IsActive = 1;
END;
GO
