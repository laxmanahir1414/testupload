# Database scripts

Plain T-SQL. No ORM, no migrations tool — run these by hand with SSMS / `sqlcmd`, or
just start the API and it will run them for you automatically (see the root
README). Run in this order:

1. **01_CreateDatabase.sql** — creates the `BudgetManagementDb` database (safe to
   re-run; skips if it already exists).
2. **02_Tables.sql** — creates all tables, indexes and constraints (safe to re-run).
3. **03_StoredProcedures.sql** — creates every stored procedure the API calls
   (uses `CREATE OR ALTER`, safe to re-run any time you change a procedure).
4. **04_SeedData.sql** — inserts master data (Products, Issue Types, Industry
   Coverage Groups, Financial Years) and 3 sample Budget Codes. Only inserts if the
   tables are empty, so it's safe to re-run.

Optional:

- **05_DropAll.sql** — drops every table and procedure created above, for a full
  reset. Re-run 02 → 03 → 04 afterwards.

## Run manually with sqlcmd

```bash
sqlcmd -S localhost -E -i 01_CreateDatabase.sql
sqlcmd -S localhost -E -i 02_Tables.sql
sqlcmd -S localhost -E -i 03_StoredProcedures.sql
sqlcmd -S localhost -E -i 04_SeedData.sql
```

(swap `-E` for `-U youruser -P yourpassword` if you're not using Windows auth)

If you run these yourself, set `"SkipDbInitOnStartup": true` in
`api/appsettings.json` so the API doesn't also try to run them on startup.

## Schema summary

- `dbo.Products`, `dbo.IssueTypes`, `dbo.IndustryCoverageGroups`, `dbo.FinancialYears`
  — small master/lookup tables.
- `dbo.BudgetEntries` — every saved version of every Budget / Estimation / Actual
  line. `EntryType`: 1 = Budget, 2 = Estimation, 3 = Actual. Only the newest row for
  a given `(BudgetCode, EntryType, QuarterCode)` has `IsActive = 1`; older ones are
  kept for history via `SupersedesId`.

Three **filtered unique indexes** enforce the core business rules at the database
level (in addition to the application-level checks in `BudgetService.cs`):

```sql
-- One Budget Code = one Budget entry, ever, for its financial year
CREATE UNIQUE INDEX UX_BudgetEntries_OneActiveBudgetPerCode
    ON dbo.BudgetEntries (BudgetCode) WHERE EntryType = 1 AND IsActive = 1;

-- One active Estimation per Budget Code + Quarter
CREATE UNIQUE INDEX UX_BudgetEntries_OneActiveEstimationPerCodeQuarter
    ON dbo.BudgetEntries (BudgetCode, QuarterCode) WHERE EntryType = 2 AND IsActive = 1;

-- One active Actual per Budget Code + Quarter
CREATE UNIQUE INDEX UX_BudgetEntries_OneActiveActualPerCodeQuarter
    ON dbo.BudgetEntries (BudgetCode, QuarterCode) WHERE EntryType = 3 AND IsActive = 1;
```
