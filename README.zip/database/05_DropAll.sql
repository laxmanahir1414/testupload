/* ============================================================================
   05_DropAll.sql
   Budget Management System — full reset. Drops every object created by
   02_Tables.sql / 03_StoredProcedures.sql. Use this when you want to start
   over with a clean database (then re-run 02, 03, 04).
   ============================================================================ */

USE [BudgetManagementDb];
GO

DROP PROCEDURE IF EXISTS dbo.usp_Products_GetAll;
DROP PROCEDURE IF EXISTS dbo.usp_IssueTypes_GetAll;
DROP PROCEDURE IF EXISTS dbo.usp_IndustryGroups_GetAll;
DROP PROCEDURE IF EXISTS dbo.usp_FinancialYears_GetAll;
DROP PROCEDURE IF EXISTS dbo.usp_FinancialYear_GetByCode;
DROP PROCEDURE IF EXISTS dbo.usp_Product_GetByCode;
DROP PROCEDURE IF EXISTS dbo.usp_IssueType_GetByCode;
DROP PROCEDURE IF EXISTS dbo.usp_IndusGroup_GetByCode;
DROP PROCEDURE IF EXISTS dbo.usp_BudgetEntries_GetActiveAll;
DROP PROCEDURE IF EXISTS dbo.usp_BudgetEntries_GetLatest;
DROP PROCEDURE IF EXISTS dbo.usp_BudgetEntries_HasAnyActualEver;
DROP PROCEDURE IF EXISTS dbo.usp_BudgetCode_NextSequence;
DROP PROCEDURE IF EXISTS dbo.usp_BudgetEntries_Insert;
DROP PROCEDURE IF EXISTS dbo.usp_BudgetEntries_Supersede;
GO

DROP TABLE IF EXISTS dbo.BudgetEntries;
DROP TABLE IF EXISTS dbo.FinancialYears;
DROP TABLE IF EXISTS dbo.IndustryCoverageGroups;
DROP TABLE IF EXISTS dbo.IssueTypes;
DROP TABLE IF EXISTS dbo.Products;
GO
