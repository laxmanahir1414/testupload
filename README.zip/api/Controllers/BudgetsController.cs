using BudgetManagement.Api.Dtos;
using BudgetManagement.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace BudgetManagement.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BudgetsController : ControllerBase
{
    private readonly IBudgetService _service;

    public BudgetsController(IBudgetService service)
    {
        _service = service;
    }

    /// <summary>Product-wise budget grid, with search + filters.</summary>
    [HttpGet]
    public async Task<ActionResult<List<BudgetGridRowDto>>> GetGrid(
        [FromQuery] string? search,
        [FromQuery] int? productCode,
        [FromQuery] int? fyCode,
        [FromQuery] int? quarterCode,
        [FromQuery] string? stage)
    {
        var result = await _service.GetGridAsync(search, productCode, fyCode, quarterCode, stage);
        return Ok(result);
    }

    /// <summary>Quarter-wise Budget / Estimation / Actual detail for one Budget Code (used by the view modal).</summary>
    [HttpGet("{budgetCode}")]
    public async Task<ActionResult<BudgetDetailDto>> GetDetail(string budgetCode)
    {
        var result = await _service.GetDetailAsync(budgetCode);
        if (result == null) return NotFound(new { message = $"Budget Code '{budgetCode}' was not found." });
        return Ok(result);
    }

    /// <summary>Add a new Budget, or add/version an Estimation or Actual entry.</summary>
    [HttpPost("entry")]
    public async Task<ActionResult<SaveResultDto>> AddOrVersionEntry([FromBody] BudgetEntryInputDto input)
    {
        var result = await _service.AddOrVersionEntryAsync(input);
        if (!result.Success) return BadRequest(result);
        return Ok(result);
    }

    /// <summary>Bulk Excel upload — validates every row first; saves all rows only if all rows pass.</summary>
    [HttpPost("upload")]
    public async Task<ActionResult<BulkUploadResponseDto>> BulkUpload([FromBody] BulkUploadRequestDto request)
    {
        var result = await _service.BulkUploadAsync(request);
        return Ok(result); // 200 either way — the payload's Success flag + per-row errors drive the UI
    }

    /// <summary>
    /// Extract all Budget Codes for a Financial Year in template format, pre-filled
    /// with their current best-known figures (Estimation source for entryType=2,
    /// Actual source for entryType=3), ready to download as Excel, edit, and
    /// re-upload via POST /upload.
    /// </summary>
    [HttpGet("export")]
    public async Task<ActionResult<BudgetExportResponseDto>> ExportTemplate(
        [FromQuery] int entryType,
        [FromQuery] int fyCode,
        [FromQuery] int quarterCode)
    {
        var result = await _service.GetExportRowsAsync(entryType, fyCode, quarterCode);
        return Ok(result);
    }

    [HttpGet("export-with-reference")]
    public async Task<ActionResult<BudgetExportWithReferenceResponseDto>> ExportTemplateWithReference(
       [FromQuery] int entryType,
       [FromQuery] int fyCode,
       [FromQuery] int quarterCode)
    {
        var result = await _service.GetExportRowsWithReferenceAsync(entryType, fyCode, quarterCode);
        return Ok(result);
    }
}
