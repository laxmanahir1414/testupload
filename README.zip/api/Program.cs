using BudgetManagement.Api.Data;
using BudgetManagement.Api.Services;

var builder = WebApplication.CreateBuilder(args);

// ---- Services --------------------------------------------------------------------

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "Budget Management API",
        Version = "v1",
        Description = "No authentication — simple JSON in / JSON out API for the Budget Management demo. " +
                      "Data access is plain ADO.NET (Microsoft.Data.SqlClient) calling stored procedures defined " +
                      "in /database/03_StoredProcedures.sql — no EF Core, no LINQ-to-SQL, no ad-hoc SQL text in C#."
    });
});

builder.Services.AddSingleton<ISqlConnectionFactory, SqlConnectionFactory>();
builder.Services.AddSingleton<IBudgetRepository, BudgetRepository>();
builder.Services.AddScoped<IBudgetService, BudgetService>();

var allowedOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>()
                     ?? new[] { "http://localhost:4200" };

builder.Services.AddCors(options =>
{
    options.AddPolicy("AngularClient", policy =>
    {
        policy.WithOrigins(allowedOrigins)
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

var app = builder.Build();

// ---- DB: create database, run schema + stored-procedure + seed scripts ------------
// These are the real .sql files under Scripts/ (copied from /database at build time),
// not embedded C# strings. See Data/DbInitializer.cs.

var connectionString = app.Configuration.GetConnectionString("Default")
    ?? throw new InvalidOperationException("Missing 'ConnectionStrings:Default' in appsettings.json.");
var scriptsDirectory = Path.Combine(AppContext.BaseDirectory, "Scripts");

var skipDbInit = app.Configuration.GetValue<bool>("SkipDbInitOnStartup");
if (!skipDbInit)
{
    try
    {
        await DbInitializer.InitializeAsync(connectionString, scriptsDirectory);
    }
    catch (Exception ex)
    {
        app.Logger.LogError(ex,
            "Database initialization failed. Is SQL Server reachable with the connection string in appsettings.json? " +
            "You can also run /database/01_CreateDatabase.sql, 02_Tables.sql, 03_StoredProcedures.sql and " +
            "04_SeedData.sql by hand in SSMS, then set \"SkipDbInitOnStartup\": true in appsettings.json.");
        throw;
    }
}

// ---- Pipeline ----------------------------------------------------------------------

app.UseSwagger();
app.UseSwaggerUI(); // available at /swagger in every environment for this demo

app.UseCors("AngularClient");
app.UseAuthorization();
app.MapControllers();

app.Run();
