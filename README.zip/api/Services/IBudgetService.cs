using BudgetManagement.Api.Dtos;

namespace BudgetManagement.Api.Services;

public interface IBudgetService
{
    Task<List<LookupDto>> GetProductsAsync();
    Task<List<LookupDto>> GetIssueTypesAsync();
    Task<List<LookupDto>> GetIndustryGroupsAsync();
    Task<List<LookupDto>> GetFinancialYearsAsync();

    Task<List<BudgetGridRowDto>> GetGridAsync(string? search, int? productCode, int? fyCode, int? quarterCode, string? stage);
    Task<BudgetDetailDto?> GetDetailAsync(string budgetCode);

    Task<SaveResultDto> AddOrVersionEntryAsync(BudgetEntryInputDto input);
    Task<BulkUploadResponseDto> BulkUploadAsync(BulkUploadRequestDto request);

    /// <summary>
    /// Extract/export all Budget Codes in a Financial Year, pre-filled in template
    /// format with their current best-known figures, ready for the user to edit and
    /// re-upload as Estimation (entryType = 2) or Actual (entryType = 3).
    /// </summary>
    Task<BudgetExportResponseDto> GetExportRowsAsync(int entryType, int fyCode, int quarterCode);

    Task<BudgetExportWithReferenceResponseDto> GetExportRowsWithReferenceAsync(int entryType, int fyCode, int quarterCode);
}
