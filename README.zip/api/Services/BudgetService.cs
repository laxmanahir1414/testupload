using BudgetManagement.Api.Data;
using BudgetManagement.Api.Dtos;
using BudgetManagement.Api.Models;
using Microsoft.Data.SqlClient;

namespace BudgetManagement.Api.Services;

/// <summary>
/// All business rules and validation for Budget / Estimation / Actual entries live
/// here. Every actual read/write against SQL Server goes through
/// Data/BudgetRepository.cs, which calls stored procedures — there is no SQL text in
/// this file at all.
///
/// Core lifecycle rules implemented below (see BuildEntryAsync):
///  1. A Budget Code has exactly ONE Budget entry, ever, entered for any single
///     quarter chosen by the user ("Quarter-wise, budget is entered in any one
///     quarter"). Attempting a second Budget for the same code fails, and is also
///     rejected at the database level by a filtered unique index (defense in depth).
///  2. The FIRST entry ever made for a Budget Code is always a Budget. Estimation and
///     Actual both require an existing Budget baseline first.
///  3. After the Budget, every further entry for any quarter is an Estimation — until
///     an Actual is recorded for that specific quarter, at which point that quarter's
///     Estimation is locked (no further Estimation edits for that quarter).
///  4. Actual sequencing: the FIRST Actual ever recorded for a Budget Code may be
///     entered directly against the Budget (no Estimation required). Every Actual
///     recorded AFTER that first one requires an Estimation to already exist for that
///     specific quarter — i.e. once a Budget Code has "matured" past its first Actual,
///     all further quarters must be estimated before their Actual can be booked.
///  5. Fields left blank on an Estimation/Actual entry are imported from the previous
///     stage's saved values (Estimation ← Budget; Actual ← Estimation ← Budget).
///  6. Bulk Excel upload validates every row first; if any row fails, nothing is
///     saved (single all-or-nothing transaction) and every row's outcome is reported.
/// </summary>
public class BudgetService : IBudgetService
{
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly IBudgetRepository _repository;
    private static readonly string[] QuarterLabels = { "", "Q1", "Q2", "Q3", "Q4" };

    // SQL Server error numbers for unique-index / unique-constraint violations.
    private const int SqlErrorUniqueConstraint = 2627;
    private const int SqlErrorUniqueIndex = 2601;

    public BudgetService(ISqlConnectionFactory connectionFactory, IBudgetRepository repository)
    {
        _connectionFactory = connectionFactory;
        _repository = repository;
    }

    // ============================================================================
    // LOOKUPS
    // ============================================================================

    public async Task<List<LookupDto>> GetProductsAsync()
    {
        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();
        return await _repository.GetProductsAsync(conn, null);
    }

    public async Task<List<LookupDto>> GetIssueTypesAsync()
    {
        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();
        return await _repository.GetIssueTypesAsync(conn, null);
    }

    public async Task<List<LookupDto>> GetIndustryGroupsAsync()
    {
        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();
        return await _repository.GetIndustryGroupsAsync(conn, null);
    }

    public async Task<List<LookupDto>> GetFinancialYearsAsync()
    {
        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();
        return await _repository.GetFinancialYearsAsync(conn, null);
    }

    /// <summary>Case-insensitive name match against an already-loaded lookup list (no LINQ).</summary>
    private static int? FindLookupCodeByName(List<LookupDto> lookups, string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) return null;
        var trimmed = name.Trim();
        foreach (var l in lookups)
        {
            if (string.Equals(l.Name, trimmed, StringComparison.OrdinalIgnoreCase)) return l.Code;
        }
        return null;
    }

    // ============================================================================
    // GRID (product-wise budget list, with filter + search)
    // ============================================================================

    public async Task<List<BudgetGridRowDto>> GetGridAsync(string? search, int? productCode, int? fyCode, int? quarterCode, string? stage)
    {
        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();

        var all = await _repository.GetActiveEntriesAsync(conn, null, null);

        // group by BudgetCode manually
        var byCode = new Dictionary<string, List<BudgetEntry>>();
        foreach (var e in all)
        {
            if (!byCode.TryGetValue(e.BudgetCode, out var list))
            {
                list = new List<BudgetEntry>();
                byCode[e.BudgetCode] = list;
            }
            list.Add(e);
        }

        var result = new List<BudgetGridRowDto>();

        foreach (var pair in byCode)
        {
            var budgetCode = pair.Key;
            var entries = pair.Value;

            BudgetEntry? budget = null;
            BudgetEntry? estimation = null;
            var actuals = new List<BudgetEntry>();

            foreach (var e in entries)
            {
                if (e.EntryType == EntryType.Budget)
                {
                    if (budget == null || e.CreatedOn > budget.CreatedOn) budget = e;
                }
                else if (e.EntryType == EntryType.Estimation)
                {
                    if (estimation == null || e.CreatedOn > estimation.CreatedOn) estimation = e;
                }
                else
                {
                    actuals.Add(e);
                }
            }

            BudgetEntry? header = budget ?? estimation;
            if (header == null && actuals.Count > 0)
            {
                header = actuals[0];
                foreach (var a in actuals)
                {
                    if (a.CreatedOn > header.CreatedOn) header = a;
                }
            }
            if (header == null) continue;

            string rowStage = actuals.Count > 0 ? "Actual" : (estimation != null ? "Estimation" : "Budget");

            if (productCode.HasValue && header.ProductCode != productCode.Value) continue;
            if (fyCode.HasValue && header.FYCode != fyCode.Value) continue;

            if (quarterCode.HasValue)
            {
                bool hasQuarter = false;
                foreach (var e in entries)
                {
                    if (e.QuarterCode == quarterCode.Value) { hasQuarter = true; break; }
                }
                if (!hasQuarter) continue;
            }

            if (!string.IsNullOrWhiteSpace(stage) && !string.Equals(rowStage, stage, StringComparison.OrdinalIgnoreCase))
                continue;

            var projectOrCompany = string.IsNullOrWhiteSpace(header.ProjectName) ? header.CompanyName : header.ProjectName;

            if (!string.IsNullOrWhiteSpace(search))
            {
                var s = search.Trim().ToLowerInvariant();
                var hay = (budgetCode + " " + header.ProductName + " " + projectOrCompany + " " + header.IndustryName + " " + header.IssueType)
                    .ToLowerInvariant();
                if (!hay.Contains(s)) continue;
            }

            decimal? actualTotal = null;
            if (actuals.Count > 0)
            {
                decimal sum = 0m;
                foreach (var a in actuals) sum += a.Total;
                actualTotal = sum;
            }

            result.Add(new BudgetGridRowDto
            {
                BudgetCode = budgetCode,
                ProductName = header.ProductName,
                IssueType = header.IssueType,
                ProjectOrCompany = projectOrCompany,
                IndustryName = header.IndustryName,
                IndusCoverageGroupName = header.IndusCoverageGroupName,
                FYName = header.FYName,
                IsMandated = header.IsMandated,
                IndicativeDealSize = header.IndicativeDealSize,
                DealProbability = header.DealProbability,
                BudgetTotal = budget != null ? budget.Total : 0m,
                EstimationTotal = estimation != null ? estimation.Total : (decimal?)null,
                ActualTotal = actualTotal,
                Stage = rowStage
            });
        }

        // sort by BudgetCode descending — simple List.Sort with a comparator, no LINQ
        result.Sort((a, b) => string.CompareOrdinal(b.BudgetCode, a.BudgetCode));
        return result;
    }

    // ============================================================================
    // DETAIL (quarter-wise Budget / Estimation / Actual for one Budget Code)
    // ============================================================================

    public async Task<BudgetDetailDto?> GetDetailAsync(string budgetCode)
    {
        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();

        var entries = await _repository.GetActiveEntriesAsync(conn, null, budgetCode);
        if (entries.Count == 0) return null;

        BudgetEntry? budget = null;
        BudgetEntry? estimation = null;
        var actualsByQuarter = new Dictionary<int, BudgetEntry>();

        foreach (var e in entries)
        {
            if (e.EntryType == EntryType.Budget)
            {
                if (budget == null || e.CreatedOn > budget.CreatedOn) budget = e;
            }
            else if (e.EntryType == EntryType.Estimation)
            {
                if (estimation == null || e.CreatedOn > estimation.CreatedOn) estimation = e;
            }
            else
            {
                if (!actualsByQuarter.TryGetValue(e.QuarterCode, out var existing) || e.CreatedOn > existing.CreatedOn)
                    actualsByQuarter[e.QuarterCode] = e;
            }
        }

        BudgetEntry? header = budget ?? estimation;
        if (header == null)
        {
            header = entries[0];
            foreach (var e in entries)
            {
                if (e.CreatedOn > header.CreatedOn) header = e;
            }
        }

        var dto = new BudgetDetailDto
        {
            BudgetCode = budgetCode,
            ProductName = header.ProductName,
            IssueType = header.IssueType,
            ProjectName = header.ProjectName,
            CompanyName = header.CompanyName,
            IndustryName = header.IndustryName,
            IndusCoverageGroupName = header.IndusCoverageGroupName,
            FYName = header.FYName,
            IsMandated = header.IsMandated,
            IndicativeDealSize = header.IndicativeDealSize,
            EstimatedFeePool = header.EstimatedFeePool,
            TotalFees = header.TotalFees,
            NoOfBRLMs = header.NoOfBRLMs,
            JMFKeepRate = header.JMFKeepRate,
            JMFGrossFee = header.JMFGrossFee,
            DealProbability = header.DealProbability,
            JMProbability = header.JMProbability,
            ExpectedClosure = header.ExpectedClosure,
            BudgetTotal = budget != null ? budget.Total : 0m,
            EstimationTotal = estimation != null ? estimation.Total : 0m,
            ActualTotal = 0m
        };

        decimal actualTotalSum = 0m;
        foreach (var kvp in actualsByQuarter) actualTotalSum += kvp.Value.Total;
        dto.ActualTotal = actualTotalSum;

        for (int q = 1; q <= 4; q++)
        {
            decimal? budgetQ = budget != null ? GetQuarterValue(budget, q) : (decimal?)null;
            decimal? estimationQ = estimation != null ? GetQuarterValue(estimation, q) : (decimal?)null;
            bool hasActualQ = actualsByQuarter.TryGetValue(q, out var a);
            decimal? actualQ = hasActualQ ? a!.Total : (decimal?)null;

            dto.Quarters.Add(new QuarterFigureDto
            {
                QuarterCode = q,
                QuarterLabel = QuarterLabels[q],
                Budget = budgetQ,
                Estimation = estimationQ,
                Actual = actualQ,
                IsLocked = hasActualQ
            });
        }

        return dto;
    }

    private static decimal GetQuarterValue(BudgetEntry e, int quarter)
    {
        if (quarter == 1) return e.Q1;
        if (quarter == 2) return e.Q2;
        if (quarter == 3) return e.Q3;
        if (quarter == 4) return e.Q4;
        return 0m;
    }

    // ============================================================================
    // SINGLE ENTRY ADD / VERSION
    // ============================================================================

    public async Task<SaveResultDto> AddOrVersionEntryAsync(BudgetEntryInputDto input)
    {
        if (input.EntryType < 1 || input.EntryType > 3)
            return Fail("Invalid entry type. Use 1 = Budget, 2 = Estimation, 3 = Actual.");
        if (input.QuarterCode < 1 || input.QuarterCode > 4)
            return Fail("Invalid quarter. Use 1-4.");

        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();
        await using var tx = (SqlTransaction)await conn.BeginTransactionAsync();

        try
        {
            var fyName = await _repository.GetFinancialYearNameAsync(conn, tx, input.FYCode);
            if (fyName == null)
            {
                await tx.RollbackAsync();
                return Fail("Invalid financial year.");
            }

            var entryType = (EntryType)input.EntryType;
            var budgetCode = input.BudgetCode?.Trim();

            if (entryType == EntryType.Budget && string.IsNullOrEmpty(budgetCode))
            {
                budgetCode = await GenerateNextBudgetCodeAsync(conn, tx, input.FYCode);
            }

            if (string.IsNullOrEmpty(budgetCode))
            {
                await tx.RollbackAsync();
                return Fail("Budget Code is required for Estimation and Actual entries.");
            }

            var built = await BuildEntryAsync(
                conn, tx, budgetCode!, entryType, input.QuarterCode, input.FYCode, fyName, input.CreatedBy,
                input.ProductCode, input.ProdIssueTypeCode, input.IndusCGCode,
                input.ProjectName, input.CompanyName, input.IndustryName,
                input.IndicativeDealSize, input.EstimatedFeePool, input.TotalFees, input.NoOfBRLMs,
                input.JMFKeepRate, input.JMFGrossFee, input.DealProbability, input.JMProbability,
                input.ExpectedClosure, input.Q1, input.Q2, input.Q3, input.Q4, input.Amount,
                input.IsMandated, input.Remarks);

            if (!built.Ok)
            {
                await tx.RollbackAsync();
                return Fail(built.Error!);
            }

            var newId = await _repository.InsertEntryAsync(conn, tx, built.Entry!);
            built.Entry!.Id = newId;
            if (built.SupersedesId.HasValue)
            {
                await _repository.SupersedeAsync(conn, tx, built.SupersedesId.Value);
            }

            await tx.CommitAsync();
            return new SaveResultDto { Success = true, Message = $"{entryType} entry saved successfully.", BudgetCode = budgetCode };
        }
        catch (SqlException ex) when (ex.Number == SqlErrorUniqueConstraint || ex.Number == SqlErrorUniqueIndex)
        {
            await tx.RollbackAsync();
            return Fail("This Budget Code already has an active entry for that Entry Type / Quarter combination. No duplicate entries are allowed.");
        }
        catch
        {
            await tx.RollbackAsync();
            throw;
        }
    }

    // ============================================================================
    // BULK (EXCEL) UPLOAD — everything happens inside ONE transaction. Every row is
    // validated and (if valid) inserted; if ANY row failed, the whole transaction is
    // rolled back at the end so nothing is persisted ("no data saved if any row
    // fails") while still reporting every row's outcome.
    // ============================================================================

    public async Task<BulkUploadResponseDto> BulkUploadAsync(BulkUploadRequestDto request)
    {
        var response = new BulkUploadResponseDto();

        if (request.EntryType < 1 || request.EntryType > 3)
        {
            response.Success = false;
            response.Message = "Invalid entry type.";
            return response;
        }
        if (request.QuarterCode < 1 || request.QuarterCode > 4)
        {
            response.Success = false;
            response.Message = "Invalid quarter.";
            return response;
        }
        if (request.Rows == null || request.Rows.Count == 0)
        {
            response.Success = false;
            response.Message = "No rows found in the uploaded file.";
            return response;
        }

        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();
        await using var tx = (SqlTransaction)await conn.BeginTransactionAsync();

        try
        {
            var fyName = await _repository.GetFinancialYearNameAsync(conn, tx, request.FYCode);
            if (fyName == null)
            {
                await tx.RollbackAsync();
                response.Success = false;
                response.Message = "Invalid financial year.";
                return response;
            }

            var entryType = (EntryType)request.EntryType;

            // duplicate Budget Code check within this batch (manual loop, no LINQ GroupBy)
            var seenCodes = new Dictionary<string, int>();
            foreach (var row in request.Rows)
            {
                if (string.IsNullOrWhiteSpace(row.BudgetCode)) continue;
                var code = row.BudgetCode.Trim();
                seenCodes.TryGetValue(code, out var count);
                seenCodes[code] = count + 1;
            }

            var products = await _repository.GetProductsAsync(conn, tx);
            var issueTypes = await _repository.GetIssueTypesAsync(conn, tx);
            var groups = await _repository.GetIndustryGroupsAsync(conn, tx);

            // sort rows by RowNumber (manual sort with a comparator, no LINQ OrderBy)
            var sortedRows = new List<BulkUploadRowDto>(request.Rows);
            sortedRows.Sort((a, b) => a.RowNumber.CompareTo(b.RowNumber));

            var rowResults = new List<BulkUploadRowResultDto>();
            bool anyFailed = false;
            var baseTime = DateTime.UtcNow;
            int rowIndex = 0;

            foreach (var row in sortedRows)
            {
                rowIndex++;
                var budgetCode = row.BudgetCode?.Trim();
                string? err = null;

                // Only a brand-new Budget entry may leave the Budget Code blank
                // (it gets auto-generated); Estimation/Actual/edits must supply one.
                if (string.IsNullOrEmpty(budgetCode) && entryType != EntryType.Budget)
                    err = "Budget Code is required for Estimation and Actual rows.";
                else if (!string.IsNullOrEmpty(budgetCode) && seenCodes.TryGetValue(budgetCode, out var occurrences) && occurrences > 1)
                    err = "Duplicate Budget Code found in this Excel batch.";

                int? expectedClosureCode = ParseQuarterText(row.ExpectedClosure);
                if (err == null && row.ExpectedClosure != null && expectedClosureCode == null)
                    err = $"Expected Closure \"{row.ExpectedClosure}\" is not a valid quarter (Q1-Q4).";
                if (err == null && expectedClosureCode.HasValue && expectedClosureCode.Value < request.QuarterCode)
                    err = "Expected Closure quarter cannot be earlier than the entry quarter.";

                int? rowQuarterCode = ParseQuarterText(row.Quarter);
                if (err == null && rowQuarterCode.HasValue && rowQuarterCode.Value != request.QuarterCode)
                    err = $"Row Quarter ({row.Quarter}) does not match the selected upload quarter (Q{request.QuarterCode}).";

                int? productCode = null, issueTypeCode = null, indusCgCode = null;
                if (err == null && !string.IsNullOrWhiteSpace(row.Product))
                {
                    productCode = FindLookupCodeByName(products, row.Product);
                    if (productCode == null) err = $"Product \"{row.Product}\" was not found in the Product master.";
                }
                if (err == null && !string.IsNullOrWhiteSpace(row.IssueType))
                {
                    issueTypeCode = FindLookupCodeByName(issueTypes, row.IssueType);
                    if (issueTypeCode == null) err = $"Issue Type \"{row.IssueType}\" was not found in the Issue Type master.";
                }
                if (err == null && !string.IsNullOrWhiteSpace(row.IndusCoverageGroup))
                {
                    indusCgCode = FindLookupCodeByName(groups, row.IndusCoverageGroup);
                    if (indusCgCode == null) err = $"Indus Coverage Group \"{row.IndusCoverageGroup}\" was not found in the master.";
                }

                if (err == null && entryType == EntryType.Budget)
                {
                    if (productCode == null) err = "Product is required for a new Budget entry.";
                    else if (issueTypeCode == null) err = "Issue Type is required for a new Budget entry.";
                    else if (indusCgCode == null) err = "Indus Coverage Group is required for a new Budget entry.";
                    else if (string.IsNullOrWhiteSpace(row.ProjectName) && string.IsNullOrWhiteSpace(row.MandatedCompany))
                        err = "Project Name or Mandated Company is required.";
                }

                if (err == null && row.DealProbability.HasValue && (row.DealProbability.Value < 0 || row.DealProbability.Value > 100))
                    err = "Deal Probability (%) must be between 0 and 100.";
                if (err == null && row.JMProbability.HasValue && (row.JMProbability.Value < 0 || row.JMProbability.Value > 100))
                    err = "JM Probability (%) must be between 0 and 100.";
                if (err == null && row.IndicativeDealSize.HasValue && row.IndicativeDealSize.Value < 0)
                    err = "Indicative Deal Size cannot be negative.";

                bool isMandated = false;
                if (!string.IsNullOrEmpty(row.PitchedOrMandated) && row.PitchedOrMandated.ToLowerInvariant().Contains("mandat"))
                    isMandated = true;

                if (err == null)
                {
                    decimal? amount = row.Amount.HasValue ? row.Amount : row.Total;

                    if (entryType == EntryType.Budget && string.IsNullOrEmpty(budgetCode))
                    {
                        budgetCode = await GenerateNextBudgetCodeAsync(conn, tx, request.FYCode);
                    }

                    var built = await BuildEntryAsync(
                        conn, tx, budgetCode!, entryType, request.QuarterCode, request.FYCode, fyName, request.CreatedBy,
                        productCode, issueTypeCode, indusCgCode,
                        row.ProjectName, row.MandatedCompany, row.Industry,
                        row.IndicativeDealSize, row.EstimatedFeePool, row.TotalFees, row.NoOfBRLMs,
                        row.JMFKeepRate, row.JMFGrossFee, row.DealProbability, row.JMProbability,
                        expectedClosureCode, row.Q1, row.Q2, row.Q3, row.Q4, amount,
                        isMandated, null,
                        baseTime.AddTicks(rowIndex)); // strictly increasing CreatedOn within this batch

                    if (!built.Ok)
                    {
                        err = built.Error;
                    }
                    else
                    {
                        var newId = await _repository.InsertEntryAsync(conn, tx, built.Entry!);
                        built.Entry!.Id = newId;
                        if (built.SupersedesId.HasValue)
                        {
                            await _repository.SupersedeAsync(conn, tx, built.SupersedesId.Value);
                        }
                    }
                }

                if (err != null)
                {
                    anyFailed = true;
                    rowResults.Add(new BulkUploadRowResultDto { RowNumber = row.RowNumber, BudgetCode = budgetCode, Success = false, ErrorMessage = err });
                }
                else
                {
                    rowResults.Add(new BulkUploadRowResultDto { RowNumber = row.RowNumber, BudgetCode = budgetCode, Success = true });
                }
            }

            if (anyFailed)
            {
                await tx.RollbackAsync();
                response.Success = false;
                response.Message = "Excel validation failed. No Budget, Estimation or Actual records were saved.";
                response.Rows = rowResults;
                return response;
            }

            await tx.CommitAsync();
            response.Success = true;
            response.Message = $"All {rowResults.Count} row(s) saved successfully.";
            response.Rows = rowResults;
            return response;
        }
        catch (SqlException ex) when (ex.Number == SqlErrorUniqueConstraint || ex.Number == SqlErrorUniqueIndex)
        {
            await tx.RollbackAsync();
            response.Success = false;
            response.Message = "One or more rows duplicate an existing active entry (same Budget Code + Entry Type + Quarter). No rows were saved.";
            return response;
        }
        catch (Exception ex)
        {
            await tx.RollbackAsync();
            response.Success = false;
            response.Message = "Bulk save failed: " + ex.Message;
            return response;
        }
    }

    // ============================================================================
    // EXTRACT / EXPORT (Excel prep for Estimation / Actual)
    // ============================================================================

    public async Task<BudgetExportResponseDto> GetExportRowsAsync(int entryType, int fyCode, int quarterCode)
    {
        var response = new BudgetExportResponseDto();

        if (entryType != (int)EntryType.Estimation && entryType != (int)EntryType.Actual)
        {
            response.Message = "Extract is only available when preparing an Estimation or Actual upload.";
            return response;
        }
        if (quarterCode < 1 || quarterCode > 4)
        {
            response.Message = "Invalid quarter.";
            return response;
        }

        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();

        var allActive = await _repository.GetActiveEntriesAsync(conn, null, null);

        var byCode = new Dictionary<string, List<BudgetEntry>>();
        foreach (var e in allActive)
        {
            if (e.FYCode != fyCode) continue;
            if (!byCode.TryGetValue(e.BudgetCode, out var list))
            {
                list = new List<BudgetEntry>();
                byCode[e.BudgetCode] = list;
            }
            list.Add(e);
        }

        var codes = new List<string>(byCode.Keys);
        codes.Sort(string.CompareOrdinal);

        var targetType = (EntryType)entryType;
        var rows = new List<BulkUploadRowDto>();
        int rowNum = 1;

        foreach (var code in codes)
        {
            var entries = byCode[code];

            BudgetEntry? latestBudget = null;
            foreach (var e in entries)
            {
                if (e.EntryType == EntryType.Budget && (latestBudget == null || e.CreatedOn > latestBudget.CreatedOn))
                    latestBudget = e;
            }
            // A Budget Code with no Budget baseline yet has nothing to extract for Estimation/Actual prep.
            if (latestBudget == null) continue;

            BudgetEntry? priorSameStageThisQuarter = null;
            foreach (var e in entries)
            {
                if (e.EntryType == targetType && e.QuarterCode == quarterCode &&
                    (priorSameStageThisQuarter == null || e.CreatedOn > priorSameStageThisQuarter.CreatedOn))
                    priorSameStageThisQuarter = e;
            }

            BudgetEntry? source = priorSameStageThisQuarter;
            if (source == null)
            {
                if (targetType == EntryType.Estimation)
                {
                    source = latestBudget;
                }
                else // Actual: prefer this quarter's Estimation, else fall back to the Budget
                {
                    BudgetEntry? est = null;
                    foreach (var e in entries)
                    {
                        if (e.EntryType == EntryType.Estimation && e.QuarterCode == quarterCode &&
                            (est == null || e.CreatedOn > est.CreatedOn))
                            est = e;
                    }
                    source = est ?? latestBudget;
                }
            }

            rows.Add(MapToTemplateRow(rowNum, code, source, quarterCode));
            rowNum++;
        }

        var stageName = targetType == EntryType.Estimation ? "Estimation" : "Actual";
        response.Message = rows.Count == 0
            ? "No Budget Codes with an existing Budget entry were found for this Financial Year."
            : $"{rows.Count} Budget Code(s) extracted in {stageName} template format for Q{quarterCode}. Edit the figures and upload this file back as {stageName}.";
        response.Rows = rows;
        return response;
    }

    private static BulkUploadRowDto MapToTemplateRow(int rowNumber, string budgetCode, BudgetEntry source, int quarterCode)
    {
        var closureQuarter = source.ExpectedClosure >= 1 && source.ExpectedClosure <= 4 ? source.ExpectedClosure : quarterCode;
        return new BulkUploadRowDto
        {
            RowNumber = rowNumber,
            BudgetCode = budgetCode,
            IndusCoverageGroup = source.IndusCoverageGroupName,
            PitchedOrMandated = source.IsMandated ? "Mandated" : "Pitched",
            ProjectName = source.ProjectName,
            MandatedCompany = source.CompanyName,
            Industry = source.IndustryName,
            Product = source.ProductName,
            IssueType = source.IssueType,
            IndicativeDealSize = source.IndicativeDealSize,
            EstimatedFeePool = source.EstimatedFeePool,
            TotalFees = source.TotalFees,
            NoOfBRLMs = source.NoOfBRLMs,
            JMFKeepRate = source.JMFKeepRate,
            JMFGrossFee = source.JMFGrossFee,
            DealProbability = source.DealProbability,
            JMProbability = source.JMProbability,
            ExpectedClosure = "Q" + closureQuarter,
            Q1 = source.Q1,
            Q2 = source.Q2,
            Q3 = source.Q3,
            Q4 = source.Q4,
            Total = source.Total,
            Quarter = "Q" + quarterCode,
            Amount = source.Amount
        };
    }

    // ============================================================================
    // SHARED: build a ready-to-insert BudgetEntry, applying versioning + import-forward
    // of defaults from the previous stage, and enforcing the Budget -> Estimation ->
    // Actual lifecycle rules. Read-only against the DB (via conn/tx) — the caller
    // decides whether/when to actually persist it.
    // ============================================================================

    private async Task<BuildResult> BuildEntryAsync(
        SqlConnection conn, SqlTransaction tx,
        string budgetCode, EntryType entryType, int quarterCode, int fyCode, string fyName, int createdBy,
        int? productCode, int? issueTypeCode, int? indusCgCode,
        string? projectName, string? companyName, string? industryName,
        decimal? dealSize, decimal? feePool, decimal? totalFees, int? noOfBRLMs,
        decimal? jmfKeepRate, decimal? jmfGrossFee, decimal? dealProbability, decimal? jmProbability,
        int? expectedClosure, decimal? q1, decimal? q2, decimal? q3, decimal? q4, decimal? amount,
        bool? isMandated, string? remarks,
        DateTime? createdOnOverride = null)
    {
        var latestBudget = await _repository.GetLatestActiveEntryAsync(conn, tx, budgetCode, EntryType.Budget, null);
        var priorSameStage = await _repository.GetLatestActiveEntryAsync(conn, tx, budgetCode, entryType, quarterCode);

        // ---- business rules -------------------------------------------------------
        if (entryType == EntryType.Budget)
        {
            // Rule 1 & 2: exactly one Budget entry per Budget Code, ever.
            if (latestBudget != null && priorSameStage == null)
                return BuildResult.Fail("A Budget entry already exists for this Budget Code. Budget can only be entered once per financial year; use Estimation for later revisions.");
        }
        else if (entryType == EntryType.Estimation)
        {
            // Rule 3: Estimation always requires an existing Budget first.
            if (latestBudget == null)
                return BuildResult.Fail("Budget Code does not have an existing Budget entry. Estimation requires a Budget first.");

            var actualForQuarter = await _repository.GetLatestActiveEntryAsync(conn, tx, budgetCode, EntryType.Actual, quarterCode);
            if (actualForQuarter != null)
                return BuildResult.Fail("Actual already exists for this quarter; Estimation can no longer be edited.");
        }
        else // Actual
        {
            // Rule 4: Actual always requires an existing Budget baseline.
            if (latestBudget == null)
                return BuildResult.Fail("Budget Code does not have an existing Budget entry. Actual requires a Budget baseline.");

            if (priorSameStage == null) // this is the first Actual for THIS quarter (not an edit/version of an existing one)
            {
                bool anyActualEverForCode = await _repository.HasAnyActualEverAsync(conn, tx, budgetCode);
                if (anyActualEverForCode)
                {
                    // An Actual has already been recorded for this Budget Code (in some
                    // quarter) previously — from now on every further Actual must be
                    // preceded by an Estimation for that specific quarter.
                    var estimationForQuarter = await _repository.GetLatestActiveEntryAsync(conn, tx, budgetCode, EntryType.Estimation, quarterCode);
                    if (estimationForQuarter == null)
                        return BuildResult.Fail("An Actual has already been recorded for this Budget Code. An Estimation must be entered for this quarter before its Actual can be recorded.");
                }
                // else: this is the very first Actual ever for this Budget Code —
                // allowed directly against the Budget, no Estimation required yet.
            }
        }

        // ---- resolve "import defaults from" source --------------------------------
        BudgetEntry? source = await ResolveImportSourceAsync(conn, tx, budgetCode, entryType, quarterCode, latestBudget, priorSameStage);

        if (source == null && entryType != EntryType.Budget)
            return BuildResult.Fail("Could not resolve a source entry to import defaults from.");

        if (source == null && entryType == EntryType.Budget)
        {
            if (productCode == null) return BuildResult.Fail("Product is required for a new Budget entry.");
            if (issueTypeCode == null) return BuildResult.Fail("Issue Type is required for a new Budget entry.");
            if (indusCgCode == null) return BuildResult.Fail("Indus Coverage Group is required for a new Budget entry.");
            if (string.IsNullOrWhiteSpace(projectName) && string.IsNullOrWhiteSpace(companyName))
                return BuildResult.Fail("Either Project Name or Mandated Company is required.");
        }

        string? productName = productCode.HasValue ? await _repository.GetProductNameAsync(conn, tx, productCode.Value) : null;
        string? issueTypeName = issueTypeCode.HasValue ? await _repository.GetIssueTypeNameAsync(conn, tx, issueTypeCode.Value) : null;
        string? indusCgName = indusCgCode.HasValue ? await _repository.GetIndusGroupNameAsync(conn, tx, indusCgCode.Value) : null;

        var entry = new BudgetEntry
        {
            BudgetCode = budgetCode,
            EntryType = entryType,
            QuarterCode = quarterCode,
            FYCode = fyCode,
            FYName = fyName,
            CreatedBy = createdBy,
            CreatedOn = createdOnOverride ?? DateTime.UtcNow,
            IsActive = true,

            ProductCode = productCode ?? (source != null ? source.ProductCode : 0),
            ProductName = productName ?? (source != null ? source.ProductName : ""),
            IssueType = issueTypeName ?? (source != null ? source.IssueType : ""),
            IndusCoverageGroupCode = indusCgCode ?? (source != null ? source.IndusCoverageGroupCode : 0),
            IndusCoverageGroupName = indusCgName ?? (source != null ? source.IndusCoverageGroupName : ""),

            ProjectName = !string.IsNullOrWhiteSpace(projectName) ? projectName.Trim() : (source != null ? source.ProjectName : ""),
            CompanyName = !string.IsNullOrWhiteSpace(companyName) ? companyName.Trim() : (source != null ? source.CompanyName : ""),
            IndustryName = !string.IsNullOrWhiteSpace(industryName) ? industryName.Trim() : (source != null ? source.IndustryName : ""),

            IndicativeDealSize = dealSize ?? (source != null ? source.IndicativeDealSize : 0),
            EstimatedFeePool = feePool ?? (source != null ? source.EstimatedFeePool : 0),
            TotalFees = totalFees ?? (source != null ? source.TotalFees : 0),
            NoOfBRLMs = noOfBRLMs ?? (source != null ? source.NoOfBRLMs : 0),
            JMFKeepRate = jmfKeepRate ?? (source != null ? source.JMFKeepRate : 0),
            JMFGrossFee = jmfGrossFee ?? (source != null ? source.JMFGrossFee : 0),
            DealProbability = dealProbability ?? (source != null ? source.DealProbability : 0),
            JMProbability = jmProbability ?? (source != null ? source.JMProbability : 0),
            ExpectedClosure = expectedClosure ?? (source != null ? source.ExpectedClosure : quarterCode),
            IsMandated = isMandated ?? (source != null && source.IsMandated),
            Remarks = remarks ?? (source != null ? source.Remarks : ""),
            Amount = amount ?? (source != null ? source.Amount : 0)
        };

        if (entryType == EntryType.Actual)
        {
            entry.Q1 = source != null ? source.Q1 : 0;
            entry.Q2 = source != null ? source.Q2 : 0;
            entry.Q3 = source != null ? source.Q3 : 0;
            entry.Q4 = source != null ? source.Q4 : 0;

            decimal actualValue = amount ?? ((q1 ?? 0) + (q2 ?? 0) + (q3 ?? 0) + (q4 ?? 0));
            if (quarterCode == 1) entry.Q1 = actualValue;
            else if (quarterCode == 2) entry.Q2 = actualValue;
            else if (quarterCode == 3) entry.Q3 = actualValue;
            else if (quarterCode == 4) entry.Q4 = actualValue;
            entry.Total = actualValue;
        }
        else
        {
            entry.Q1 = q1 ?? (source != null ? source.Q1 : 0);
            entry.Q2 = q2 ?? (source != null ? source.Q2 : 0);
            entry.Q3 = q3 ?? (source != null ? source.Q3 : 0);
            entry.Q4 = q4 ?? (source != null ? source.Q4 : 0);
            entry.Total = entry.Q1 + entry.Q2 + entry.Q3 + entry.Q4;
        }

        return BuildResult.Success(entry, priorSameStage?.Id);
    }

    /// <summary>
    /// Shared "import defaults from" resolver, used both when actually creating an
    /// entry (BuildEntryAsync) and when preparing an Excel extract (GetExportRowsAsync)
    /// — keeps the two flows perfectly in sync.
    /// </summary>
    private async Task<BudgetEntry?> ResolveImportSourceAsync(
        SqlConnection conn, SqlTransaction? tx, string budgetCode, EntryType entryType, int quarterCode,
        BudgetEntry? latestBudget, BudgetEntry? priorSameStage)
    {
        if (priorSameStage != null) return priorSameStage;

        if (entryType == EntryType.Estimation)
            return latestBudget;

        if (entryType == EntryType.Actual)
        {
            var estimationForQuarter = await _repository.GetLatestActiveEntryAsync(conn, tx, budgetCode, EntryType.Estimation, quarterCode);
            return estimationForQuarter ?? latestBudget;
        }

        return null; // Budget with no prior version — caller supplies all fields
    }

    private sealed class BuildResult
    {
        public bool Ok { get; private init; }
        public string? Error { get; private init; }
        public BudgetEntry? Entry { get; private init; }
        public int? SupersedesId { get; private init; }

        public static BuildResult Fail(string error) => new() { Ok = false, Error = error };
        public static BuildResult Success(BudgetEntry entry, int? supersedesId) => new() { Ok = true, Entry = entry, SupersedesId = supersedesId };
    }

    // ============================================================================
    // SMALL HELPERS
    // ============================================================================

    private async Task<string> GenerateNextBudgetCodeAsync(SqlConnection conn, SqlTransaction tx, int fyCode)
    {
        var nextSeq = await _repository.GetNextBudgetSequenceAsync(conn, tx, fyCode);
        return $"BUD-FY{fyCode}-{nextSeq:D5}";
    }

    private static int? ParseQuarterText(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        var t = text.Trim().ToUpperInvariant();
        if (t == "Q1" || t == "1") return 1;
        if (t == "Q2" || t == "2") return 2;
        if (t == "Q3" || t == "3") return 3;
        if (t == "Q4" || t == "4") return 4;
        return null;
    }

    private static SaveResultDto Fail(string message) => new() { Success = false, Message = message };

    public async Task<BudgetExportWithReferenceResponseDto> GetExportRowsWithReferenceAsync(int entryType, int fyCode, int quarterCode)
    {
        var response = new BudgetExportWithReferenceResponseDto();

        if (entryType != (int)EntryType.Estimation && entryType != (int)EntryType.Actual)
        {
            response.Message = "Extract is only available when preparing an Estimation or Actual upload.";
            return response;
        }
        if (quarterCode < 1 || quarterCode > 4)
        {
            response.Message = "Invalid quarter.";
            return response;
        }

        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();

        var allActive = await _repository.GetActiveEntriesAsync(conn, null, null);

        var byCode = new Dictionary<string, List<BudgetEntry>>();
        foreach (var e in allActive)
        {
            if (e.FYCode != fyCode) continue;
            if (!byCode.TryGetValue(e.BudgetCode, out var list))
            {
                list = new List<BudgetEntry>();
                byCode[e.BudgetCode] = list;
            }
            list.Add(e);
        }

        var codes = new List<string>(byCode.Keys);
        codes.Sort(string.CompareOrdinal);

        var targetType = (EntryType)entryType;
        var rows = new List<BulkUploadRowWithReferenceDto>();
        int rowNum = 1;

        foreach (var code in codes)
        {
            var entries = byCode[code];

            BudgetEntry? latestBudget = null;
            BudgetEntry? estimationForQuarter = null;
            BudgetEntry? actualForQuarter = null;

            foreach (var e in entries)
            {
                if (e.EntryType == EntryType.Budget && (latestBudget == null || e.CreatedOn > latestBudget.CreatedOn))
                    latestBudget = e;
                if (e.EntryType == EntryType.Estimation && e.QuarterCode == quarterCode &&
                    (estimationForQuarter == null || e.CreatedOn > estimationForQuarter.CreatedOn))
                    estimationForQuarter = e;
                if (e.EntryType == EntryType.Actual && e.QuarterCode == quarterCode &&
                    (actualForQuarter == null || e.CreatedOn > actualForQuarter.CreatedOn))
                    actualForQuarter = e;
            }

            if (latestBudget == null) continue; // nothing to extract without a Budget baseline

            BudgetEntry? priorSameStageThisQuarter = targetType == EntryType.Estimation ? estimationForQuarter : actualForQuarter;
            BudgetEntry? source = priorSameStageThisQuarter
                ?? (targetType == EntryType.Estimation ? latestBudget : (estimationForQuarter ?? latestBudget));

            // Per your requirement:
            //  - Estimation export -> reference columns = Budget (first entry) + Actual
            //  - Actual export     -> reference columns = Budget (first entry) + Estimation
            BudgetEntry? refActual = targetType == EntryType.Estimation ? actualForQuarter : null;
            BudgetEntry? refEstimation = targetType == EntryType.Actual ? estimationForQuarter : null;

            var closureQuarter = source.ExpectedClosure >= 1 && source.ExpectedClosure <= 4 ? source.ExpectedClosure : quarterCode;
            var dto = new BulkUploadRowWithReferenceDto
            {
                RowNumber = rowNum,
                BudgetCode = code,
                IndusCoverageGroup = source.IndusCoverageGroupName,
                PitchedOrMandated = source.IsMandated ? "Mandated" : "Pitched",
                ProjectName = source.ProjectName,
                MandatedCompany = source.CompanyName,
                Industry = source.IndustryName,
                Product = source.ProductName,
                IssueType = source.IssueType,
                IndicativeDealSize = source.IndicativeDealSize,
                EstimatedFeePool = source.EstimatedFeePool,
                TotalFees = source.TotalFees,
                NoOfBRLMs = source.NoOfBRLMs,
                JMFKeepRate = source.JMFKeepRate,
                JMFGrossFee = source.JMFGrossFee,
                DealProbability = source.DealProbability,
                JMProbability = source.JMProbability,
                ExpectedClosure = "Q" + closureQuarter,
                Q1 = source.Q1,
                Q2 = source.Q2,
                Q3 = source.Q3,
                Q4 = source.Q4,
                Total = source.Total,
                Quarter = "Q" + quarterCode,
                Amount = source.Amount,

                RefBudgetQ1 = latestBudget.Q1,
                RefBudgetQ2 = latestBudget.Q2,
                RefBudgetQ3 = latestBudget.Q3,
                RefBudgetQ4 = latestBudget.Q4,
                RefBudgetTotal = latestBudget.Total
            };

            if (refEstimation != null)
            {
                dto.RefEstimationQ1 = refEstimation.Q1;
                dto.RefEstimationQ2 = refEstimation.Q2;
                dto.RefEstimationQ3 = refEstimation.Q3;
                dto.RefEstimationQ4 = refEstimation.Q4;
                dto.RefEstimationTotal = refEstimation.Total;
            }
            if (refActual != null)
            {
                dto.RefActualQ1 = refActual.Q1;
                dto.RefActualQ2 = refActual.Q2;
                dto.RefActualQ3 = refActual.Q3;
                dto.RefActualQ4 = refActual.Q4;
                dto.RefActualTotal = refActual.Total;
            }

            rows.Add(dto);
            rowNum++;
        }

        var stageName = targetType == EntryType.Estimation ? "Estimation" : "Actual";
        var refStageName = targetType == EntryType.Estimation ? "Actual" : "Estimation";
        response.Message = rows.Count == 0
            ? "No Budget Codes with an existing Budget entry were found for this Financial Year."
            : $"{rows.Count} Budget Code(s) extracted in {stageName} template format for Q{quarterCode}, with Budget and {refStageName} shown for reference.";
        response.Rows = rows;
        return response;
    }
}
