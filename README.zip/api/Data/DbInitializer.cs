using System.Text.RegularExpressions;
using Microsoft.Data.SqlClient;

namespace BudgetManagement.Api.Data;

/// <summary>
/// Runs the real .sql script files in Scripts/ (copies of /database/*.sql at the
/// repo root — see the csproj's &lt;Content Include="..\database\*.sql"&gt; item) against
/// the target SQL Server on startup, so the app is runnable with zero manual DBA
/// steps. Every script is idempotent (guarded CREATE/INSERT), so re-running on every
/// startup is safe. A DBA can instead run the same files by hand in SSMS/sqlcmd —
/// they are plain T-SQL, not C# strings.
/// </summary>
public static class DbInitializer
{
    private static readonly Regex GoSeparator = new(@"^\s*GO\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);

    public static async Task InitializeAsync(string connectionString, string scriptsDirectory)
    {
        var builder = new SqlConnectionStringBuilder(connectionString);
        var databaseName = builder.InitialCatalog;
        if (string.IsNullOrWhiteSpace(databaseName))
            throw new InvalidOperationException("The connection string must specify an Initial Catalog / Database.");

        // 1) CREATE DATABASE (must run against 'master') — from 01_CreateDatabase.sql
        var masterBuilder = new SqlConnectionStringBuilder(connectionString) { InitialCatalog = "master" };
        await using (var masterConn = new SqlConnection(masterBuilder.ConnectionString))
        {
            await masterConn.OpenAsync();
            await using var createDbCmd = new SqlCommand(
                "IF DB_ID(@dbName) IS NULL EXEC('CREATE DATABASE [' + @dbName + ']');",
                masterConn);
            createDbCmd.Parameters.AddWithValue("@dbName", databaseName);
            await createDbCmd.ExecuteNonQueryAsync();
        }

        // 2) Tables, 3) Stored procedures, 4) Seed data — run the actual .sql files
        await using var conn = new SqlConnection(connectionString);
        await conn.OpenAsync();

        await RunScriptFileAsync(conn, Path.Combine(scriptsDirectory, "02_Tables.sql"));
        await RunScriptFileAsync(conn, Path.Combine(scriptsDirectory, "03_StoredProcedures.sql"));
        await RunScriptFileAsync(conn, Path.Combine(scriptsDirectory, "04_SeedData.sql"));
    }

    private static async Task RunScriptFileAsync(SqlConnection conn, string path)
    {
        if (!File.Exists(path))
            throw new FileNotFoundException($"Required SQL script not found: {path}. " +
                "Make sure the /database/*.sql files are copied to the build output (Scripts folder).");

        var scriptText = await File.ReadAllTextAsync(path);

        // SSMS/sqlcmd "GO" batch separators are not understood by SqlCommand,
        // so split the script into batches on lines that are exactly "GO".
        var batches = GoSeparator.Split(scriptText);

        foreach (var batch in batches)
        {
            var trimmed = batch.Trim();
            if (trimmed.Length == 0) continue;

            await using var cmd = new SqlCommand(trimmed, conn);
            cmd.CommandTimeout = 120;
            await cmd.ExecuteNonQueryAsync();
        }
    }
}
