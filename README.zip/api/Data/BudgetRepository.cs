using System.Data;
using BudgetManagement.Api.Dtos;
using BudgetManagement.Api.Models;
using Microsoft.Data.SqlClient;

namespace BudgetManagement.Api.Data;

/// <summary>
/// The ONLY class in this project that talks to SQL Server. Every method calls a
/// stored procedure defined in /database/03_StoredProcedures.sql via plain ADO.NET
/// (SqlCommand with CommandType.StoredProcedure + parameterized SqlParameters).
/// There is no ad-hoc SQL text here, no Entity Framework, no LINQ-to-SQL.
/// All business rule / validation logic lives in Services/BudgetService.cs — this
/// class only reads and writes rows.
/// </summary>
public interface IBudgetRepository
{
    Task<List<LookupDto>> GetProductsAsync(SqlConnection conn, SqlTransaction? tx);
    Task<List<LookupDto>> GetIssueTypesAsync(SqlConnection conn, SqlTransaction? tx);
    Task<List<LookupDto>> GetIndustryGroupsAsync(SqlConnection conn, SqlTransaction? tx);
    Task<List<LookupDto>> GetFinancialYearsAsync(SqlConnection conn, SqlTransaction? tx);

    Task<string?> GetFinancialYearNameAsync(SqlConnection conn, SqlTransaction? tx, int fyCode);
    Task<string?> GetProductNameAsync(SqlConnection conn, SqlTransaction? tx, int code);
    Task<string?> GetIssueTypeNameAsync(SqlConnection conn, SqlTransaction? tx, int code);
    Task<string?> GetIndusGroupNameAsync(SqlConnection conn, SqlTransaction? tx, int code);

    Task<List<BudgetEntry>> GetActiveEntriesAsync(SqlConnection conn, SqlTransaction? tx, string? budgetCode);
    Task<BudgetEntry?> GetLatestActiveEntryAsync(SqlConnection conn, SqlTransaction? tx, string budgetCode, EntryType entryType, int? quarterCode);
    Task<bool> HasAnyActualEverAsync(SqlConnection conn, SqlTransaction? tx, string budgetCode);
    Task<int> GetNextBudgetSequenceAsync(SqlConnection conn, SqlTransaction? tx, int fyCode);

    Task<int> InsertEntryAsync(SqlConnection conn, SqlTransaction tx, BudgetEntry entry);
    Task SupersedeAsync(SqlConnection conn, SqlTransaction tx, int id);
}

public class BudgetRepository : IBudgetRepository
{
    // ---------------------------------------------------------------- lookups

    public Task<List<LookupDto>> GetProductsAsync(SqlConnection conn, SqlTransaction? tx) =>
        LoadLookupAsync(conn, tx, "dbo.usp_Products_GetAll");

    public Task<List<LookupDto>> GetIssueTypesAsync(SqlConnection conn, SqlTransaction? tx) =>
        LoadLookupAsync(conn, tx, "dbo.usp_IssueTypes_GetAll");

    public Task<List<LookupDto>> GetIndustryGroupsAsync(SqlConnection conn, SqlTransaction? tx) =>
        LoadLookupAsync(conn, tx, "dbo.usp_IndustryGroups_GetAll");

    public async Task<List<LookupDto>> GetFinancialYearsAsync(SqlConnection conn, SqlTransaction? tx)
    {
        var result = new List<LookupDto>();
        await using var cmd = NewProcCommand(conn, tx, "dbo.usp_FinancialYears_GetAll");
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new LookupDto(reader.GetInt32(0), reader.GetString(1)));
        }
        return result;
    }

    private static async Task<List<LookupDto>> LoadLookupAsync(SqlConnection conn, SqlTransaction? tx, string procName)
    {
        var result = new List<LookupDto>();
        await using var cmd = NewProcCommand(conn, tx, procName);
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new LookupDto(reader.GetInt32(0), reader.GetString(1)));
        }
        return result;
    }

    public async Task<string?> GetFinancialYearNameAsync(SqlConnection conn, SqlTransaction? tx, int fyCode)
    {
        await using var cmd = NewProcCommand(conn, tx, "dbo.usp_FinancialYear_GetByCode");
        cmd.Parameters.AddWithValue("@FYCode", fyCode);
        await using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync()) return reader.GetString(reader.GetOrdinal("Name"));
        return null;
    }

    public async Task<string?> GetProductNameAsync(SqlConnection conn, SqlTransaction? tx, int code)
    {
        await using var cmd = NewProcCommand(conn, tx, "dbo.usp_Product_GetByCode");
        cmd.Parameters.AddWithValue("@Code", code);
        await using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync()) return reader.GetString(reader.GetOrdinal("Name"));
        return null;
    }

    public async Task<string?> GetIssueTypeNameAsync(SqlConnection conn, SqlTransaction? tx, int code)
    {
        await using var cmd = NewProcCommand(conn, tx, "dbo.usp_IssueType_GetByCode");
        cmd.Parameters.AddWithValue("@Code", code);
        await using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync()) return reader.GetString(reader.GetOrdinal("Name"));
        return null;
    }

    public async Task<string?> GetIndusGroupNameAsync(SqlConnection conn, SqlTransaction? tx, int code)
    {
        await using var cmd = NewProcCommand(conn, tx, "dbo.usp_IndusGroup_GetByCode");
        cmd.Parameters.AddWithValue("@Code", code);
        await using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync()) return reader.GetString(reader.GetOrdinal("Name"));
        return null;
    }

    // ---------------------------------------------------------------- budget entries: reads

    public async Task<List<BudgetEntry>> GetActiveEntriesAsync(SqlConnection conn, SqlTransaction? tx, string? budgetCode)
    {
        await using var cmd = NewProcCommand(conn, tx, "dbo.usp_BudgetEntries_GetActiveAll");
        cmd.Parameters.AddWithValue("@BudgetCode", (object?)budgetCode ?? DBNull.Value);

        var list = new List<BudgetEntry>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            list.Add(MapEntry(reader));
        }
        return list;
    }

    public async Task<BudgetEntry?> GetLatestActiveEntryAsync(SqlConnection conn, SqlTransaction? tx, string budgetCode, EntryType entryType, int? quarterCode)
    {
        await using var cmd = NewProcCommand(conn, tx, "dbo.usp_BudgetEntries_GetLatest");
        cmd.Parameters.AddWithValue("@BudgetCode", budgetCode);
        cmd.Parameters.AddWithValue("@EntryType", (int)entryType);
        cmd.Parameters.AddWithValue("@QuarterCode", (object?)quarterCode ?? DBNull.Value);

        await using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync()) return MapEntry(reader);
        return null;
    }

    public async Task<bool> HasAnyActualEverAsync(SqlConnection conn, SqlTransaction? tx, string budgetCode)
    {
        await using var cmd = NewProcCommand(conn, tx, "dbo.usp_BudgetEntries_HasAnyActualEver");
        cmd.Parameters.AddWithValue("@BudgetCode", budgetCode);
        var result = await cmd.ExecuteScalarAsync();
        return result is bool b && b;
    }

    public async Task<int> GetNextBudgetSequenceAsync(SqlConnection conn, SqlTransaction? tx, int fyCode)
    {
        await using var cmd = NewProcCommand(conn, tx, "dbo.usp_BudgetCode_NextSequence");
        cmd.Parameters.AddWithValue("@FYCode", fyCode);
        var result = await cmd.ExecuteScalarAsync();
        return result == null || result is DBNull ? 1 : Convert.ToInt32(result);
    }

    // ---------------------------------------------------------------- budget entries: writes

    public async Task<int> InsertEntryAsync(SqlConnection conn, SqlTransaction tx, BudgetEntry entry)
    {
        await using var cmd = NewProcCommand(conn, tx, "dbo.usp_BudgetEntries_Insert");
        cmd.Parameters.AddWithValue("@BudgetCode", entry.BudgetCode);
        cmd.Parameters.AddWithValue("@ProductCode", entry.ProductCode);
        cmd.Parameters.AddWithValue("@ProductName", entry.ProductName);
        cmd.Parameters.AddWithValue("@IssueType", entry.IssueType);
        cmd.Parameters.AddWithValue("@ProjectName", entry.ProjectName);
        cmd.Parameters.AddWithValue("@CompanyName", entry.CompanyName);
        cmd.Parameters.AddWithValue("@IndustryName", entry.IndustryName);
        cmd.Parameters.AddWithValue("@IndusCoverageGroupCode", entry.IndusCoverageGroupCode);
        cmd.Parameters.AddWithValue("@IndusCoverageGroupName", entry.IndusCoverageGroupName);
        cmd.Parameters.AddWithValue("@FYCode", entry.FYCode);
        cmd.Parameters.AddWithValue("@FYName", entry.FYName);
        cmd.Parameters.AddWithValue("@QuarterCode", entry.QuarterCode);
        cmd.Parameters.AddWithValue("@EntryType", (int)entry.EntryType);
        cmd.Parameters.AddWithValue("@IsMandated", entry.IsMandated);
        cmd.Parameters.AddWithValue("@IndicativeDealSize", entry.IndicativeDealSize);
        cmd.Parameters.AddWithValue("@EstimatedFeePool", entry.EstimatedFeePool);
        cmd.Parameters.AddWithValue("@TotalFees", entry.TotalFees);
        cmd.Parameters.AddWithValue("@NoOfBRLMs", entry.NoOfBRLMs);
        cmd.Parameters.AddWithValue("@JMFKeepRate", entry.JMFKeepRate);
        cmd.Parameters.AddWithValue("@JMFGrossFee", entry.JMFGrossFee);
        cmd.Parameters.AddWithValue("@DealProbability", entry.DealProbability);
        cmd.Parameters.AddWithValue("@JMProbability", entry.JMProbability);
        cmd.Parameters.AddWithValue("@ExpectedClosure", entry.ExpectedClosure);
        cmd.Parameters.AddWithValue("@Q1", entry.Q1);
        cmd.Parameters.AddWithValue("@Q2", entry.Q2);
        cmd.Parameters.AddWithValue("@Q3", entry.Q3);
        cmd.Parameters.AddWithValue("@Q4", entry.Q4);
        cmd.Parameters.AddWithValue("@Total", entry.Total);
        cmd.Parameters.AddWithValue("@Amount", entry.Amount);
        cmd.Parameters.AddWithValue("@Remarks", entry.Remarks);
        cmd.Parameters.AddWithValue("@SupersedesId", (object?)entry.SupersedesId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@CreatedBy", entry.CreatedBy);
        cmd.Parameters.AddWithValue("@CreatedOn", entry.CreatedOn);

        var newIdParam = new SqlParameter("@NewId", SqlDbType.Int) { Direction = ParameterDirection.Output };
        cmd.Parameters.Add(newIdParam);

        await cmd.ExecuteNonQueryAsync();
        return (int)newIdParam.Value;
    }

    public async Task SupersedeAsync(SqlConnection conn, SqlTransaction tx, int id)
    {
        await using var cmd = NewProcCommand(conn, tx, "dbo.usp_BudgetEntries_Supersede");
        cmd.Parameters.AddWithValue("@Id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    // ---------------------------------------------------------------- helpers

    private static SqlCommand NewProcCommand(SqlConnection conn, SqlTransaction? tx, string procName)
    {
        var cmd = new SqlCommand(procName, conn, tx) { CommandType = CommandType.StoredProcedure };
        return cmd;
    }

    private static BudgetEntry MapEntry(SqlDataReader r)
    {
        return new BudgetEntry
        {
            Id = r.GetInt32(r.GetOrdinal("Id")),
            BudgetCode = r.GetString(r.GetOrdinal("BudgetCode")),
            ProductCode = r.GetInt32(r.GetOrdinal("ProductCode")),
            ProductName = r.GetString(r.GetOrdinal("ProductName")),
            IssueType = r.GetString(r.GetOrdinal("IssueType")),
            ProjectName = r.GetString(r.GetOrdinal("ProjectName")),
            CompanyName = r.GetString(r.GetOrdinal("CompanyName")),
            IndustryName = r.GetString(r.GetOrdinal("IndustryName")),
            IndusCoverageGroupCode = r.GetInt32(r.GetOrdinal("IndusCoverageGroupCode")),
            IndusCoverageGroupName = r.GetString(r.GetOrdinal("IndusCoverageGroupName")),
            FYCode = r.GetInt32(r.GetOrdinal("FYCode")),
            FYName = r.GetString(r.GetOrdinal("FYName")),
            QuarterCode = r.GetInt32(r.GetOrdinal("QuarterCode")),
            EntryType = (EntryType)r.GetInt32(r.GetOrdinal("EntryType")),
            IsMandated = r.GetBoolean(r.GetOrdinal("IsMandated")),
            IndicativeDealSize = r.GetDecimal(r.GetOrdinal("IndicativeDealSize")),
            EstimatedFeePool = r.GetDecimal(r.GetOrdinal("EstimatedFeePool")),
            TotalFees = r.GetDecimal(r.GetOrdinal("TotalFees")),
            NoOfBRLMs = r.GetInt32(r.GetOrdinal("NoOfBRLMs")),
            JMFKeepRate = r.GetDecimal(r.GetOrdinal("JMFKeepRate")),
            JMFGrossFee = r.GetDecimal(r.GetOrdinal("JMFGrossFee")),
            DealProbability = r.GetDecimal(r.GetOrdinal("DealProbability")),
            JMProbability = r.GetDecimal(r.GetOrdinal("JMProbability")),
            ExpectedClosure = r.GetInt32(r.GetOrdinal("ExpectedClosure")),
            Q1 = r.GetDecimal(r.GetOrdinal("Q1")),
            Q2 = r.GetDecimal(r.GetOrdinal("Q2")),
            Q3 = r.GetDecimal(r.GetOrdinal("Q3")),
            Q4 = r.GetDecimal(r.GetOrdinal("Q4")),
            Total = r.GetDecimal(r.GetOrdinal("Total")),
            Amount = r.GetDecimal(r.GetOrdinal("Amount")),
            Remarks = r.GetString(r.GetOrdinal("Remarks")),
            IsActive = r.GetBoolean(r.GetOrdinal("IsActive")),
            SupersedesId = r.IsDBNull(r.GetOrdinal("SupersedesId")) ? (int?)null : r.GetInt32(r.GetOrdinal("SupersedesId")),
            CreatedBy = r.GetInt32(r.GetOrdinal("CreatedBy")),
            CreatedOn = r.GetDateTime(r.GetOrdinal("CreatedOn"))
        };
    }
}
