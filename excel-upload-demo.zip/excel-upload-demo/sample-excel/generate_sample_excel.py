"""
Generates sample-data.xlsx matching angular-client/src/app/excel-template.config.ts

Run:  pip install openpyxl
      python3 generate_sample_excel.py

Contains a mix of:
- clean rows (should pass both client + server validation)
- rows with client-side issues (missing required field / bad type)
- rows with server-side-only issues (bad CostCenter, TotalAmount mismatch)
so you can see both validation paths light up red in the grid.
"""
import openpyxl
from datetime import date

columns = [
    "SrNo","ProjectCode","ProjectName","Department","Vendor","ItemDescription",
    "Quantity","UnitPrice","TotalAmount","Currency","StartDate","EndDate",
    "ApprovedBy","ApprovalDate","CostCenter","GLCode","Region","Country",
    "PaymentTerms","InvoiceNumber","InvoiceDate","Remarks","Status","PriorityLevel"
]

rows = [
    # 1: clean row
    [1,"PRJ-1001","Website Revamp","Engineering","Acme Vendor","UX design work",
     10,100,1000,"USD",date(2026,1,10),date(2026,3,1),"John Doe",date(2026,1,5),
     "CC-100","GL-01","APAC","India","Net 30","INV-001",date(2026,1,15),"On track","Active","High"],

    # 2: clean row
    [2,"PRJ-1002","Cloud Migration","Operations","CloudCo","Server migration",
     5,2000,10000,"USD",date(2026,2,1),None,"Jane Smith",date(2026,1,20),
     "CC-300","GL-02","EMEA","Germany","Net 45",None,None,"","Active","Medium"],

    # 3: CLIENT error - missing required ProjectName
    [3,"PRJ-1003",None,"Marketing","Acme Vendor","Campaign assets",
     20,50,1000,"USD",date(2026,1,1),None,None,None,
     "CC-200","GL-03","NA","USA",None,None,None,None,"Active","Low"],

    # 4: CLIENT error - Quantity is text, not a number
    [4,"PRJ-1004","Ad Campaign","Marketing","MediaCo","Digital ads",
     "ten",50,500,"USD",date(2026,1,1),None,None,None,
     "CC-200","GL-04","NA","USA",None,None,None,None,"Active","Low"],

    # 5: SERVER-only error - CostCenter not in master table (passes client validation)
    [5,"PRJ-1005","New Office Setup","Finance","Furniture Inc","Office furniture",
     15,300,4500,"USD",date(2026,3,1),None,"John Doe",date(2026,2,20),
     "CC-999","GL-05","APAC","India","Net 30",None,None,None,"Active","Medium"],

    # 6: SERVER-only error - TotalAmount does not equal Quantity * UnitPrice
    [6,"PRJ-1006","HR Portal","Human Resources","TechVendor","Portal license",
     2,500,5000,"USD",date(2026,1,1),None,None,None,
     "CC-500","GL-06","NA","USA",None,None,None,None,"Active","High"],

    # 7: clean row
    [7,"PRJ-1007","Data Center Upgrade","Engineering","HardwareCo","Rack upgrade",
     8,750,6000,"USD",date(2026,4,1),date(2026,5,1),"Jane Smith",date(2026,3,25),
     "CC-100","GL-07","EMEA","France","Net 60","INV-002",date(2026,4,5),None,"Active","High"],
]

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Data"
ws.append(columns)
for r in rows:
    ws.append(r)

wb.save("sample-data.xlsx")
print("Created sample-data.xlsx with", len(rows), "rows")
