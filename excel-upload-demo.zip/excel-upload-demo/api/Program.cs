using BudgetUploadApi.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddScoped<IUploadService, UploadService>();

// Allow the Angular dev server (ng serve, default port 4200) to call this API.
// No authentication is configured, as requested - do not use this CORS policy in production as-is.
const string CorsPolicy = "AngularDevClient";
builder.Services.AddCors(options =>
{
    options.AddPolicy(CorsPolicy, policy =>
    {
        policy.WithOrigins("http://localhost:4200")
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

var app = builder.Build();

app.UseCors(CorsPolicy);
app.UseAuthorization();
app.MapControllers();

app.Run();
