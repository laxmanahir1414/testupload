using BudgetUploadApi.Dtos;

namespace BudgetUploadApi.Services
{
    public interface IUploadService
    {
        Task<UploadResponse> ProcessUploadAsync(UploadPayload payload);
    }
}
