using System.Data;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using BudgetUploadApi.Dtos;

namespace BudgetUploadApi.Services
{
    public class UploadService : IUploadService
    {
        private readonly string _connectionString;

        // Column name -> CLR type, must match dbo.BudgetRowType exactly (see sql/01_create_table_type.sql)
        private static readonly (string Name, Type ClrType)[] Columns = new (string, Type)[]
        {
            ("SrNo",            typeof(int)),
            ("ProjectCode",     typeof(string)),
            ("ProjectName",     typeof(string)),
            ("Department",      typeof(string)),
            ("Vendor",          typeof(string)),
            ("ItemDescription", typeof(string)),
            ("Quantity",        typeof(decimal)),
            ("UnitPrice",       typeof(decimal)),
            ("TotalAmount",     typeof(decimal)),
            ("Currency",        typeof(string)),
            ("StartDate",       typeof(DateTime)),
            ("EndDate",         typeof(DateTime)),
            ("ApprovedBy",      typeof(string)),
            ("ApprovalDate",    typeof(DateTime)),
            ("CostCenter",      typeof(string)),
            ("GLCode",          typeof(string)),
            ("Region",          typeof(string)),
            ("Country",         typeof(string)),
            ("PaymentTerms",    typeof(string)),
            ("InvoiceNumber",   typeof(string)),
            ("InvoiceDate",     typeof(DateTime)),
            ("Remarks",         typeof(string)),
            ("Status",          typeof(string)),
            ("PriorityLevel",   typeof(string)),
        };

        public UploadService(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("DefaultConnection")
                ?? throw new InvalidOperationException("DefaultConnection connection string is missing in appsettings.json");
        }

        public async Task<UploadResponse> ProcessUploadAsync(UploadPayload payload)
        {
            var table = BuildDataTable(payload.Rows);

            using var conn = new SqlConnection(_connectionString);
            using var cmd = new SqlCommand("usp_ProcessBudgetUpload", conn)
            {
                CommandType = CommandType.StoredProcedure,
                CommandTimeout = 120
            };

            var tvpParam = cmd.Parameters.AddWithValue("@Rows", table);
            tvpParam.SqlDbType = SqlDbType.Structured;
            tvpParam.TypeName = "dbo.BudgetRowType";

            cmd.Parameters.AddWithValue("@Type", payload.Type);

            await conn.OpenAsync();
            using var reader = await cmd.ExecuteReaderAsync();

            var response = new UploadResponse();

            // Result set 1: failed rows with error messages (one row per error)
            var failedMap = new Dictionary<int, ServerRowError>();
            while (await reader.ReadAsync())
            {
                var rowNumber = Convert.ToInt32(reader["RowNumber"]);
                var message = reader["ErrorMessage"].ToString() ?? "Unknown error";

                if (!failedMap.TryGetValue(rowNumber, out var existing))
                {
                    existing = new ServerRowError { RowNumber = rowNumber };
                    failedMap[rowNumber] = existing;
                }
                existing.Errors.Add(message);
            }
            response.FailedRows = failedMap.Values.OrderBy(f => f.RowNumber).ToList();

            // Result set 2: success count
            if (await reader.NextResultAsync() && await reader.ReadAsync())
            {
                response.SuccessCount = Convert.ToInt32(reader["SuccessCount"]);
            }

            return response;
        }

        private DataTable BuildDataTable(List<Dictionary<string, object?>> rows)
        {
            var table = new DataTable();
            table.Columns.Add("RowNumber", typeof(int));
            foreach (var (name, clrType) in Columns)
            {
                table.Columns.Add(name, clrType);
            }

            int rowNum = 2; // matches Angular's rowNumber (header row = 1, data starts at 2)
            foreach (var row in rows)
            {
                var dr = table.NewRow();
                dr["RowNumber"] = rowNum++;

                foreach (var (name, clrType) in Columns)
                {
                    row.TryGetValue(name, out var rawVal);
                    dr[name] = ConvertValue(rawVal, clrType);
                }
                table.Rows.Add(dr);
            }

            return table;
        }

        // System.Text.Json deserializes untyped object values as JsonElement - unwrap before converting
        private static object ConvertValue(object? raw, Type targetType)
        {
            if (raw is null) return DBNull.Value;

            string? text = null;

            if (raw is JsonElement je)
            {
                if (je.ValueKind == JsonValueKind.Null) return DBNull.Value;
                text = je.ValueKind switch
                {
                    JsonValueKind.String => je.GetString(),
                    JsonValueKind.Number => je.GetRawText(),
                    _ => je.ToString()
                };
            }
            else
            {
                text = raw.ToString();
            }

            if (string.IsNullOrWhiteSpace(text)) return DBNull.Value;

            try
            {
                if (targetType == typeof(int)) return int.Parse(text);
                if (targetType == typeof(decimal)) return decimal.Parse(text);
                if (targetType == typeof(DateTime)) return DateTime.Parse(text);
                return text; // string
            }
            catch
            {
                // Let SQL-side validation flag the bad value rather than throwing here
                return DBNull.Value;
            }
        }
    }
}
