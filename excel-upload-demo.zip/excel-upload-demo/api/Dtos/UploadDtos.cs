namespace BudgetUploadApi.Dtos
{
    public class UploadPayload
    {
        public string Type { get; set; } = string.Empty; // "Budget" or "Estimated"
        public List<Dictionary<string, object?>> Rows { get; set; } = new();
    }

    public class ServerRowError
    {
        public int RowNumber { get; set; }
        public List<string> Errors { get; set; } = new();
    }

    public class UploadResponse
    {
        public int SuccessCount { get; set; }
        public List<ServerRowError> FailedRows { get; set; } = new();
    }
}
