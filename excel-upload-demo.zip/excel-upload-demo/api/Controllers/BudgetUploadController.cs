using Microsoft.AspNetCore.Mvc;
using BudgetUploadApi.Dtos;
using BudgetUploadApi.Services;

namespace BudgetUploadApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BudgetUploadController : ControllerBase
    {
        private readonly IUploadService _uploadService;
        private readonly ILogger<BudgetUploadController> _logger;

        public BudgetUploadController(IUploadService uploadService, ILogger<BudgetUploadController> logger)
        {
            _uploadService = uploadService;
            _logger = logger;
        }

        [HttpPost("upload")]
        public async Task<ActionResult<UploadResponse>> Upload([FromBody] UploadPayload payload)
        {
            if (payload?.Rows == null || payload.Rows.Count == 0)
                return BadRequest("No data received.");

            if (payload.Type != "Budget" && payload.Type != "Estimated")
                return BadRequest("Type must be 'Budget' or 'Estimated'.");

            try
            {
                var result = await _uploadService.ProcessUploadAsync(payload);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Upload processing failed");
                return StatusCode(500, "An error occurred while processing the upload.");
            }
        }
    }
}
