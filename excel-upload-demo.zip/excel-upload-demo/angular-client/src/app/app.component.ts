import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChildModalComponent } from './child-modal/child-modal.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, ChildModalComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  isModalOpen = false;

  // example data passed from parent to child
  parentData = { source: 'ParentComponent', requestedBy: 'demo-user' };

  openUploadModal(): void {
    this.isModalOpen = true;
  }

  onModalClosed(_result: boolean): void {
    this.isModalOpen = false;
  }
}
