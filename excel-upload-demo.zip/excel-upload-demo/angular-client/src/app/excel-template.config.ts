export interface ColumnDef {
  name: string;          // must match Excel header exactly (case-sensitive)
  type: 'string' | 'number' | 'date';
  required: boolean;
}

// ============================================================
// EDIT THIS ARRAY to match your real 20-25 column template.
// The sample Excel generator (sample-excel/generate_sample_excel.py)
// is built from this exact list, so if you change this, regenerate
// the sample file too (see README).
// ============================================================
export const ExcelTemplateColumns: ColumnDef[] = [
  { name: 'SrNo',            type: 'number', required: true  },
  { name: 'ProjectCode',     type: 'string', required: true  },
  { name: 'ProjectName',     type: 'string', required: true  },
  { name: 'Department',      type: 'string', required: true  },
  { name: 'Vendor',          type: 'string', required: false },
  { name: 'ItemDescription', type: 'string', required: true  },
  { name: 'Quantity',        type: 'number', required: true  },
  { name: 'UnitPrice',       type: 'number', required: true  },
  { name: 'TotalAmount',     type: 'number', required: true  },
  { name: 'Currency',        type: 'string', required: true  },
  { name: 'StartDate',       type: 'date',   required: true  },
  { name: 'EndDate',         type: 'date',   required: false },
  { name: 'ApprovedBy',      type: 'string', required: false },
  { name: 'ApprovalDate',    type: 'date',   required: false },
  { name: 'CostCenter',      type: 'string', required: true  },
  { name: 'GLCode',          type: 'string', required: true  },
  { name: 'Region',          type: 'string', required: true  },
  { name: 'Country',         type: 'string', required: true  },
  { name: 'PaymentTerms',    type: 'string', required: false },
  { name: 'InvoiceNumber',   type: 'string', required: false },
  { name: 'InvoiceDate',     type: 'date',   required: false },
  { name: 'Remarks',         type: 'string', required: false },
  { name: 'Status',          type: 'string', required: true  },
  { name: 'PriorityLevel',   type: 'string', required: false }
];
