export interface ExcelRow {
  rowNumber: number;             // Excel row number (header = row 1, data starts row 2)
  data: Record<string, any>;     // column name -> value
  errors: string[];              // client OR server validation errors
  hasError: boolean;
}

export interface UploadPayload {
  type: 'Budget' | 'Estimated';
  rows: Record<string, any>[];
}

export interface ServerRowError {
  rowNumber: number;
  errors: string[];
}

export interface UploadResponse {
  successCount: number;
  failedRows: ServerRowError[];
}
