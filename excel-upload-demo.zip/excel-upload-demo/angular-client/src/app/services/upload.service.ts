import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UploadPayload, UploadResponse } from '../models/excel-row.model';

@Injectable({ providedIn: 'root' })
export class UploadService {
  // Update this if your API runs on a different port (see api/Properties/launchSettings.json)
  private apiUrl = 'https://localhost:5001/api/BudgetUpload/upload';

  constructor(private http: HttpClient) {}

  uploadData(payload: UploadPayload): Observable<UploadResponse> {
    return this.http.post<UploadResponse>(this.apiUrl, payload);
  }
}
