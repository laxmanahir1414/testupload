import { Injectable } from '@angular/core';
import * as XLSX from 'xlsx';
import { ExcelTemplateColumns } from '../excel-template.config';
import { ExcelRow } from '../models/excel-row.model';

export interface ParseResult {
  templateValid: boolean;
  templateError: string | null;
  rows: ExcelRow[];
  columns: string[];
}

@Injectable({ providedIn: 'root' })
export class ExcelValidatorService {

  async parseAndValidate(file: File): Promise<ParseResult> {
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];

    // Read as array-of-arrays so we can check the header row precisely
    const raw: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: null });

    if (!raw.length) {
      return { templateValid: false, templateError: 'Excel file is empty.', rows: [], columns: [] };
    }

    const headerRow: string[] = (raw[0] || []).map(h => (h ?? '').toString().trim());

    // 1. Column count must match
    if (headerRow.length !== ExcelTemplateColumns.length) {
      return {
        templateValid: false,
        templateError: `Column count mismatch. Template expects ${ExcelTemplateColumns.length} columns, file has ${headerRow.length}.`,
        rows: [],
        columns: []
      };
    }

    // 2. Column names must match (order-independent)
    const expectedNames = ExcelTemplateColumns.map(c => c.name);
    const missing = expectedNames.filter(n => !headerRow.includes(n));
    const extra = headerRow.filter(n => !expectedNames.includes(n));
    if (missing.length || extra.length) {
      return {
        templateValid: false,
        templateError:
          (missing.length ? `Missing columns: ${missing.join(', ')}. ` : '') +
          (extra.length ? `Unexpected columns: ${extra.join(', ')}.` : ''),
        rows: [],
        columns: []
      };
    }

    // 3. Build row objects keyed by header name, then validate each cell
    const dataRows = raw.slice(1).filter(r => r.some(cell => cell !== null && cell !== ''));
    const rows: ExcelRow[] = dataRows.map((r, idx) => {
      const obj: Record<string, any> = {};
      headerRow.forEach((colName, i) => {
        let val = r[i] ?? null;
        if (val instanceof Date) {
          val = val.toISOString().substring(0, 10); // normalize to yyyy-MM-dd
        }
        obj[colName] = val;
      });

      const errors = this.validateRow(obj);
      return {
        rowNumber: idx + 2, // +2 = header row (1) + 1-based data index
        data: obj,
        errors,
        hasError: errors.length > 0
      };
    });

    return { templateValid: true, templateError: null, rows, columns: headerRow };
  }

  private validateRow(row: Record<string, any>): string[] {
    const errors: string[] = [];

    for (const col of ExcelTemplateColumns) {
      const value = row[col.name];
      const isEmpty = value === null || value === undefined || value.toString().trim() === '';

      if (col.required && isEmpty) {
        errors.push(`${col.name} is required`);
        continue;
      }
      if (isEmpty) continue; // optional & empty -> skip type check

      switch (col.type) {
        case 'number':
          if (isNaN(Number(value))) errors.push(`${col.name} must be a number`);
          break;
        case 'date':
          if (isNaN(new Date(value).getTime())) errors.push(`${col.name} must be a valid date`);
          break;
        case 'string':
          if (typeof value !== 'string' && typeof value !== 'number') {
            errors.push(`${col.name} must be text`);
          }
          break;
      }
    }
    return errors;
  }
}
