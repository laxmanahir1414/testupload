import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ExcelValidatorService } from '../services/excel-validator.service';
import { UploadService } from '../services/upload.service';
import { ExcelRow } from '../models/excel-row.model';

@Component({
  selector: 'app-child-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './child-modal.component.html',
  styleUrls: ['./child-modal.component.css']
})
export class ChildModalComponent {
  @Input() parentData: any;
  @Output() closed = new EventEmitter<boolean>();

  selectedType: 'Budget' | 'Estimated' = 'Budget';
  selectedFile: File | null = null;

  templateError: string | null = null;
  rows: ExcelRow[] = [];
  columns: string[] = [];

  isValidating = false;
  isSubmitting = false;
  submitMessage: string | null = null;
  submitSuccess = false;

  constructor(
    private excelValidator: ExcelValidatorService,
    private uploadService: UploadService
  ) {}

  get hasClientErrors(): boolean {
    return this.rows.some(r => r.hasError);
  }

  get errorRowCount(): number {
    return this.rows.filter(r => r.hasError).length;
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.selectedFile = input.files?.[0] ?? null;
    this.resetGrid();
  }

  async validateExcel(): Promise<void> {
    if (!this.selectedFile) return;

    this.isValidating = true;
    this.resetGrid();

    try {
      const result = await this.excelValidator.parseAndValidate(this.selectedFile);

      if (!result.templateValid) {
        this.templateError = result.templateError;
        return;
      }
      this.rows = result.rows;
      this.columns = result.columns;
    } catch (err) {
      this.templateError = 'Could not read the file. Please make sure it is a valid .xlsx/.xls file.';
      console.error(err);
    } finally {
      this.isValidating = false;
    }
  }

  submit(): void {
    if (this.hasClientErrors || !this.rows.length || this.isSubmitting) return;

    this.isSubmitting = true;
    this.submitMessage = null;
    this.submitSuccess = false;

    const payload = {
      type: this.selectedType,
      rows: this.rows.map(r => r.data)
    };

    this.uploadService.uploadData(payload).subscribe({
      next: (res) => {
        this.isSubmitting = false;

        if (res.failedRows?.length) {
          // merge server-side errors back into the same grid, mark rows red again
          const errorMap = new Map(res.failedRows.map(f => [f.rowNumber, f.errors]));
          this.rows.forEach(r => {
            if (errorMap.has(r.rowNumber)) {
              r.errors = errorMap.get(r.rowNumber)!;
              r.hasError = true;
            } else {
              r.errors = [];
              r.hasError = false;
            }
          });
          this.submitSuccess = false;
          this.submitMessage =
            `${res.successCount} row(s) saved successfully. ${res.failedRows.length} row(s) failed validation in the database — fix the highlighted rows in Excel and reupload.`;
        } else {
          this.submitSuccess = true;
          this.submitMessage = `All ${res.successCount} row(s) saved successfully.`;
        }
      },
      error: (err) => {
        this.isSubmitting = false;
        this.submitSuccess = false;
        this.submitMessage = 'Upload failed: could not reach the API. Is the backend running on https://localhost:5001 ?';
        console.error(err);
      }
    });
  }

  private resetGrid(): void {
    this.templateError = null;
    this.rows = [];
    this.columns = [];
    this.submitMessage = null;
    this.submitSuccess = false;
  }

  close(): void {
    this.closed.emit(this.submitSuccess);
  }
}
