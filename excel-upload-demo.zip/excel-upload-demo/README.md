# Excel Upload Demo — Angular + ASP.NET Core + SQL Server

A small runnable project demonstrating:

- Parent component → button → opens a **child modal component** (data passed via `@Input`)
- Child modal: **Budget / Estimated radio buttons** + **file upload**
- Client-side Excel validation (column names, column count, data types, required fields) using SheetJS
- Bad rows shown **highlighted red in a grid**, with an Errors column
- On submit, clean JSON is POSTed to an **ASP.NET Core Web API**
- API loads the data into a SQL Server **table-valued parameter** and calls a **stored procedure**
- Stored procedure applies business rules, inserts good rows, returns bad rows + error messages
- API returns those errors to Angular, which **merges them back into the same grid** (red rows again) so the user can fix and reupload

No authentication is implemented, as requested — add it later if needed (JWT / Windows Auth / API key, whichever fits your environment).

---

## What's in this folder

```
angular-client/     Angular 17 standalone app (this has been npm installed + built successfully)
api/                 ASP.NET Core 8 Web API (source only — install .NET 8 SDK to run)
sql/                 SQL Server scripts (run in order 01 -> 02 -> 03)
sample-excel/        A ready-to-use test file (sample-data.xlsx) matching the template,
                     plus the Python script that generated it
```

---

## 1. Set up the database

Requires SQL Server (Developer/Express edition is fine) + SSMS or `sqlcmd`.

Run these in order, in `sql/`:

1. `01_create_database_and_type.sql` — creates the `BudgetUploadDemo` database and the `dbo.BudgetRowType` table type (used as the TVP)
2. `02_create_tables.sql` — creates `dbo.BudgetData` (destination table) and `dbo.CostCenterMaster` (a small lookup table with sample rows, used by one of the validation rules)
3. `03_stored_procedure.sql` — creates `dbo.usp_ProcessBudgetUpload`, which does the server-side validation + insert

```powershell
sqlcmd -S localhost -i sql\01_create_database_and_type.sql
sqlcmd -S localhost -i sql\02_create_tables.sql
sqlcmd -S localhost -i sql\03_stored_procedure.sql
```

(Or just open each `.sql` file in SSMS and hit Execute, in order.)

---

## 2. Run the API

Requires the **.NET 8 SDK** (not included here — install from Microsoft if you don't have it).

```bash
cd api
dotnet restore
dotnet run
```

It will start on **https://localhost:5001** (see `Properties/launchSettings.json`). If you get an untrusted dev-cert warning the first time, run `dotnet dev-certs https --trust`.

Check the connection string in `api/appsettings.json` — by default it assumes:
```
Server=localhost;Database=BudgetUploadDemo;Trusted_Connection=True;TrustServerCertificate=True;
```
Change `Server=` (and add `User Id=`/`Password=` if you're not using Windows auth) to match your SQL Server instance.

---

## 3. Run the Angular app

Already `npm install`-ed and build-tested in this sandbox — you just need Node.js 18+ installed locally.

```bash
cd angular-client
npm install
npm start
```

Opens on **http://localhost:4200**. The API URL is set in `src/app/services/upload.service.ts` — update it if your API runs on a different port/host.

---

## 4. Try it

1. Open http://localhost:4200 → click **"Upload Budget/Estimated Data"** → modal opens.
2. Pick **Budget** or **Estimated**.
3. Choose the file `sample-excel/sample-data.xlsx` (included) and click **Validate Excel**.
   - Row 3 and row 4 will show **red** immediately — missing `ProjectName`, and `Quantity` is text instead of a number. This is **client-side** validation, no API call yet.
4. Fix those two rows in Excel (or just delete them for a quick test) and re-upload, or leave them and notice **Submit stays disabled** while any row has an error.
5. Once all rows are clean client-side, click **Submit**.
   - Row 5 (`CC-999`, not in `CostCenterMaster`) and row 6 (`TotalAmount` ≠ `Quantity × UnitPrice`) will come back **red from the server**, each with its SQL error message in the Errors column.
   - The other rows will already be inserted into `dbo.BudgetData`.
6. Fix rows 5 & 6, reupload the file, submit again → all rows succeed.

---

## Customizing to your real template

Everything is driven off one place on each side:

| What | Where |
|---|---|
| Angular column list (name/type/required) | `angular-client/src/app/excel-template.config.ts` |
| API's column list + SQL types | `api/Services/UploadService.cs` → `Columns` array |
| SQL Server TVP shape | `sql/01_create_database_and_type.sql` |
| Destination table | `sql/02_create_tables.sql` |
| Business validation rules | `sql/03_stored_procedure.sql` (the numbered `-- Rule N` blocks) |

Update all four to match your real 20–25 column template (column names must match your Excel header row exactly), then regenerate `sample-excel/sample-data.xlsx` using `generate_sample_excel.py` if you want a matching test file.

---

## Notes / things you'll likely want to add later

- **Authentication** — deliberately left out per the request. Add `[Authorize]` + your auth scheme to the controller when ready.
- **File size / row count limits** — no cap is currently enforced on the Angular side; add one if users might upload very large files.
- **Batching very large uploads** — the whole grid is sent as one JSON POST and one TVP call. Fine for thousands of rows; if you expect tens of thousands+, consider chunking.
- **Production CORS** — `Program.cs` currently only allows `http://localhost:4200`. Update the allowed origin(s) for your real deployment.
