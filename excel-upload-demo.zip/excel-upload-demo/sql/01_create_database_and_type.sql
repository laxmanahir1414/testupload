-- ============================================================
-- 01_create_database_and_type.sql
-- Run this first.
-- ============================================================

IF DB_ID('BudgetUploadDemo') IS NULL
BEGIN
    CREATE DATABASE BudgetUploadDemo;
END
GO

USE BudgetUploadDemo;
GO

IF TYPE_ID('dbo.BudgetRowType') IS NOT NULL
    DROP TYPE dbo.BudgetRowType;
GO

-- Table-valued parameter type used to pass the whole uploaded grid to the stored procedure in one call.
-- Columns must match UploadService.cs 'Columns' array exactly (name + order).
CREATE TYPE dbo.BudgetRowType AS TABLE
(
    RowNumber        INT             NOT NULL,
    SrNo             INT             NULL,
    ProjectCode      NVARCHAR(50)    NULL,
    ProjectName      NVARCHAR(200)   NULL,
    Department       NVARCHAR(100)   NULL,
    Vendor           NVARCHAR(100)   NULL,
    ItemDescription  NVARCHAR(500)   NULL,
    Quantity         DECIMAL(18,2)   NULL,
    UnitPrice        DECIMAL(18,2)   NULL,
    TotalAmount      DECIMAL(18,2)   NULL,
    Currency         NVARCHAR(10)    NULL,
    StartDate        DATE            NULL,
    EndDate          DATE            NULL,
    ApprovedBy       NVARCHAR(100)   NULL,
    ApprovalDate     DATE            NULL,
    CostCenter       NVARCHAR(50)    NULL,
    GLCode           NVARCHAR(50)    NULL,
    Region           NVARCHAR(50)    NULL,
    Country          NVARCHAR(50)    NULL,
    PaymentTerms     NVARCHAR(100)   NULL,
    InvoiceNumber    NVARCHAR(50)    NULL,
    InvoiceDate      DATE            NULL,
    Remarks          NVARCHAR(500)   NULL,
    Status           NVARCHAR(50)    NULL,
    PriorityLevel    NVARCHAR(20)    NULL
);
GO
