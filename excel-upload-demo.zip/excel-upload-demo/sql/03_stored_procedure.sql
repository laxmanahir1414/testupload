-- ============================================================
-- 03_stored_procedure.sql
-- Server-side ("backend") validation + insert.
-- Returns TWO result sets, read by UploadService.cs:
--   1) failed rows: RowNumber, ErrorMessage (one row per error)
--   2) success count: SuccessCount
-- ============================================================

USE BudgetUploadDemo;
GO

IF OBJECT_ID('dbo.usp_ProcessBudgetUpload', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_ProcessBudgetUpload;
GO

CREATE PROCEDURE dbo.usp_ProcessBudgetUpload
    @Rows dbo.BudgetRowType READONLY,
    @Type NVARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Errors TABLE (RowNumber INT, ErrorMessage NVARCHAR(500));

    -- ------------------------------------------------------------
    -- Business validation rules. Edit / add your real logic here.
    -- Each rule adds one row per problem found into @Errors.
    -- ------------------------------------------------------------

    -- Rule 1: ProjectCode must not already exist in the database
    INSERT INTO @Errors (RowNumber, ErrorMessage)
    SELECT r.RowNumber, 'ProjectCode "' + r.ProjectCode + '" already exists in database'
    FROM @Rows r
    JOIN dbo.BudgetData bd ON bd.ProjectCode = r.ProjectCode;

    -- Rule 2: TotalAmount must equal Quantity * UnitPrice
    INSERT INTO @Errors (RowNumber, ErrorMessage)
    SELECT RowNumber, 'TotalAmount does not match Quantity * UnitPrice'
    FROM @Rows
    WHERE Quantity IS NOT NULL
      AND UnitPrice IS NOT NULL
      AND TotalAmount IS NOT NULL
      AND TotalAmount <> (Quantity * UnitPrice);

    -- Rule 3: CostCenter must exist in the master table
    INSERT INTO @Errors (RowNumber, ErrorMessage)
    SELECT r.RowNumber, 'CostCenter "' + ISNULL(r.CostCenter, '') + '" is not a valid cost center'
    FROM @Rows r
    WHERE NOT EXISTS (SELECT 1 FROM dbo.CostCenterMaster cm WHERE cm.Code = r.CostCenter);

    -- Rule 4: EndDate (if provided) must be after StartDate
    INSERT INTO @Errors (RowNumber, ErrorMessage)
    SELECT RowNumber, 'EndDate must be after StartDate'
    FROM @Rows
    WHERE EndDate IS NOT NULL AND StartDate IS NOT NULL AND EndDate < StartDate;

    -- Rule 5: any required column that arrived NULL (e.g. failed type conversion in the API) is rejected
    INSERT INTO @Errors (RowNumber, ErrorMessage)
    SELECT RowNumber, 'One or more required fields could not be read (check for text in a numeric/date column)'
    FROM @Rows
    WHERE ProjectCode IS NULL OR ProjectName IS NULL OR Department IS NULL
       OR ItemDescription IS NULL OR Quantity IS NULL OR UnitPrice IS NULL
       OR TotalAmount IS NULL OR Currency IS NULL OR StartDate IS NULL
       OR CostCenter IS NULL OR GLCode IS NULL OR Region IS NULL
       OR Country IS NULL OR Status IS NULL;

    -- ------------------------------------------------------------
    -- Insert only rows with zero errors. Any data manipulation
    -- ("alter the data") logic goes here too, e.g. trimming,
    -- defaulting Status, upper-casing Currency, etc.
    -- ------------------------------------------------------------
    INSERT INTO dbo.BudgetData
        (ProjectCode, ProjectName, Department, Vendor, ItemDescription,
         Quantity, UnitPrice, TotalAmount, Currency, StartDate, EndDate,
         ApprovedBy, ApprovalDate, CostCenter, GLCode, Region, Country,
         PaymentTerms, InvoiceNumber, InvoiceDate, Remarks, Status,
         PriorityLevel, RecordType, CreatedDate)
    SELECT
         LTRIM(RTRIM(r.ProjectCode)), r.ProjectName, r.Department, r.Vendor, r.ItemDescription,
         r.Quantity, r.UnitPrice, r.TotalAmount, UPPER(r.Currency), r.StartDate, r.EndDate,
         r.ApprovedBy, r.ApprovalDate, r.CostCenter, r.GLCode, r.Region, r.Country,
         r.PaymentTerms, r.InvoiceNumber, r.InvoiceDate, r.Remarks, r.Status,
         r.PriorityLevel, @Type, GETDATE()
    FROM @Rows r
    WHERE NOT EXISTS (SELECT 1 FROM @Errors e WHERE e.RowNumber = r.RowNumber);

    -- Result set 1: failed rows (Angular groups these back onto the grid by RowNumber)
    SELECT RowNumber, ErrorMessage FROM @Errors ORDER BY RowNumber;

    -- Result set 2: success count
    SELECT
        (SELECT COUNT(*) FROM @Rows) - (SELECT COUNT(DISTINCT RowNumber) FROM @Errors) AS SuccessCount;
END
GO
