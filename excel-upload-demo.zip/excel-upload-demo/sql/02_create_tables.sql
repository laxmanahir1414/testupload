-- ============================================================
-- 02_create_tables.sql
-- Main data table + a small master table used by the SQL-side
-- validation logic (CostCenter must exist here).
-- ============================================================

USE BudgetUploadDemo;
GO

IF OBJECT_ID('dbo.BudgetData', 'U') IS NOT NULL
    DROP TABLE dbo.BudgetData;
GO

CREATE TABLE dbo.BudgetData
(
    Id               INT IDENTITY(1,1) PRIMARY KEY,
    ProjectCode      NVARCHAR(50)    NOT NULL,
    ProjectName      NVARCHAR(200)   NOT NULL,
    Department       NVARCHAR(100)   NOT NULL,
    Vendor           NVARCHAR(100)   NULL,
    ItemDescription  NVARCHAR(500)   NOT NULL,
    Quantity         DECIMAL(18,2)   NOT NULL,
    UnitPrice        DECIMAL(18,2)   NOT NULL,
    TotalAmount       DECIMAL(18,2)  NOT NULL,
    Currency         NVARCHAR(10)    NOT NULL,
    StartDate        DATE            NOT NULL,
    EndDate          DATE            NULL,
    ApprovedBy       NVARCHAR(100)   NULL,
    ApprovalDate     DATE            NULL,
    CostCenter       NVARCHAR(50)    NOT NULL,
    GLCode           NVARCHAR(50)    NOT NULL,
    Region           NVARCHAR(50)    NOT NULL,
    Country          NVARCHAR(50)    NOT NULL,
    PaymentTerms     NVARCHAR(100)   NULL,
    InvoiceNumber    NVARCHAR(50)    NULL,
    InvoiceDate      DATE            NULL,
    Remarks          NVARCHAR(500)   NULL,
    Status           NVARCHAR(50)    NOT NULL,
    PriorityLevel    NVARCHAR(20)    NULL,
    RecordType       NVARCHAR(20)    NOT NULL,   -- 'Budget' or 'Estimated', from the radio button
    CreatedDate      DATETIME        NOT NULL DEFAULT GETDATE()
);
GO

IF OBJECT_ID('dbo.CostCenterMaster', 'U') IS NOT NULL
    DROP TABLE dbo.CostCenterMaster;
GO

CREATE TABLE dbo.CostCenterMaster
(
    Code NVARCHAR(50) PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL
);
GO

-- Sample master data so the demo SQL validation ("Invalid CostCenter") has something to check against.
-- Edit / replace with your real master data.
INSERT INTO dbo.CostCenterMaster (Code, Name) VALUES
('CC-100', 'Engineering'),
('CC-200', 'Marketing'),
('CC-300', 'Operations'),
('CC-400', 'Finance'),
('CC-500', 'Human Resources');
GO
