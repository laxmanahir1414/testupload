import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BudgetService } from '../../services/budget.service';
import { BudgetEntryInput, Lookup } from '../../models/budget.models';

@Component({
  selector: 'app-entry-form-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './entry-form-modal.component.html',
  styleUrls: ['./entry-form-modal.component.css']
})
export class EntryFormModalComponent implements OnInit, OnChanges {
  @Input() open = false;
  @Output() closed = new EventEmitter<void>();
  @Output() saved = new EventEmitter<void>();

  products: Lookup[] = [];
  issueTypes: Lookup[] = [];
  industryGroups: Lookup[] = [];
  financialYears: Lookup[] = [];

  model: BudgetEntryInput = this.blankModel();

  saving = false;
  errorMessage: string | null = null;
  successMessage: string | null = null;

  constructor(private budgetService: BudgetService) {}

  ngOnInit(): void {
    this.budgetService.getProducts().subscribe(p => (this.products = p));
    this.budgetService.getIssueTypes().subscribe(p => (this.issueTypes = p));
    this.budgetService.getIndustryGroups().subscribe(p => (this.industryGroups = p));
    this.budgetService.getFinancialYears().subscribe(fy => {
      this.financialYears = fy;
      if (fy.length) this.model.fyCode = fy[0].code;
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['open'] && this.open) {
      this.model = this.blankModel();
      if (this.financialYears.length) this.model.fyCode = this.financialYears[0].code;
      this.errorMessage = null;
      this.successMessage = null;
    }
  }

  private blankModel(): BudgetEntryInput {
    return {
      budgetCode: '',
      entryType: 1,
      quarterCode: 1,
      fyCode: 0,
      createdBy: 1,
      productCode: null,
      prodIssueTypeCode: null,
      indusCGCode: null,
      projectName: '',
      companyName: '',
      industryName: '',
      indicativeDealSize: null,
      estimatedFeePool: null,
      totalFees: null,
      noOfBRLMs: null,
      jmfKeepRate: null,
      jmfGrossFee: null,
      dealProbability: null,
      jmProbability: null,
      expectedClosure: null,
      q1: null,
      q2: null,
      q3: null,
      q4: null,
      amount: null,
      isMandated: false,
      remarks: ''
    };
  }

  get isBudget(): boolean { return Number(this.model.entryType) === 1; }
  get isActual(): boolean { return Number(this.model.entryType) === 3; }

  submit(): void {
    this.errorMessage = null;
    this.successMessage = null;

    if (!this.isBudget && !this.model.budgetCode?.trim()) {
      this.errorMessage = 'Budget Code is required for Estimation and Actual entries.';
      return;
    }
    if (this.isBudget && (!this.model.projectName?.trim() && !this.model.companyName?.trim())) {
      this.errorMessage = 'Either Project Name or Mandated Company is required.';
      return;
    }

    this.saving = true;
    const payload: BudgetEntryInput = {
      ...this.model,
      entryType: Number(this.model.entryType),
      quarterCode: Number(this.model.quarterCode),
      fyCode: Number(this.model.fyCode),
      budgetCode: this.model.budgetCode?.trim() || null
    };

    this.budgetService.saveEntry(payload).subscribe({
      next: result => {
        this.saving = false;
        if (result.success) {
          this.successMessage = `${result.message} (Budget Code: ${result.budgetCode})`;
          this.saved.emit();
          setTimeout(() => this.close(), 900);
        } else {
          this.errorMessage = result.message;
        }
      },
      error: err => {
        this.saving = false;
        this.errorMessage = err?.error?.message || 'Save failed. Is the API running?';
      }
    });
  }

  close(): void {
    this.open = false;
    this.closed.emit();
  }

  onBackdropClick(event: MouseEvent): void {
    if (event.target === event.currentTarget) this.close();
  }
}
