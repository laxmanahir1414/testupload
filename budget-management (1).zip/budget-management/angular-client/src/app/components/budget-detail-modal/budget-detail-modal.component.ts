import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BudgetService } from '../../services/budget.service';
import { BudgetDetail } from '../../models/budget.models';

@Component({
  selector: 'app-budget-detail-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './budget-detail-modal.component.html',
  styleUrls: ['./budget-detail-modal.component.css']
})
export class BudgetDetailModalComponent implements OnChanges {
  @Input() budgetCode: string | null = null;
  @Output() closed = new EventEmitter<void>();

  detail: BudgetDetail | null = null;
  loading = false;
  errorMessage: string | null = null;

  constructor(private budgetService: BudgetService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['budgetCode'] && this.budgetCode) {
      this.load(this.budgetCode);
    }
  }

  private load(code: string): void {
    this.loading = true;
    this.errorMessage = null;
    this.detail = null;
    this.budgetService.getDetail(code).subscribe({
      next: d => {
        this.detail = d;
        this.loading = false;
      },
      error: err => {
        this.loading = false;
        this.errorMessage = 'Could not load budget details.';
        console.error(err);
      }
    });
  }

  close(): void {
    this.budgetCode = null;
    this.detail = null;
    this.closed.emit();
  }

  onBackdropClick(event: MouseEvent): void {
    if (event.target === event.currentTarget) this.close();
  }
}
