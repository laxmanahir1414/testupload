import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BudgetGridComponent } from './components/budget-grid/budget-grid.component';
import { BudgetDetailModalComponent } from './components/budget-detail-modal/budget-detail-modal.component';
import { EntryFormModalComponent } from './components/entry-form-modal/entry-form-modal.component';
import { UploadModalComponent } from './components/upload-modal/upload-modal.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    BudgetGridComponent,
    BudgetDetailModalComponent,
    EntryFormModalComponent,
    UploadModalComponent
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  selectedBudgetCode: string | null = null;
  entryFormOpen = false;
  uploadModalOpen = false;

  /// bumped whenever data changes, so the grid can refresh itself
  gridRefreshToken = 0;

  onView(budgetCode: string): void {
    this.selectedBudgetCode = budgetCode;
  }

  onDetailClosed(): void {
    this.selectedBudgetCode = null;
  }

  openEntryForm(): void {
    this.entryFormOpen = true;
  }

  openUpload(): void {
    this.uploadModalOpen = true;
  }

  onEntrySaved(): void {
    this.gridRefreshToken++;
  }

  onUploadSaved(): void {
    this.gridRefreshToken++;
  }
}
