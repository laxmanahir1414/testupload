using BudgetManagement.Api.Dtos;

namespace BudgetManagement.Api.Services;

public interface IBudgetService
{
    Task<List<BudgetGridRowDto>> GetGridAsync(string? search, int? productCode, int? fyCode, int? quarterCode, string? stage);
    Task<BudgetDetailDto?> GetDetailAsync(string budgetCode);
    Task<SaveResultDto> AddOrVersionEntryAsync(BudgetEntryInputDto input);
    Task<BulkUploadResponseDto> BulkUploadAsync(BulkUploadRequestDto request);

    /// <summary>
    /// Excel "Extract" — for Estimation, pulls each Budget Code's current state (latest
    /// Estimation if one exists, else the original Budget) into the same row shape used
    /// for upload, so the user can download, edit, and re-upload as Estimation. For
    /// Actual, pulls the same "current state" (Estimation ?? Budget) as the baseline the
    /// user fills real Actual figures into.
    /// </summary>
    Task<List<BulkUploadRowDto>> ExtractTemplateAsync(int entryType, int fyCode);

    Task<List<LookupDto>> GetProductsAsync();
    Task<List<LookupDto>> GetIssueTypesAsync();
    Task<List<LookupDto>> GetIndustryGroupsAsync();
    Task<List<LookupDto>> GetFinancialYearsAsync();
}
