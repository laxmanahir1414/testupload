using BudgetManagement.Api.Data;
using BudgetManagement.Api.Dtos;
using BudgetManagement.Api.Models;
using Microsoft.Data.SqlClient;
using System.Data;

namespace BudgetManagement.Api.Services;

/// <summary>
/// Every data access call in this class is plain ADO.NET calling a stored procedure
/// (CommandType.StoredProcedure) — no Entity Framework, no LINQ-to-SQL, no ad-hoc SQL
/// text built at runtime, and no LINQ query/extension operators anywhere below.
/// The actual T-SQL lives in api/Database/03_stored_procedures.sql.
///
/// BUSINESS RULE (per Budget Code, within its Financial Year):
///   - Budget     : entered exactly ONCE ever, in whichever quarter the user first
///                  submits it. A second Budget submission for the same code is
///                  rejected — corrections go through Estimation instead.
///   - Estimation : a single, ongoing revision of the Budget. Each new Estimation
///                  submission supersedes the PREVIOUS Estimation regardless of which
///                  quarter either one was made in (NOT re-versioned per quarter).
///                  Blocked only for a specific quarter once that quarter already has
///                  an Actual recorded against it.
///   - Actual     : genuinely quarter-specific. One Actual per quarter, versioned
///                  independently per quarter. Defaults are imported from the latest
///                  Estimation if one exists, otherwise straight from the Budget.
/// </summary>
public class BudgetService : IBudgetService
{
    private readonly ISqlConnectionFactory _connectionFactory;
    private static readonly string[] QuarterLabels = { "", "Q1", "Q2", "Q3", "Q4" };

    public BudgetService(ISqlConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    // ============================================================================
    // LOOKUPS
    // ============================================================================

    public async Task<List<LookupDto>> GetProductsAsync()
    {
        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();
        return await LoadLookupAsync(conn, null, "dbo.sp_Products_GetAll");
    }

    public async Task<List<LookupDto>> GetIssueTypesAsync()
    {
        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();
        return await LoadLookupAsync(conn, null, "dbo.sp_IssueTypes_GetAll");
    }

    public async Task<List<LookupDto>> GetIndustryGroupsAsync()
    {
        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();
        return await LoadLookupAsync(conn, null, "dbo.sp_IndustryCoverageGroups_GetAll");
    }

    public async Task<List<LookupDto>> GetFinancialYearsAsync()
    {
        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();
        return await LoadLookupAsync(conn, null, "dbo.sp_FinancialYears_GetAll");
    }

    private static async Task<List<LookupDto>> LoadLookupAsync(SqlConnection conn, SqlTransaction? tx, string procName)
    {
        var result = new List<LookupDto>();
        await using var cmd = new SqlCommand(procName, conn, tx) { CommandType = CommandType.StoredProcedure };
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new LookupDto(reader.GetInt32(0), reader.GetString(1)));
        }
        return result;
    }

    /// <summary>Case-insensitive name match against an already-loaded lookup list (no LINQ).</summary>
    private static int? FindLookupCodeByName(List<LookupDto> lookups, string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) return null;
        var trimmed = name.Trim();
        foreach (var l in lookups)
        {
            if (string.Equals(l.Name, trimmed, StringComparison.OrdinalIgnoreCase)) return l.Code;
        }
        return null;
    }

    // ============================================================================
    // GRID (product-wise budget list, with filter + search)
    // ============================================================================

    public async Task<List<BudgetGridRowDto>> GetGridAsync(string? search, int? productCode, int? fyCode, int? quarterCode, string? stage)
    {
        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();

        var all = await LoadActiveEntriesAsync(conn, null, null);
        var grouped = GroupByBudgetCode(all);

        var result = new List<BudgetGridRowDto>();

        foreach (var pair in grouped)
        {
            var budgetCode = pair.Key;
            var entries = pair.Value;

            var (budget, estimation, actuals) = SplitByStage(entries);

            BudgetEntry? header = budget ?? estimation;
            if (header == null && actuals.Count > 0)
            {
                header = actuals[0];
                foreach (var a in actuals)
                {
                    if (a.CreatedOn > header.CreatedOn) header = a;
                }
            }
            if (header == null) continue;

            string rowStage = actuals.Count > 0 ? "Actual" : (estimation != null ? "Estimation" : "Budget");

            if (productCode.HasValue && header.ProductCode != productCode.Value) continue;
            if (fyCode.HasValue && header.FYCode != fyCode.Value) continue;

            if (quarterCode.HasValue)
            {
                bool hasQuarter = false;
                foreach (var e in entries)
                {
                    if (e.QuarterCode == quarterCode.Value) { hasQuarter = true; break; }
                }
                if (!hasQuarter) continue;
            }

            if (!string.IsNullOrWhiteSpace(stage) && !string.Equals(rowStage, stage, StringComparison.OrdinalIgnoreCase))
                continue;

            var projectOrCompany = string.IsNullOrWhiteSpace(header.ProjectName) ? header.CompanyName : header.ProjectName;

            if (!string.IsNullOrWhiteSpace(search))
            {
                var s = search.Trim().ToLowerInvariant();
                var hay = (budgetCode + " " + header.ProductName + " " + projectOrCompany + " " + header.IndustryName + " " + header.IssueType)
                    .ToLowerInvariant();
                if (!hay.Contains(s)) continue;
            }

            decimal? actualTotal = null;
            if (actuals.Count > 0)
            {
                decimal sum = 0m;
                foreach (var a in actuals) sum += a.Total;
                actualTotal = sum;
            }

            result.Add(new BudgetGridRowDto
            {
                BudgetCode = budgetCode,
                ProductName = header.ProductName,
                IssueType = header.IssueType,
                ProjectOrCompany = projectOrCompany,
                IndustryName = header.IndustryName,
                IndusCoverageGroupName = header.IndusCoverageGroupName,
                FYName = header.FYName,
                IsMandated = header.IsMandated,
                IndicativeDealSize = header.IndicativeDealSize,
                DealProbability = header.DealProbability,
                BudgetTotal = budget != null ? budget.Total : 0m,
                EstimationTotal = estimation != null ? estimation.Total : (decimal?)null,
                ActualTotal = actualTotal,
                Stage = rowStage
            });
        }

        result.Sort((a, b) => string.CompareOrdinal(b.BudgetCode, a.BudgetCode));
        return result;
    }

    // ============================================================================
    // DETAIL (quarter-wise Budget / Estimation / Actual for one Budget Code)
    // ============================================================================

    public async Task<BudgetDetailDto?> GetDetailAsync(string budgetCode)
    {
        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();

        var entries = await LoadActiveEntriesAsync(conn, null, budgetCode);
        if (entries.Count == 0) return null;

        var (budget, estimation, actuals) = SplitByStage(entries);

        var actualsByQuarter = new Dictionary<int, BudgetEntry>();
        foreach (var a in actuals)
        {
            if (!actualsByQuarter.TryGetValue(a.QuarterCode, out var existing) || a.CreatedOn > existing.CreatedOn)
                actualsByQuarter[a.QuarterCode] = a;
        }

        BudgetEntry? header = budget ?? estimation;
        if (header == null)
        {
            header = entries[0];
            foreach (var e in entries)
            {
                if (e.CreatedOn > header.CreatedOn) header = e;
            }
        }

        var dto = new BudgetDetailDto
        {
            BudgetCode = budgetCode,
            ProductName = header.ProductName,
            IssueType = header.IssueType,
            ProjectName = header.ProjectName,
            CompanyName = header.CompanyName,
            IndustryName = header.IndustryName,
            IndusCoverageGroupName = header.IndusCoverageGroupName,
            FYName = header.FYName,
            IsMandated = header.IsMandated,
            IndicativeDealSize = header.IndicativeDealSize,
            EstimatedFeePool = header.EstimatedFeePool,
            TotalFees = header.TotalFees,
            NoOfBRLMs = header.NoOfBRLMs,
            JMFKeepRate = header.JMFKeepRate,
            JMFGrossFee = header.JMFGrossFee,
            DealProbability = header.DealProbability,
            JMProbability = header.JMProbability,
            ExpectedClosure = header.ExpectedClosure,
            BudgetTotal = budget != null ? budget.Total : 0m,
            EstimationTotal = estimation != null ? estimation.Total : 0m,
            ActualTotal = 0m
        };

        decimal actualTotalSum = 0m;
        foreach (var kvp in actualsByQuarter) actualTotalSum += kvp.Value.Total;
        dto.ActualTotal = actualTotalSum;

        for (int q = 1; q <= 4; q++)
        {
            decimal? budgetQ = budget != null ? GetQuarterValue(budget, q) : (decimal?)null;
            decimal? estimationQ = estimation != null ? GetQuarterValue(estimation, q) : (decimal?)null;
            decimal? actualQ = actualsByQuarter.TryGetValue(q, out var a) ? a.Total : (decimal?)null;

            dto.Quarters.Add(new QuarterFigureDto
            {
                QuarterCode = q,
                QuarterLabel = QuarterLabels[q],
                Budget = budgetQ,
                Estimation = estimationQ,
                Actual = actualQ
            });
        }

        return dto;
    }

    private static decimal GetQuarterValue(BudgetEntry e, int quarter)
    {
        if (quarter == 1) return e.Q1;
        if (quarter == 2) return e.Q2;
        if (quarter == 3) return e.Q3;
        if (quarter == 4) return e.Q4;
        return 0m;
    }

    /// <summary>Groups a flat list of active entries by BudgetCode (no LINQ GroupBy).</summary>
    private static Dictionary<string, List<BudgetEntry>> GroupByBudgetCode(List<BudgetEntry> entries)
    {
        var byCode = new Dictionary<string, List<BudgetEntry>>();
        foreach (var e in entries)
        {
            if (!byCode.TryGetValue(e.BudgetCode, out var list))
            {
                list = new List<BudgetEntry>();
                byCode[e.BudgetCode] = list;
            }
            list.Add(e);
        }
        return byCode;
    }

    /// <summary>Splits one Budget Code's active entries into (latest Budget, latest Estimation, all Actuals) — no LINQ.</summary>
    private static (BudgetEntry? Budget, BudgetEntry? Estimation, List<BudgetEntry> Actuals) SplitByStage(List<BudgetEntry> entries)
    {
        BudgetEntry? budget = null;
        BudgetEntry? estimation = null;
        var actuals = new List<BudgetEntry>();

        foreach (var e in entries)
        {
            if (e.EntryType == EntryType.Budget)
            {
                if (budget == null || e.CreatedOn > budget.CreatedOn) budget = e;
            }
            else if (e.EntryType == EntryType.Estimation)
            {
                if (estimation == null || e.CreatedOn > estimation.CreatedOn) estimation = e;
            }
            else
            {
                actuals.Add(e);
            }
        }
        return (budget, estimation, actuals);
    }

    // ============================================================================
    // EXCEL EXTRACT — pulls current DB state into the same row shape used for upload
    // ============================================================================

    public async Task<List<BulkUploadRowDto>> ExtractTemplateAsync(int entryType, int fyCode)
    {
        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();

        var all = await LoadActiveEntriesByFYAsync(conn, null, fyCode);
        var grouped = GroupByBudgetCode(all);

        var rows = new List<BulkUploadRowDto>();
        int rowNumber = 2; // row 1 is the header, matching the Excel template convention

        // sort by BudgetCode so the extracted file has a stable, predictable order
        var codes = new List<string>(grouped.Keys);
        codes.Sort(StringComparer.Ordinal);

        foreach (var budgetCode in codes)
        {
            var (budget, estimation, _) = SplitByStage(grouped[budgetCode]);
            if (budget == null) continue; // nothing to extract until a Budget exists

            // Both Estimation and Actual extracts start from the same "current best known
            // state": the latest Estimation if one exists, otherwise the original Budget.
            var source = estimation ?? budget;

            rows.Add(new BulkUploadRowDto
            {
                RowNumber = rowNumber++,
                BudgetCode = source.BudgetCode,
                IndusCoverageGroup = source.IndusCoverageGroupName,
                PitchedOrMandated = source.IsMandated ? "Mandated" : "Pitched",
                ProjectName = source.ProjectName,
                MandatedCompany = source.CompanyName,
                Industry = source.IndustryName,
                Product = source.ProductName,
                IssueType = source.IssueType,
                IndicativeDealSize = source.IndicativeDealSize,
                EstimatedFeePool = source.EstimatedFeePool,
                TotalFees = source.TotalFees,
                NoOfBRLMs = source.NoOfBRLMs,
                JMFKeepRate = source.JMFKeepRate,
                JMFGrossFee = source.JMFGrossFee,
                DealProbability = source.DealProbability,
                JMProbability = source.JMProbability,
                ExpectedClosure = "Q" + source.ExpectedClosure,
                Q1 = source.Q1,
                Q2 = source.Q2,
                Q3 = source.Q3,
                Q4 = source.Q4,
                Total = source.Total,
                Quarter = null, // user picks the target quarter in the upload screen itself
                Amount = source.Amount
            });
        }

        return rows;
    }

    // ============================================================================
    // SINGLE ENTRY ADD / VERSION
    // ============================================================================

    public async Task<SaveResultDto> AddOrVersionEntryAsync(BudgetEntryInputDto input)
    {
        if (input.EntryType < 1 || input.EntryType > 3)
            return Fail("Invalid entry type. Use 1 = Budget, 2 = Estimation, 3 = Actual.");
        if (input.QuarterCode < 1 || input.QuarterCode > 4)
            return Fail("Invalid quarter. Use 1-4.");

        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();
        await using var tx = (SqlTransaction)await conn.BeginTransactionAsync();

        try
        {
            var fyName = await GetFinancialYearNameAsync(conn, tx, input.FYCode);
            if (fyName == null)
            {
                await tx.RollbackAsync();
                return Fail("Invalid financial year.");
            }

            var entryType = (EntryType)input.EntryType;
            var budgetCode = input.BudgetCode?.Trim();

            if (entryType == EntryType.Budget && string.IsNullOrEmpty(budgetCode))
            {
                budgetCode = await GenerateNextBudgetCodeAsync(conn, tx, input.FYCode);
            }

            if (string.IsNullOrEmpty(budgetCode))
            {
                await tx.RollbackAsync();
                return Fail("Budget Code is required for Estimation and Actual entries.");
            }

            var built = await BuildEntryAsync(
                conn, tx, budgetCode!, entryType, input.QuarterCode, input.FYCode, fyName, input.CreatedBy ?? 1,
                input.ProductCode, input.ProdIssueTypeCode, input.IndusCGCode,
                input.ProjectName, input.CompanyName, input.IndustryName,
                input.IndicativeDealSize, input.EstimatedFeePool, input.TotalFees, input.NoOfBRLMs,
                input.JMFKeepRate, input.JMFGrossFee, input.DealProbability, input.JMProbability,
                input.ExpectedClosure, input.Q1, input.Q2, input.Q3, input.Q4, input.Amount,
                input.IsMandated, input.Remarks);

            if (!built.Ok)
            {
                await tx.RollbackAsync();
                return Fail(built.Error!);
            }

            await InsertEntryAsync(conn, tx, built.Entry!);
            if (built.SupersedesId.HasValue)
            {
                await MarkSupersededAsync(conn, tx, built.SupersedesId.Value);
            }

            await tx.CommitAsync();
            return new SaveResultDto { Success = true, Message = $"{entryType} entry saved successfully.", BudgetCode = budgetCode };
        }
        catch
        {
            await tx.RollbackAsync();
            throw;
        }
    }

    // ============================================================================
    // BULK (EXCEL) UPLOAD — everything happens inside ONE transaction. Every row is
    // validated and (if valid) inserted; if ANY row failed, the whole transaction is
    // rolled back at the end so nothing is persisted, while still reporting every row's
    // outcome.
    // ============================================================================

    public async Task<BulkUploadResponseDto> BulkUploadAsync(BulkUploadRequestDto request)
    {
        var response = new BulkUploadResponseDto();

        if (request.EntryType < 1 || request.EntryType > 3)
        {
            response.Success = false;
            response.Message = "Invalid entry type.";
            return response;
        }
        if (request.QuarterCode < 1 || request.QuarterCode > 4)
        {
            response.Success = false;
            response.Message = "Invalid quarter.";
            return response;
        }
        if (request.Rows == null || request.Rows.Count == 0)
        {
            response.Success = false;
            response.Message = "No rows found in the uploaded file.";
            return response;
        }

        await using var conn = _connectionFactory.CreateConnection();
        await conn.OpenAsync();
        await using var tx = (SqlTransaction)await conn.BeginTransactionAsync();

        try
        {
            var fyName = await GetFinancialYearNameAsync(conn, tx, request.FYCode);
            if (fyName == null)
            {
                await tx.RollbackAsync();
                response.Success = false;
                response.Message = "Invalid financial year.";
                return response;
            }

            var entryType = (EntryType)request.EntryType;

            var seenCodes = new Dictionary<string, int>();
            foreach (var row in request.Rows)
            {
                if (string.IsNullOrWhiteSpace(row.BudgetCode)) continue;
                var code = row.BudgetCode.Trim();
                seenCodes.TryGetValue(code, out var count);
                seenCodes[code] = count + 1;
            }

            var products = await LoadLookupAsync(conn, tx, "dbo.sp_Products_GetAll");
            var issueTypes = await LoadLookupAsync(conn, tx, "dbo.sp_IssueTypes_GetAll");
            var groups = await LoadLookupAsync(conn, tx, "dbo.sp_IndustryCoverageGroups_GetAll");

            var sortedRows = new List<BulkUploadRowDto>(request.Rows);
            sortedRows.Sort((a, b) => a.RowNumber.CompareTo(b.RowNumber));

            var rowResults = new List<BulkUploadRowResultDto>();
            bool anyFailed = false;
            var baseTime = DateTime.UtcNow;
            int rowIndex = 0;

            foreach (var row in sortedRows)
            {
                rowIndex++;
                var budgetCode = row.BudgetCode?.Trim();
                string? err = null;

                if (string.IsNullOrEmpty(budgetCode))
                    err = "Budget Code is required.";
                else if (seenCodes.TryGetValue(budgetCode, out var occurrences) && occurrences > 1)
                    err = "Duplicate Budget Code found in this Excel batch.";

                int? expectedClosureCode = ParseQuarterText(row.ExpectedClosure);
                if (err == null && row.ExpectedClosure != null && expectedClosureCode == null)
                    err = $"Expected Closure \"{row.ExpectedClosure}\" is not a valid quarter (Q1-Q4).";
                if (err == null && expectedClosureCode.HasValue && expectedClosureCode.Value < request.QuarterCode)
                    err = "Expected Closure quarter cannot be earlier than the entry quarter.";

                int? rowQuarterCode = ParseQuarterText(row.Quarter);
                if (err == null && rowQuarterCode.HasValue && rowQuarterCode.Value != request.QuarterCode)
                    err = $"Row Quarter ({row.Quarter}) does not match the selected upload quarter (Q{request.QuarterCode}).";

                int? productCode = null, issueTypeCode = null, indusCgCode = null;
                if (err == null && !string.IsNullOrWhiteSpace(row.Product))
                {
                    productCode = FindLookupCodeByName(products, row.Product);
                    if (productCode == null) err = $"Product \"{row.Product}\" was not found in the Product master.";
                }
                if (err == null && !string.IsNullOrWhiteSpace(row.IssueType))
                {
                    issueTypeCode = FindLookupCodeByName(issueTypes, row.IssueType);
                    if (issueTypeCode == null) err = $"Issue Type \"{row.IssueType}\" was not found in the Issue Type master.";
                }
                if (err == null && !string.IsNullOrWhiteSpace(row.IndusCoverageGroup))
                {
                    indusCgCode = FindLookupCodeByName(groups, row.IndusCoverageGroup);
                    if (indusCgCode == null) err = $"Indus Coverage Group \"{row.IndusCoverageGroup}\" was not found in the master.";
                }

                if (err == null && entryType == EntryType.Budget)
                {
                    if (productCode == null) err = "Product is required for a new Budget entry.";
                    else if (issueTypeCode == null) err = "Issue Type is required for a new Budget entry.";
                    else if (indusCgCode == null) err = "Indus Coverage Group is required for a new Budget entry.";
                    else if (string.IsNullOrWhiteSpace(row.ProjectName) && string.IsNullOrWhiteSpace(row.MandatedCompany))
                        err = "Project Name or Mandated Company is required.";
                }

                if (err == null && row.DealProbability.HasValue && (row.DealProbability.Value < 0 || row.DealProbability.Value > 100))
                    err = "Deal Probability (%) must be between 0 and 100.";
                if (err == null && row.JMProbability.HasValue && (row.JMProbability.Value < 0 || row.JMProbability.Value > 100))
                    err = "JM Probability (%) must be between 0 and 100.";
                if (err == null && row.IndicativeDealSize.HasValue && row.IndicativeDealSize.Value < 0)
                    err = "Indicative Deal Size cannot be negative.";

                bool isMandated = false;
                if (!string.IsNullOrEmpty(row.PitchedOrMandated) && row.PitchedOrMandated.ToLowerInvariant().Contains("mandat"))
                    isMandated = true;

                if (err == null)
                {
                    decimal? amount = row.Amount.HasValue ? row.Amount : row.Total;

                    var built = await BuildEntryAsync(
                        conn, tx, budgetCode!, entryType, request.QuarterCode, request.FYCode, fyName, request.CreatedBy,
                        productCode, issueTypeCode, indusCgCode,
                        row.ProjectName, row.MandatedCompany, row.Industry,
                        row.IndicativeDealSize, row.EstimatedFeePool, row.TotalFees, row.NoOfBRLMs,
                        row.JMFKeepRate, row.JMFGrossFee, row.DealProbability, row.JMProbability,
                        expectedClosureCode, row.Q1, row.Q2, row.Q3, row.Q4, amount,
                        isMandated, null,
                        baseTime.AddTicks(rowIndex));

                    if (!built.Ok)
                    {
                        err = built.Error;
                    }
                    else
                    {
                        await InsertEntryAsync(conn, tx, built.Entry!);
                        if (built.SupersedesId.HasValue)
                        {
                            await MarkSupersededAsync(conn, tx, built.SupersedesId.Value);
                        }
                    }
                }

                if (err != null)
                {
                    anyFailed = true;
                    rowResults.Add(new BulkUploadRowResultDto { RowNumber = row.RowNumber, BudgetCode = budgetCode, Success = false, ErrorMessage = err });
                }
                else
                {
                    rowResults.Add(new BulkUploadRowResultDto { RowNumber = row.RowNumber, BudgetCode = budgetCode, Success = true });
                }
            }

            if (anyFailed)
            {
                await tx.RollbackAsync();
                response.Success = false;
                response.Message = "Excel validation failed. No Budget, Estimation or Actual records were saved.";
                response.Rows = rowResults;
                return response;
            }

            await tx.CommitAsync();
            response.Success = true;
            response.Message = $"All {rowResults.Count} row(s) saved successfully.";
            response.Rows = rowResults;
            return response;
        }
        catch (Exception ex)
        {
            await tx.RollbackAsync();
            response.Success = false;
            response.Message = "Bulk save failed: " + ex.Message;
            return response;
        }
    }

    // ============================================================================
    // SHARED: build a ready-to-insert BudgetEntry, applying versioning + import-forward
    // of defaults from the previous stage. Read-only against the DB (via conn/tx) —
    // the caller decides whether/when to actually INSERT it.
    // ============================================================================

    private async Task<BuildResult> BuildEntryAsync(
        SqlConnection conn, SqlTransaction tx,
        string budgetCode, EntryType entryType, int quarterCode, int fyCode, string fyName, int createdBy,
        int? productCode, int? issueTypeCode, int? indusCgCode,
        string? projectName, string? companyName, string? industryName,
        decimal? dealSize, decimal? feePool, decimal? totalFees, int? noOfBRLMs,
        decimal? jmfKeepRate, decimal? jmfGrossFee, decimal? dealProbability, decimal? jmProbability,
        int? expectedClosure, decimal? q1, decimal? q2, decimal? q3, decimal? q4, decimal? amount,
        bool? isMandated, string? remarks,
        DateTime? createdOnOverride = null)
    {
        // Budget and Estimation are NEVER quarter-scoped — there is only ever one current
        // Budget and one current Estimation per Budget Code. Actual is quarter-scoped.
        var latestBudget = await GetLatestActiveEntryAsync(conn, tx, budgetCode, EntryType.Budget, null);
        var latestEstimation = await GetLatestActiveEntryAsync(conn, tx, budgetCode, EntryType.Estimation, null);

        BudgetEntry? priorSameStage;
        if (entryType == EntryType.Budget) priorSameStage = latestBudget;
        else if (entryType == EntryType.Estimation) priorSameStage = latestEstimation;
        else priorSameStage = await GetLatestActiveEntryAsync(conn, tx, budgetCode, EntryType.Actual, quarterCode);

        // ---- business rules -------------------------------------------------------
        if (entryType == EntryType.Budget)
        {
            if (latestBudget != null)
                return BuildResult.Fail("A Budget entry already exists for this Budget Code. Budget is entered once; use Estimation to revise the figures.");
        }
        else if (entryType == EntryType.Estimation)
        {
            if (latestBudget == null)
                return BuildResult.Fail("Budget Code does not have an existing Budget entry. Estimation requires a Budget first.");

            var actualForThisQuarter = await GetLatestActiveEntryAsync(conn, tx, budgetCode, EntryType.Actual, quarterCode);
            if (actualForThisQuarter != null)
                return BuildResult.Fail($"Actual already exists for quarter Q{quarterCode}; that quarter can no longer be re-estimated.");
        }
        else // Actual
        {
            if (latestBudget == null)
                return BuildResult.Fail("Budget Code does not have an existing Budget entry. Actual requires a Budget baseline.");
        }

        // ---- resolve "import defaults from" source --------------------------------
        // Estimation: import from the previous Estimation if this is a revision,
        // otherwise from the Budget (first-ever Estimation).
        // Actual: import from the same quarter's previous Actual if this is a
        // resubmission, otherwise from the latest Estimation, otherwise the Budget —
        // "first Actual compares against Budget; once Estimation exists, later Actuals
        // compare against the latest Estimation instead."
        BudgetEntry? source;
        if (entryType == EntryType.Budget) source = null;
        else if (entryType == EntryType.Estimation) source = latestEstimation ?? latestBudget;
        else source = priorSameStage ?? latestEstimation ?? latestBudget;

        if (source == null && entryType == EntryType.Budget)
        {
            if (productCode == null) return BuildResult.Fail("Product is required for a new Budget entry.");
            if (issueTypeCode == null) return BuildResult.Fail("Issue Type is required for a new Budget entry.");
            if (indusCgCode == null) return BuildResult.Fail("Indus Coverage Group is required for a new Budget entry.");
            if (string.IsNullOrWhiteSpace(projectName) && string.IsNullOrWhiteSpace(companyName))
                return BuildResult.Fail("Either Project Name or Mandated Company is required.");
        }

        string? productName = productCode.HasValue ? await GetLookupNameAsync(conn, tx, "Product", productCode.Value) : null;
        string? issueTypeName = issueTypeCode.HasValue ? await GetLookupNameAsync(conn, tx, "IssueType", issueTypeCode.Value) : null;
        string? indusCgName = indusCgCode.HasValue ? await GetLookupNameAsync(conn, tx, "IndustryGroup", indusCgCode.Value) : null;

        var entry = new BudgetEntry
        {
            BudgetCode = budgetCode,
            EntryType = entryType,
            QuarterCode = quarterCode,
            FYCode = fyCode,
            FYName = fyName,
            CreatedBy = createdBy,
            CreatedOn = createdOnOverride ?? DateTime.UtcNow,
            IsActive = true,

            ProductCode = productCode ?? (source != null ? source.ProductCode : 0),
            ProductName = productName ?? (source != null ? source.ProductName : ""),
            IssueType = issueTypeName ?? (source != null ? source.IssueType : ""),
            IndusCoverageGroupCode = indusCgCode ?? (source != null ? source.IndusCoverageGroupCode : 0),
            IndusCoverageGroupName = indusCgName ?? (source != null ? source.IndusCoverageGroupName : ""),

            ProjectName = !string.IsNullOrWhiteSpace(projectName) ? projectName.Trim() : (source != null ? source.ProjectName : ""),
            CompanyName = !string.IsNullOrWhiteSpace(companyName) ? companyName.Trim() : (source != null ? source.CompanyName : ""),
            IndustryName = !string.IsNullOrWhiteSpace(industryName) ? industryName.Trim() : (source != null ? source.IndustryName : ""),

            IndicativeDealSize = dealSize ?? (source != null ? source.IndicativeDealSize : 0),
            EstimatedFeePool = feePool ?? (source != null ? source.EstimatedFeePool : 0),
            TotalFees = totalFees ?? (source != null ? source.TotalFees : 0),
            NoOfBRLMs = noOfBRLMs ?? (source != null ? source.NoOfBRLMs : 0),
            JMFKeepRate = jmfKeepRate ?? (source != null ? source.JMFKeepRate : 0),
            JMFGrossFee = jmfGrossFee ?? (source != null ? source.JMFGrossFee : 0),
            DealProbability = dealProbability ?? (source != null ? source.DealProbability : 0),
            JMProbability = jmProbability ?? (source != null ? source.JMProbability : 0),
            ExpectedClosure = expectedClosure ?? (source != null ? source.ExpectedClosure : quarterCode),
            IsMandated = isMandated ?? (source != null && source.IsMandated),
            Remarks = remarks ?? (source != null ? source.Remarks : ""),
            Amount = amount ?? (source != null ? source.Amount : 0)
        };

        if (entryType == EntryType.Actual)
        {
            entry.Q1 = source != null ? source.Q1 : 0;
            entry.Q2 = source != null ? source.Q2 : 0;
            entry.Q3 = source != null ? source.Q3 : 0;
            entry.Q4 = source != null ? source.Q4 : 0;

            decimal actualValue = amount ?? ((q1 ?? 0) + (q2 ?? 0) + (q3 ?? 0) + (q4 ?? 0));
            if (quarterCode == 1) entry.Q1 = actualValue;
            else if (quarterCode == 2) entry.Q2 = actualValue;
            else if (quarterCode == 3) entry.Q3 = actualValue;
            else if (quarterCode == 4) entry.Q4 = actualValue;
            entry.Total = actualValue;
        }
        else
        {
            entry.Q1 = q1 ?? (source != null ? source.Q1 : 0);
            entry.Q2 = q2 ?? (source != null ? source.Q2 : 0);
            entry.Q3 = q3 ?? (source != null ? source.Q3 : 0);
            entry.Q4 = q4 ?? (source != null ? source.Q4 : 0);
            entry.Total = entry.Q1 + entry.Q2 + entry.Q3 + entry.Q4;
        }

        return BuildResult.Success(entry, priorSameStage?.Id);
    }

    private sealed class BuildResult
    {
        public bool Ok { get; private init; }
        public string? Error { get; private init; }
        public BudgetEntry? Entry { get; private init; }
        public int? SupersedesId { get; private init; }

        public static BuildResult Fail(string error) => new() { Ok = false, Error = error };
        public static BuildResult Success(BudgetEntry entry, int? supersedesId) => new() { Ok = true, Entry = entry, SupersedesId = supersedesId };
    }

    // ============================================================================
    // RAW DATA ACCESS HELPERS — every one of these calls a stored procedure.
    // ============================================================================

    private static async Task<List<BudgetEntry>> LoadActiveEntriesAsync(SqlConnection conn, SqlTransaction? tx, string? budgetCode)
    {
        await using var cmd = new SqlCommand("dbo.sp_BudgetEntries_GetActive", conn, tx) { CommandType = CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@BudgetCode", (object?)budgetCode ?? DBNull.Value);

        var list = new List<BudgetEntry>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            list.Add(MapEntry(reader));
        }
        return list;
    }

    private static async Task<List<BudgetEntry>> LoadActiveEntriesByFYAsync(SqlConnection conn, SqlTransaction? tx, int fyCode)
    {
        await using var cmd = new SqlCommand("dbo.sp_BudgetEntries_GetActiveByFY", conn, tx) { CommandType = CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@FYCode", fyCode);

        var list = new List<BudgetEntry>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            list.Add(MapEntry(reader));
        }
        return list;
    }

    private static async Task<BudgetEntry?> GetLatestActiveEntryAsync(SqlConnection conn, SqlTransaction? tx, string budgetCode, EntryType entryType, int? quarterCode)
    {
        await using var cmd = new SqlCommand("dbo.sp_BudgetEntries_GetLatestActive", conn, tx) { CommandType = CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@BudgetCode", budgetCode);
        cmd.Parameters.AddWithValue("@EntryType", (int)entryType);
        cmd.Parameters.AddWithValue("@QuarterCode", (object?)quarterCode ?? DBNull.Value);

        await using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync()) return MapEntry(reader);
        return null;
    }

    private static BudgetEntry MapEntry(SqlDataReader r)
    {
        return new BudgetEntry
        {
            Id = r.GetInt32(r.GetOrdinal("Id")),
            BudgetCode = r.GetString(r.GetOrdinal("BudgetCode")),
            ProductCode = r.GetInt32(r.GetOrdinal("ProductCode")),
            ProductName = r.GetString(r.GetOrdinal("ProductName")),
            IssueType = r.GetString(r.GetOrdinal("IssueType")),
            ProjectName = r.GetString(r.GetOrdinal("ProjectName")),
            CompanyName = r.GetString(r.GetOrdinal("CompanyName")),
            IndustryName = r.GetString(r.GetOrdinal("IndustryName")),
            IndusCoverageGroupCode = r.GetInt32(r.GetOrdinal("IndusCoverageGroupCode")),
            IndusCoverageGroupName = r.GetString(r.GetOrdinal("IndusCoverageGroupName")),
            FYCode = r.GetInt32(r.GetOrdinal("FYCode")),
            FYName = r.GetString(r.GetOrdinal("FYName")),
            QuarterCode = r.GetInt32(r.GetOrdinal("QuarterCode")),
            EntryType = (EntryType)r.GetInt32(r.GetOrdinal("EntryType")),
            IsMandated = r.GetBoolean(r.GetOrdinal("IsMandated")),
            IndicativeDealSize = r.GetDecimal(r.GetOrdinal("IndicativeDealSize")),
            EstimatedFeePool = r.GetDecimal(r.GetOrdinal("EstimatedFeePool")),
            TotalFees = r.GetDecimal(r.GetOrdinal("TotalFees")),
            NoOfBRLMs = r.GetInt32(r.GetOrdinal("NoOfBRLMs")),
            JMFKeepRate = r.GetDecimal(r.GetOrdinal("JMFKeepRate")),
            JMFGrossFee = r.GetDecimal(r.GetOrdinal("JMFGrossFee")),
            DealProbability = r.GetDecimal(r.GetOrdinal("DealProbability")),
            JMProbability = r.GetDecimal(r.GetOrdinal("JMProbability")),
            ExpectedClosure = r.GetInt32(r.GetOrdinal("ExpectedClosure")),
            Q1 = r.GetDecimal(r.GetOrdinal("Q1")),
            Q2 = r.GetDecimal(r.GetOrdinal("Q2")),
            Q3 = r.GetDecimal(r.GetOrdinal("Q3")),
            Q4 = r.GetDecimal(r.GetOrdinal("Q4")),
            Total = r.GetDecimal(r.GetOrdinal("Total")),
            Amount = r.GetDecimal(r.GetOrdinal("Amount")),
            Remarks = r.GetString(r.GetOrdinal("Remarks")),
            IsActive = r.GetBoolean(r.GetOrdinal("IsActive")),
            SupersedesId = r.IsDBNull(r.GetOrdinal("SupersedesId")) ? (int?)null : r.GetInt32(r.GetOrdinal("SupersedesId")),
            CreatedBy = r.GetInt32(r.GetOrdinal("CreatedBy")),
            CreatedOn = r.GetDateTime(r.GetOrdinal("CreatedOn"))
        };
    }

    private static async Task InsertEntryAsync(SqlConnection conn, SqlTransaction tx, BudgetEntry entry)
    {
        await using var cmd = new SqlCommand("dbo.sp_BudgetEntries_Insert", conn, tx) { CommandType = CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@BudgetCode", entry.BudgetCode);
        cmd.Parameters.AddWithValue("@ProductCode", entry.ProductCode);
        cmd.Parameters.AddWithValue("@ProductName", entry.ProductName);
        cmd.Parameters.AddWithValue("@IssueType", entry.IssueType);
        cmd.Parameters.AddWithValue("@ProjectName", entry.ProjectName);
        cmd.Parameters.AddWithValue("@CompanyName", entry.CompanyName);
        cmd.Parameters.AddWithValue("@IndustryName", entry.IndustryName);
        cmd.Parameters.AddWithValue("@IndusCoverageGroupCode", entry.IndusCoverageGroupCode);
        cmd.Parameters.AddWithValue("@IndusCoverageGroupName", entry.IndusCoverageGroupName);
        cmd.Parameters.AddWithValue("@FYCode", entry.FYCode);
        cmd.Parameters.AddWithValue("@FYName", entry.FYName);
        cmd.Parameters.AddWithValue("@QuarterCode", entry.QuarterCode);
        cmd.Parameters.AddWithValue("@EntryType", (int)entry.EntryType);
        cmd.Parameters.AddWithValue("@IsMandated", entry.IsMandated);
        cmd.Parameters.AddWithValue("@IndicativeDealSize", entry.IndicativeDealSize);
        cmd.Parameters.AddWithValue("@EstimatedFeePool", entry.EstimatedFeePool);
        cmd.Parameters.AddWithValue("@TotalFees", entry.TotalFees);
        cmd.Parameters.AddWithValue("@NoOfBRLMs", entry.NoOfBRLMs);
        cmd.Parameters.AddWithValue("@JMFKeepRate", entry.JMFKeepRate);
        cmd.Parameters.AddWithValue("@JMFGrossFee", entry.JMFGrossFee);
        cmd.Parameters.AddWithValue("@DealProbability", entry.DealProbability);
        cmd.Parameters.AddWithValue("@JMProbability", entry.JMProbability);
        cmd.Parameters.AddWithValue("@ExpectedClosure", entry.ExpectedClosure);
        cmd.Parameters.AddWithValue("@Q1", entry.Q1);
        cmd.Parameters.AddWithValue("@Q2", entry.Q2);
        cmd.Parameters.AddWithValue("@Q3", entry.Q3);
        cmd.Parameters.AddWithValue("@Q4", entry.Q4);
        cmd.Parameters.AddWithValue("@Total", entry.Total);
        cmd.Parameters.AddWithValue("@Amount", entry.Amount);
        cmd.Parameters.AddWithValue("@Remarks", entry.Remarks);
        cmd.Parameters.AddWithValue("@SupersedesId", (object?)entry.SupersedesId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@CreatedBy", entry.CreatedBy);
        cmd.Parameters.AddWithValue("@CreatedOn", entry.CreatedOn);

        var newIdParam = new SqlParameter("@NewId", SqlDbType.Int) { Direction = ParameterDirection.Output };
        cmd.Parameters.Add(newIdParam);

        await cmd.ExecuteNonQueryAsync();
        entry.Id = (int)newIdParam.Value;
    }

    private static async Task MarkSupersededAsync(SqlConnection conn, SqlTransaction tx, int id)
    {
        await using var cmd = new SqlCommand("dbo.sp_BudgetEntries_MarkSuperseded", conn, tx) { CommandType = CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@Id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    private static async Task<string?> GetFinancialYearNameAsync(SqlConnection conn, SqlTransaction? tx, int fyCode)
    {
        await using var cmd = new SqlCommand("dbo.sp_FinancialYear_GetName", conn, tx) { CommandType = CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@FYCode", fyCode);
        var result = await cmd.ExecuteScalarAsync();
        return result == null || result is DBNull ? null : (string)result;
    }

    /// <summary>@lookupType is one of "Product" | "IssueType" | "IndustryGroup".</summary>
    private static async Task<string?> GetLookupNameAsync(SqlConnection conn, SqlTransaction? tx, string lookupType, int code)
    {
        await using var cmd = new SqlCommand("dbo.sp_Lookup_GetName", conn, tx) { CommandType = CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@LookupType", lookupType);
        cmd.Parameters.AddWithValue("@Code", code);
        var result = await cmd.ExecuteScalarAsync();
        return result == null || result is DBNull ? null : (string)result;
    }

    private static async Task<string> GenerateNextBudgetCodeAsync(SqlConnection conn, SqlTransaction tx, int fyCode)
    {
        var prefix = $"BUD-FY{fyCode}-";
        await using var cmd = new SqlCommand("dbo.sp_BudgetEntries_GetNextCode", conn, tx) { CommandType = CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@Prefix", prefix);
        var nextCodeParam = new SqlParameter("@NextCode", SqlDbType.NVarChar, 30) { Direction = ParameterDirection.Output };
        cmd.Parameters.Add(nextCodeParam);

        await cmd.ExecuteNonQueryAsync();
        return (string)nextCodeParam.Value;
    }

    private static int? ParseQuarterText(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        var t = text.Trim().ToUpperInvariant();
        if (t == "Q1" || t == "1") return 1;
        if (t == "Q2" || t == "2") return 2;
        if (t == "Q3" || t == "3") return 3;
        if (t == "Q4" || t == "4") return 4;
        return null;
    }

    private static SaveResultDto Fail(string message) => new() { Success = false, Message = message };
}
