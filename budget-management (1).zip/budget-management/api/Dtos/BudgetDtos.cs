namespace BudgetManagement.Api.Dtos;

// ---------- Lookups -----------------------------------------------------------

public record LookupDto(int Code, string Name);

// ---------- Grid (list) --------------------------------------------------------

public class BudgetGridRowDto
{
    public string BudgetCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string IssueType { get; set; } = string.Empty;
    public string ProjectOrCompany { get; set; } = string.Empty;
    public string IndustryName { get; set; } = string.Empty;
    public string IndusCoverageGroupName { get; set; } = string.Empty;
    public string FYName { get; set; } = string.Empty;
    public bool IsMandated { get; set; }
    public decimal IndicativeDealSize { get; set; }
    public decimal DealProbability { get; set; }
    public decimal BudgetTotal { get; set; }
    public decimal? EstimationTotal { get; set; }
    public decimal? ActualTotal { get; set; }
    /// <summary>Highest stage reached: Budget / Estimation / Actual.</summary>
    public string Stage { get; set; } = string.Empty;
}

// ---------- Detail (modal) ------------------------------------------------------

public class QuarterFigureDto
{
    public int QuarterCode { get; set; }
    public string QuarterLabel { get; set; } = string.Empty;
    public decimal? Budget { get; set; }
    public decimal? Estimation { get; set; }
    public decimal? Actual { get; set; }
}

public class BudgetDetailDto
{
    public string BudgetCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string IssueType { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public string CompanyName { get; set; } = string.Empty;
    public string IndustryName { get; set; } = string.Empty;
    public string IndusCoverageGroupName { get; set; } = string.Empty;
    public string FYName { get; set; } = string.Empty;
    public bool IsMandated { get; set; }
    public decimal IndicativeDealSize { get; set; }
    public decimal EstimatedFeePool { get; set; }
    public decimal TotalFees { get; set; }
    public int NoOfBRLMs { get; set; }
    public decimal JMFKeepRate { get; set; }
    public decimal JMFGrossFee { get; set; }
    public decimal DealProbability { get; set; }
    public decimal JMProbability { get; set; }
    public int ExpectedClosure { get; set; }

    public List<QuarterFigureDto> Quarters { get; set; } = new();

    public decimal BudgetTotal { get; set; }
    public decimal EstimationTotal { get; set; }
    public decimal ActualTotal { get; set; }
}

// ---------- Single entry add/edit ------------------------------------------------

public class BudgetEntryInputDto
{
    /// <summary>Leave blank for a brand-new Budget Code (auto-generated). Required for Estimation/Actual.</summary>
    public string? BudgetCode { get; set; }

    public int EntryType { get; set; }          // 1 Budget / 2 Estimation / 3 Actual
    public int QuarterCode { get; set; }         // 1-4
    public int FYCode { get; set; }
    public int CreatedBy { get; set; } = 1;      // no auth in this demo — fixed "system" user

    public int? ProductCode { get; set; }
    public int? ProdIssueTypeCode { get; set; }
    public int? IndusCGCode { get; set; }

    public string? ProjectName { get; set; }
    public string? CompanyName { get; set; }
    public string? IndustryName { get; set; }

    public decimal? IndicativeDealSize { get; set; }
    public decimal? EstimatedFeePool { get; set; }
    public decimal? TotalFees { get; set; }
    public int? NoOfBRLMs { get; set; }
    public decimal? JMFKeepRate { get; set; }
    public decimal? JMFGrossFee { get; set; }
    public decimal? DealProbability { get; set; }
    public decimal? JMProbability { get; set; }
    public int? ExpectedClosure { get; set; }

    public decimal? Q1 { get; set; }
    public decimal? Q2 { get; set; }
    public decimal? Q3 { get; set; }
    public decimal? Q4 { get; set; }
    public decimal? Amount { get; set; }

    public bool? IsMandated { get; set; }
    public string? Remarks { get; set; }
}

public class SaveResultDto
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public string? BudgetCode { get; set; }
}

// ---------- Bulk (Excel) upload --------------------------------------------------

public class BulkUploadRequestDto
{
    public int EntryType { get; set; }
    public int QuarterCode { get; set; }
    public int FYCode { get; set; }
    public int CreatedBy { get; set; } = 1;
    public List<BulkUploadRowDto> Rows { get; set; } = new();
}

public class BulkUploadRowDto
{
    public int RowNumber { get; set; }
    public string? BudgetCode { get; set; }
    public string? IndusCoverageGroup { get; set; }
    public string? PitchedOrMandated { get; set; }
    public string? ProjectName { get; set; }
    public string? MandatedCompany { get; set; }
    public string? Industry { get; set; }
    public string? Product { get; set; }
    public string? IssueType { get; set; }
    public decimal? IndicativeDealSize { get; set; }
    public decimal? EstimatedFeePool { get; set; }
    public decimal? TotalFees { get; set; }
    public int? NoOfBRLMs { get; set; }
    public decimal? JMFKeepRate { get; set; }
    public decimal? JMFGrossFee { get; set; }
    public decimal? DealProbability { get; set; }
    public decimal? JMProbability { get; set; }
    public string? ExpectedClosure { get; set; }   // "Q1".."Q4"
    public decimal? Q1 { get; set; }
    public decimal? Q2 { get; set; }
    public decimal? Q3 { get; set; }
    public decimal? Q4 { get; set; }
    public decimal? Total { get; set; }
    public string? Quarter { get; set; }            // "Q1".."Q4" - must match header QuarterCode
    public decimal? Amount { get; set; }
}

public class BulkUploadRowResultDto
{
    public int RowNumber { get; set; }
    public string? BudgetCode { get; set; }
    public bool Success { get; set; }
    public string? ErrorMessage { get; set; }
}

public class BulkUploadResponseDto
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public List<BulkUploadRowResultDto> Rows { get; set; } = new();
}
