using BudgetManagement.Api.Data;
using BudgetManagement.Api.Services;

var builder = WebApplication.CreateBuilder(args);

// ---- Services --------------------------------------------------------------------

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "Budget Management API",
        Version = "v1",
        Description = "No authentication — simple JSON in / JSON out API for the Budget Management demo. Data access is plain ADO.NET (Microsoft.Data.SqlClient), no EF Core / LINQ-to-SQL."
    });
});

builder.Services.AddSingleton<ISqlConnectionFactory, SqlConnectionFactory>();
builder.Services.AddScoped<IBudgetService, BudgetService>();

var allowedOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>()
                     ?? new[] { "http://localhost:4200" };

builder.Services.AddCors(options =>
{
    options.AddPolicy("AngularClient", policy =>
    {
        policy.WithOrigins(allowedOrigins)
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

var app = builder.Build();

// ---- DB: create database + tables (raw DDL) and seed sample data, all via ADO.NET ----

var connectionString = app.Configuration.GetConnectionString("Default")
    ?? throw new InvalidOperationException("Missing 'ConnectionStrings:Default' in appsettings.json.");
await DbInitializer.InitializeAsync(connectionString, app.Environment.ContentRootPath);

// ---- Pipeline ----------------------------------------------------------------------

app.UseSwagger();
app.UseSwaggerUI(); // available at /swagger in every environment for this demo

app.UseCors("AngularClient");
app.UseAuthorization();
app.MapControllers();

app.Run();
