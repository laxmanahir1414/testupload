namespace BudgetManagement.Api.Models;

/// <summary>
/// Entry-type lifecycle: 1 = Budget, 2 = Estimation, 3 = Actual.
/// The first entry ever made for a Budget Code is always a Budget.
/// After that, new entries are Estimation (any quarter) or Actual
/// (only for a quarter that already has an Estimation, or a Budget
/// if no Estimation was ever made for that quarter).
/// </summary>
public enum EntryType
{
    Budget = 1,
    Estimation = 2,
    Actual = 3
}

/// <summary>
/// One saved version of a budget line. A given (BudgetCode, EntryType, QuarterCode)
/// combination can have many rows over time — only the newest one has IsActive = true,
/// older ones are kept (IsActive = false) for history via the Supersedes chain.
/// </summary>
public class BudgetEntry
{
    public int Id { get; set; }

    public string BudgetCode { get; set; } = string.Empty;

    public int ProductCode { get; set; }
    public string ProductName { get; set; } = string.Empty;

    public string IssueType { get; set; } = string.Empty;

    public string ProjectName { get; set; } = string.Empty;
    public string CompanyName { get; set; } = string.Empty;
    public string IndustryName { get; set; } = string.Empty;

    public int IndusCoverageGroupCode { get; set; }
    public string IndusCoverageGroupName { get; set; } = string.Empty;

    public int FYCode { get; set; }
    public string FYName { get; set; } = string.Empty;

    /// <summary>Quarter this version was recorded "as of" (1-4).</summary>
    public int QuarterCode { get; set; }

    public EntryType EntryType { get; set; }

    public bool IsMandated { get; set; }

    public decimal IndicativeDealSize { get; set; }
    public decimal EstimatedFeePool { get; set; }
    public decimal TotalFees { get; set; }
    public int NoOfBRLMs { get; set; }
    public decimal JMFKeepRate { get; set; }
    public decimal JMFGrossFee { get; set; }
    public decimal DealProbability { get; set; }
    public decimal JMProbability { get; set; }

    /// <summary>Expected closure quarter (1-4).</summary>
    public int ExpectedClosure { get; set; }

    public decimal Q1 { get; set; }
    public decimal Q2 { get; set; }
    public decimal Q3 { get; set; }
    public decimal Q4 { get; set; }
    public decimal Total { get; set; }

    /// <summary>Total fee amount for this version (used for Actual quarter-split, matches the "Amount" excel column).</summary>
    public decimal Amount { get; set; }

    public string Remarks { get; set; } = string.Empty;

    /// <summary>True only for the newest version of this (BudgetCode, EntryType, QuarterCode) combination.</summary>
    public bool IsActive { get; set; } = true;

    public int? SupersedesId { get; set; }

    public int CreatedBy { get; set; }
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
}
