namespace BudgetManagement.Api.Models;

public class Product
{
    public int Code { get; set; }
    public string Name { get; set; } = string.Empty;
}

public class IssueTypeMaster
{
    public int Code { get; set; }
    public string Name { get; set; } = string.Empty;
}

public class IndustryCoverageGroup
{
    public int Code { get; set; }
    public string Name { get; set; } = string.Empty;
}

public class FinancialYear
{
    public int Code { get; set; }
    public string Name { get; set; } = string.Empty;
    public bool IsCurrent { get; set; }
}
