using Microsoft.Data.SqlClient;

namespace BudgetManagement.Api.Data;

/// <summary>
/// Runs the real .sql files under api/Database/ at startup — nothing is embedded as a
/// C# string. 01_schema.sql and 02_seed_data.sql are each a single batch; 03_stored_procedures.sql
/// contains one CREATE OR ALTER PROCEDURE per "GO"-separated batch, so it's split on GO
/// and each batch is executed individually (ADO.NET has no built-in concept of "GO" —
/// that's a client-tool-only separator, not valid T-SQL by itself).
/// </summary>
public static class DbInitializer
{
    public static async Task InitializeAsync(string connectionString, string contentRootPath)
    {
        var builder = new SqlConnectionStringBuilder(connectionString);
        var databaseName = builder.InitialCatalog;
        if (string.IsNullOrWhiteSpace(databaseName))
            throw new InvalidOperationException("The connection string must specify an Initial Catalog / Database.");

        // 1) create the database if it doesn't exist yet (connect to 'master' to do this)
        var masterBuilder = new SqlConnectionStringBuilder(connectionString) { InitialCatalog = "master" };
        await using (var masterConn = new SqlConnection(masterBuilder.ConnectionString))
        {
            await masterConn.OpenAsync();
            await using var createDbCmd = new SqlCommand(
                "IF DB_ID(@dbName) IS NULL EXEC('CREATE DATABASE [' + @dbName + ']');",
                masterConn);
            createDbCmd.Parameters.AddWithValue("@dbName", databaseName);
            await createDbCmd.ExecuteNonQueryAsync();
        }

        // 2) run the real .sql scripts, in order
        var databaseFolder = Path.Combine(contentRootPath, "Database");

        await using var conn = new SqlConnection(connectionString);
        await conn.OpenAsync();

        await RunSqlFileAsync(conn, Path.Combine(databaseFolder, "01_schema.sql"));
        await RunSqlFileAsync(conn, Path.Combine(databaseFolder, "03_stored_procedures.sql"));
        await RunSqlFileAsync(conn, Path.Combine(databaseFolder, "02_seed_data.sql")); // self-guarding, safe to re-run
    }

    private static async Task RunSqlFileAsync(SqlConnection conn, string path)
    {
        if (!File.Exists(path))
            throw new FileNotFoundException($"Required SQL script not found: {path}");

        var script = await File.ReadAllTextAsync(path);

        foreach (var batch in SplitOnGo(script))
        {
            if (string.IsNullOrWhiteSpace(batch)) continue;
            await using var cmd = new SqlCommand(batch, conn) { CommandTimeout = 60 };
            await cmd.ExecuteNonQueryAsync();
        }
    }

    /// <summary>Splits a .sql script on lines that contain only "GO" (case-insensitive), the
    /// same convention SSMS/sqlcmd use as a batch separator.</summary>
    private static List<string> SplitOnGo(string script)
    {
        var batches = new List<string>();
        var current = new System.Text.StringBuilder();

        foreach (var rawLine in script.Replace("\r\n", "\n").Split('\n'))
        {
            if (rawLine.Trim().Equals("GO", StringComparison.OrdinalIgnoreCase))
            {
                batches.Add(current.ToString());
                current.Clear();
            }
            else
            {
                current.AppendLine(rawLine);
            }
        }
        batches.Add(current.ToString());
        return batches;
    }
}
