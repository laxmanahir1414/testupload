using Microsoft.Data.SqlClient;

namespace BudgetManagement.Api.Data;

public interface ISqlConnectionFactory
{
    string ConnectionString { get; }
    SqlConnection CreateConnection();
}

public class SqlConnectionFactory : ISqlConnectionFactory
{
    public string ConnectionString { get; }

    public SqlConnectionFactory(IConfiguration configuration)
    {
        ConnectionString = configuration.GetConnectionString("Default")
            ?? throw new InvalidOperationException("Missing 'ConnectionStrings:Default' in appsettings.json.");
    }

    public SqlConnection CreateConnection() => new(ConnectionString);
}
