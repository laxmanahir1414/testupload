/* ============================================================================
   Budget Management System — 02_seed_data.sql
   Self-guarding: does nothing if dbo.Products already has rows. Safe to re-run.
   ============================================================================ */

IF NOT EXISTS (SELECT 1 FROM dbo.Products)
BEGIN
    INSERT INTO dbo.Products (Code, Name) VALUES
        (1, N'Capital Market'),
        (2, N'Debt Advisory'),
        (3, N'M&A Advisory'),
        (4, N'Private Equity');

    INSERT INTO dbo.IssueTypes (Code, Name) VALUES
        (1, N'IPO'),
        (2, N'QIP'),
        (3, N'Rights Issue'),
        (4, N'Open Offer'),
        (5, N'Buyback'),
        (6, N'NCD');

    INSERT INTO dbo.IndustryCoverageGroups (Code, Name) VALUES
        (1, N'Consumer'),
        (2, N'Financial Institutions'),
        (3, N'Industrials'),
        (4, N'Technology');

    INSERT INTO dbo.FinancialYears (Code, Name, IsCurrent) VALUES
        (2026, N'FY 2025-26', 1);

    DECLARE @Now DATETIME2 = SYSUTCDATETIME();

    -- BUD-FY26-00001: Budget (Q1) -> Estimation -> Actual (Q1)
    INSERT INTO dbo.BudgetEntries
        (BudgetCode, ProductCode, ProductName, IssueType, ProjectName, CompanyName, IndustryName,
         IndusCoverageGroupCode, IndusCoverageGroupName, FYCode, FYName, QuarterCode, EntryType,
         IsMandated, IndicativeDealSize, EstimatedFeePool, TotalFees, NoOfBRLMs, JMFKeepRate, JMFGrossFee,
         DealProbability, JMProbability, ExpectedClosure, Q1, Q2, Q3, Q4, Total, Amount, Remarks,
         IsActive, SupersedesId, CreatedBy, CreatedOn)
    VALUES
        (N'BUD-FY26-00001', 1, N'Capital Market', N'IPO', N'Ganesh Tech', N'', N'Digital Marketing',
         1, N'Consumer', 2026, N'FY 2025-26', 1, 1,
         0, 500, 25, 125, 4, 25, 31.25, 90, 80, 2, 5, 17.5, 0, 0, 22.5, 22.5, N'',
         1, NULL, 1, @Now);

    INSERT INTO dbo.BudgetEntries
        (BudgetCode, ProductCode, ProductName, IssueType, ProjectName, CompanyName, IndustryName,
         IndusCoverageGroupCode, IndusCoverageGroupName, FYCode, FYName, QuarterCode, EntryType,
         IsMandated, IndicativeDealSize, EstimatedFeePool, TotalFees, NoOfBRLMs, JMFKeepRate, JMFGrossFee,
         DealProbability, JMProbability, ExpectedClosure, Q1, Q2, Q3, Q4, Total, Amount, Remarks,
         IsActive, SupersedesId, CreatedBy, CreatedOn)
    VALUES
        (N'BUD-FY26-00001', 1, N'Capital Market', N'IPO', N'Ganesh Tech', N'', N'Digital Marketing',
         1, N'Consumer', 2026, N'FY 2025-26', 2, 2,
         1, 520, 25, 130, 4, 25, 32.5, 95, 85, 3, 5, 0, 20, 0, 25, 25, N'',
         1, NULL, 1, DATEADD(DAY, 30, @Now));

    INSERT INTO dbo.BudgetEntries
        (BudgetCode, ProductCode, ProductName, IssueType, ProjectName, CompanyName, IndustryName,
         IndusCoverageGroupCode, IndusCoverageGroupName, FYCode, FYName, QuarterCode, EntryType,
         IsMandated, IndicativeDealSize, EstimatedFeePool, TotalFees, NoOfBRLMs, JMFKeepRate, JMFGrossFee,
         DealProbability, JMProbability, ExpectedClosure, Q1, Q2, Q3, Q4, Total, Amount, Remarks,
         IsActive, SupersedesId, CreatedBy, CreatedOn)
    VALUES
        (N'BUD-FY26-00001', 1, N'Capital Market', N'IPO', N'Ganesh Tech', N'', N'Digital Marketing',
         1, N'Consumer', 2026, N'FY 2025-26', 1, 3,
         1, 500, 25, 125, 4, 25, 31.25, 100, 100, 2, 4.8, 0, 0, 0, 4.8, 4.8, N'',
         1, NULL, 1, DATEADD(DAY, 35, @Now));

    -- BUD-FY26-00002: Budget only
    INSERT INTO dbo.BudgetEntries
        (BudgetCode, ProductCode, ProductName, IssueType, ProjectName, CompanyName, IndustryName,
         IndusCoverageGroupCode, IndusCoverageGroupName, FYCode, FYName, QuarterCode, EntryType,
         IsMandated, IndicativeDealSize, EstimatedFeePool, TotalFees, NoOfBRLMs, JMFKeepRate, JMFGrossFee,
         DealProbability, JMProbability, ExpectedClosure, Q1, Q2, Q3, Q4, Total, Amount, Remarks,
         IsActive, SupersedesId, CreatedBy, CreatedOn)
    VALUES
        (N'BUD-FY26-00002', 2, N'Debt Advisory', N'NCD', N'Team Tech', N'', N'Digital Marketing',
         1, N'Consumer', 2026, N'FY 2025-26', 1, 1,
         0, 600, 25, 125, 4, 25, 31.25, 90, 80, 2, 5, 17.5, 0, 0, 22.5, 22.5, N'',
         1, NULL, 1, @Now);

    -- BUD-FY26-00003: Budget -> Estimation
    INSERT INTO dbo.BudgetEntries
        (BudgetCode, ProductCode, ProductName, IssueType, ProjectName, CompanyName, IndustryName,
         IndusCoverageGroupCode, IndusCoverageGroupName, FYCode, FYName, QuarterCode, EntryType,
         IsMandated, IndicativeDealSize, EstimatedFeePool, TotalFees, NoOfBRLMs, JMFKeepRate, JMFGrossFee,
         DealProbability, JMProbability, ExpectedClosure, Q1, Q2, Q3, Q4, Total, Amount, Remarks,
         IsActive, SupersedesId, CreatedBy, CreatedOn)
    VALUES
        (N'BUD-FY26-00003', 3, N'M&A Advisory', N'Buyback', N'', N'Orion Industries', N'Manufacturing',
         3, N'Industrials', 2026, N'FY 2025-26', 1, 1,
         1, 300, 20, 60, 2, 30, 18, 70, 60, 4, 0, 10, 10, 10, 30, 30, N'',
         1, NULL, 1, @Now);

    INSERT INTO dbo.BudgetEntries
        (BudgetCode, ProductCode, ProductName, IssueType, ProjectName, CompanyName, IndustryName,
         IndusCoverageGroupCode, IndusCoverageGroupName, FYCode, FYName, QuarterCode, EntryType,
         IsMandated, IndicativeDealSize, EstimatedFeePool, TotalFees, NoOfBRLMs, JMFKeepRate, JMFGrossFee,
         DealProbability, JMProbability, ExpectedClosure, Q1, Q2, Q3, Q4, Total, Amount, Remarks,
         IsActive, SupersedesId, CreatedBy, CreatedOn)
    VALUES
        (N'BUD-FY26-00003', 3, N'M&A Advisory', N'Buyback', N'', N'Orion Industries', N'Manufacturing',
         3, N'Industrials', 2026, N'FY 2025-26', 2, 2,
         1, 320, 20, 64, 2, 30, 19.2, 75, 65, 4, 0, 0, 15, 15, 30, 30, N'',
         1, NULL, 1, DATEADD(DAY, 28, @Now));
END;
