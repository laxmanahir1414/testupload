/* ============================================================================
   Budget Management System — 01_schema.sql
   Run this against your target database (or just start the API — it runs this
   same file automatically on first launch; see Data/DbInitializer.cs).
   Safe to re-run: every CREATE is guarded by an existence check.
   ============================================================================ */

IF OBJECT_ID('dbo.Products', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Products (
        Code INT NOT NULL PRIMARY KEY,
        Name NVARCHAR(200) NOT NULL
    );
END;

IF OBJECT_ID('dbo.IssueTypes', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.IssueTypes (
        Code INT NOT NULL PRIMARY KEY,
        Name NVARCHAR(200) NOT NULL
    );
END;

IF OBJECT_ID('dbo.IndustryCoverageGroups', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.IndustryCoverageGroups (
        Code INT NOT NULL PRIMARY KEY,
        Name NVARCHAR(200) NOT NULL
    );
END;

IF OBJECT_ID('dbo.FinancialYears', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.FinancialYears (
        Code INT NOT NULL PRIMARY KEY,
        Name NVARCHAR(50) NOT NULL,
        IsCurrent BIT NOT NULL
    );
END;

/* ----------------------------------------------------------------------------
   BudgetEntries — one row per SAVED VERSION of a budget line.

   Business rule (per Budget Code, within its Financial Year):
     - EntryType 1 (Budget)     : entered exactly ONCE, in whichever quarter the
                                   user first enters it. Not repeated per quarter.
     - EntryType 2 (Estimation) : a single, ongoing revision of the Budget —
                                   entered after the Budget, and each new
                                   Estimation submission supersedes the PREVIOUS
                                   Estimation regardless of which quarter either
                                   one was made in (versioning key = BudgetCode
                                   only, NOT BudgetCode+Quarter).
     - EntryType 3 (Actual)     : genuinely quarter-specific — one Actual per
                                   quarter, versioned independently per quarter
                                   (versioning key = BudgetCode + Quarter). The
                                   first Actual is compared against the Budget;
                                   once an Estimation exists, later Actuals are
                                   compared against the latest Estimation instead.

   QuarterCode always means "the quarter this particular version was recorded
   in / applies to" — for Budget and Estimation that's just informational
   (the row itself still carries the full Q1..Q4 split); for Actual it's the
   specific quarter this figure belongs to.
   ---------------------------------------------------------------------------- */
IF OBJECT_ID('dbo.BudgetEntries', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.BudgetEntries (
        Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        BudgetCode NVARCHAR(30) NOT NULL,
        ProductCode INT NOT NULL,
        ProductName NVARCHAR(200) NOT NULL,
        IssueType NVARCHAR(200) NOT NULL,
        ProjectName NVARCHAR(200) NOT NULL,
        CompanyName NVARCHAR(200) NOT NULL,
        IndustryName NVARCHAR(200) NOT NULL,
        IndusCoverageGroupCode INT NOT NULL,
        IndusCoverageGroupName NVARCHAR(200) NOT NULL,
        FYCode INT NOT NULL,
        FYName NVARCHAR(50) NOT NULL,
        QuarterCode INT NOT NULL,
        EntryType INT NOT NULL,          -- 1 Budget / 2 Estimation / 3 Actual
        IsMandated BIT NOT NULL,
        IndicativeDealSize DECIMAL(18,2) NOT NULL,
        EstimatedFeePool DECIMAL(5,2) NOT NULL,
        TotalFees DECIMAL(18,2) NOT NULL,
        NoOfBRLMs INT NOT NULL,
        JMFKeepRate DECIMAL(5,2) NOT NULL,
        JMFGrossFee DECIMAL(18,2) NOT NULL,
        DealProbability DECIMAL(5,2) NOT NULL,
        JMProbability DECIMAL(5,2) NOT NULL,
        ExpectedClosure INT NOT NULL,
        Q1 DECIMAL(18,2) NOT NULL,
        Q2 DECIMAL(18,2) NOT NULL,
        Q3 DECIMAL(18,2) NOT NULL,
        Q4 DECIMAL(18,2) NOT NULL,
        Total DECIMAL(18,2) NOT NULL,
        Amount DECIMAL(18,2) NOT NULL,   -- fee amount for the quarter (used for Actual)
        Remarks NVARCHAR(200) NOT NULL,
        IsActive BIT NOT NULL,            -- only the current version of a (BudgetCode, EntryType[, Quarter for Actual]) is 1
        SupersedesId INT NULL,
        CreatedBy INT NOT NULL,
        CreatedOn DATETIME2 NOT NULL
    );

    CREATE INDEX IX_BudgetEntries_Lookup
        ON dbo.BudgetEntries (BudgetCode, EntryType, QuarterCode, IsActive);
END;
