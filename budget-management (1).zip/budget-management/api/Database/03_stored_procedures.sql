/* ============================================================================
   Budget Management System — 03_stored_procedures.sql
   Every one of these is called from Services/BudgetService.cs via plain ADO.NET
   (SqlCommand with CommandType.StoredProcedure) — there is no ORM and no SQL
   text built at runtime anywhere in the API.
   Run this after 01_schema.sql. Safe to re-run (CREATE OR ALTER).
   ============================================================================ */

-- ---------------------------------------------------------------------------
-- Lookups
-- ---------------------------------------------------------------------------

CREATE OR ALTER PROCEDURE dbo.sp_Products_GetAll
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Code, Name FROM dbo.Products ORDER BY Name;
END
GO

CREATE OR ALTER PROCEDURE dbo.sp_IssueTypes_GetAll
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Code, Name FROM dbo.IssueTypes ORDER BY Name;
END
GO

CREATE OR ALTER PROCEDURE dbo.sp_IndustryCoverageGroups_GetAll
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Code, Name FROM dbo.IndustryCoverageGroups ORDER BY Name;
END
GO

CREATE OR ALTER PROCEDURE dbo.sp_FinancialYears_GetAll
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Code, Name FROM dbo.FinancialYears ORDER BY Code DESC;
END
GO

CREATE OR ALTER PROCEDURE dbo.sp_FinancialYear_GetName
    @FYCode INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Name FROM dbo.FinancialYears WHERE Code = @FYCode;
END
GO

-- @LookupType is one of 'Product' | 'IssueType' | 'IndustryGroup' — fixed set,
-- selected in code from a literal, never built from request input, so a plain
-- IF/ELSE is used instead of dynamic SQL.
CREATE OR ALTER PROCEDURE dbo.sp_Lookup_GetName
    @LookupType NVARCHAR(20),
    @Code INT
AS
BEGIN
    SET NOCOUNT ON;
    IF @LookupType = 'Product'
        SELECT Name FROM dbo.Products WHERE Code = @Code;
    ELSE IF @LookupType = 'IssueType'
        SELECT Name FROM dbo.IssueTypes WHERE Code = @Code;
    ELSE IF @LookupType = 'IndustryGroup'
        SELECT Name FROM dbo.IndustryCoverageGroups WHERE Code = @Code;
    ELSE
        THROW 50000, 'Unknown lookup type.', 1;
END
GO

-- ---------------------------------------------------------------------------
-- BudgetEntries — reads
-- ---------------------------------------------------------------------------

-- All currently-active rows, optionally restricted to one Budget Code.
-- Used to build the grid (NULL) and the detail view (specific code).
CREATE OR ALTER PROCEDURE dbo.sp_BudgetEntries_GetActive
    @BudgetCode NVARCHAR(30) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT *
    FROM dbo.BudgetEntries
    WHERE IsActive = 1
      AND (@BudgetCode IS NULL OR BudgetCode = @BudgetCode);
END
GO

-- All currently-active rows for an entire Financial Year — used by the Excel
-- "Extract" feature (pull current Budget/Estimation data into a template).
CREATE OR ALTER PROCEDURE dbo.sp_BudgetEntries_GetActiveByFY
    @FYCode INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT *
    FROM dbo.BudgetEntries
    WHERE IsActive = 1
      AND FYCode = @FYCode;
END
GO

-- The current version of a (BudgetCode, EntryType) — pass @QuarterCode only for
-- Actual, where each quarter is versioned independently. For Budget and
-- Estimation, @QuarterCode must be NULL: there is only ever ONE current Budget
-- and ONE current Estimation per Budget Code, regardless of which quarter
-- either was entered in.
CREATE OR ALTER PROCEDURE dbo.sp_BudgetEntries_GetLatestActive
    @BudgetCode NVARCHAR(30),
    @EntryType INT,
    @QuarterCode INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (1) *
    FROM dbo.BudgetEntries
    WHERE BudgetCode = @BudgetCode
      AND EntryType = @EntryType
      AND IsActive = 1
      AND (@QuarterCode IS NULL OR QuarterCode = @QuarterCode)
    ORDER BY CreatedOn DESC, Id DESC;
END
GO

-- Next auto-generated Budget Code for a Financial Year, e.g. BUD-FY2026-00004.
CREATE OR ALTER PROCEDURE dbo.sp_BudgetEntries_GetNextCode
    @Prefix NVARCHAR(20),
    @NextCode NVARCHAR(30) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @MaxSuffix INT;

    SELECT @MaxSuffix = MAX(TRY_CONVERT(INT, SUBSTRING(BudgetCode, LEN(@Prefix) + 1, 10)))
    FROM dbo.BudgetEntries
    WHERE BudgetCode LIKE @Prefix + '%';

    SET @NextCode = @Prefix + RIGHT('00000' + CAST(ISNULL(@MaxSuffix, 0) + 1 AS VARCHAR(10)), 5);
END
GO

-- ---------------------------------------------------------------------------
-- BudgetEntries — writes
-- ---------------------------------------------------------------------------

CREATE OR ALTER PROCEDURE dbo.sp_BudgetEntries_Insert
    @BudgetCode NVARCHAR(30),
    @ProductCode INT,
    @ProductName NVARCHAR(200),
    @IssueType NVARCHAR(200),
    @ProjectName NVARCHAR(200),
    @CompanyName NVARCHAR(200),
    @IndustryName NVARCHAR(200),
    @IndusCoverageGroupCode INT,
    @IndusCoverageGroupName NVARCHAR(200),
    @FYCode INT,
    @FYName NVARCHAR(50),
    @QuarterCode INT,
    @EntryType INT,
    @IsMandated BIT,
    @IndicativeDealSize DECIMAL(18,2),
    @EstimatedFeePool DECIMAL(5,2),
    @TotalFees DECIMAL(18,2),
    @NoOfBRLMs INT,
    @JMFKeepRate DECIMAL(5,2),
    @JMFGrossFee DECIMAL(18,2),
    @DealProbability DECIMAL(5,2),
    @JMProbability DECIMAL(5,2),
    @ExpectedClosure INT,
    @Q1 DECIMAL(18,2),
    @Q2 DECIMAL(18,2),
    @Q3 DECIMAL(18,2),
    @Q4 DECIMAL(18,2),
    @Total DECIMAL(18,2),
    @Amount DECIMAL(18,2),
    @Remarks NVARCHAR(200),
    @SupersedesId INT = NULL,
    @CreatedBy INT,
    @CreatedOn DATETIME2,
    @NewId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.BudgetEntries
        (BudgetCode, ProductCode, ProductName, IssueType, ProjectName, CompanyName, IndustryName,
         IndusCoverageGroupCode, IndusCoverageGroupName, FYCode, FYName, QuarterCode, EntryType,
         IsMandated, IndicativeDealSize, EstimatedFeePool, TotalFees, NoOfBRLMs, JMFKeepRate, JMFGrossFee,
         DealProbability, JMProbability, ExpectedClosure, Q1, Q2, Q3, Q4, Total, Amount, Remarks,
         IsActive, SupersedesId, CreatedBy, CreatedOn)
    VALUES
        (@BudgetCode, @ProductCode, @ProductName, @IssueType, @ProjectName, @CompanyName, @IndustryName,
         @IndusCoverageGroupCode, @IndusCoverageGroupName, @FYCode, @FYName, @QuarterCode, @EntryType,
         @IsMandated, @IndicativeDealSize, @EstimatedFeePool, @TotalFees, @NoOfBRLMs, @JMFKeepRate, @JMFGrossFee,
         @DealProbability, @JMProbability, @ExpectedClosure, @Q1, @Q2, @Q3, @Q4, @Total, @Amount, @Remarks,
         1, @SupersedesId, @CreatedBy, @CreatedOn);

    SET @NewId = SCOPE_IDENTITY();
END
GO

CREATE OR ALTER PROCEDURE dbo.sp_BudgetEntries_MarkSuperseded
    @Id INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.BudgetEntries SET IsActive = 0 WHERE Id = @Id;
END
GO
