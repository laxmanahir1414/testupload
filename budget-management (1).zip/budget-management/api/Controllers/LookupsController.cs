using BudgetManagement.Api.Dtos;
using BudgetManagement.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace BudgetManagement.Api.Controllers;

[ApiController]
[Route("api/lookups")]
public class LookupsController : ControllerBase
{
    private readonly IBudgetService _service;

    public LookupsController(IBudgetService service)
    {
        _service = service;
    }

    [HttpGet("products")]
    public async Task<ActionResult<List<LookupDto>>> Products() => Ok(await _service.GetProductsAsync());

    [HttpGet("issue-types")]
    public async Task<ActionResult<List<LookupDto>>> IssueTypes() => Ok(await _service.GetIssueTypesAsync());

    [HttpGet("industry-groups")]
    public async Task<ActionResult<List<LookupDto>>> IndustryGroups() => Ok(await _service.GetIndustryGroupsAsync());

    [HttpGet("financial-years")]
    public async Task<ActionResult<List<LookupDto>>> FinancialYears() => Ok(await _service.GetFinancialYearsAsync());
}
