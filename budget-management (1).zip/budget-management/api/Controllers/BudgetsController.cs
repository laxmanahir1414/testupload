using BudgetManagement.Api.Dtos;
using BudgetManagement.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace BudgetManagement.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BudgetsController : ControllerBase
{
    private readonly IBudgetService _service;

    public BudgetsController(IBudgetService service)
    {
        _service = service;
    }

    /// <summary>Product-wise budget grid, with search + filters.</summary>
    [HttpGet]
    public async Task<ActionResult<List<BudgetGridRowDto>>> GetGrid(
        [FromQuery] string? search,
        [FromQuery] int? productCode,
        [FromQuery] int? fyCode,
        [FromQuery] int? quarterCode,
        [FromQuery] string? stage)
    {
        var result = await _service.GetGridAsync(search, productCode, fyCode, quarterCode, stage);
        return Ok(result);
    }

    /// <summary>Quarter-wise Budget / Estimation / Actual detail for one Budget Code (used by the view modal).</summary>
    [HttpGet("{budgetCode}")]
    public async Task<ActionResult<BudgetDetailDto>> GetDetail(string budgetCode)
    {
        var result = await _service.GetDetailAsync(budgetCode);
        if (result == null) return NotFound(new { message = $"Budget Code '{budgetCode}' was not found." });
        return Ok(result);
    }

    /// <summary>
    /// Excel "Extract" — returns every Budget Code's current state (latest Estimation if
    /// one exists, otherwise the original Budget) in the same row shape as the upload
    /// template, for the person to download as .xlsx, edit, and re-upload as Estimation
    /// or Actual. entryType is 2 (Estimation) or 3 (Actual) — both extract the same
    /// "current best known state" as their starting point.
    /// </summary>
    [HttpGet("extract")]
    public async Task<ActionResult<List<BulkUploadRowDto>>> Extract([FromQuery] int entryType, [FromQuery] int fyCode)
    {
        if (entryType != 2 && entryType != 3)
            return BadRequest(new { message = "entryType must be 2 (Estimation) or 3 (Actual)." });

        var rows = await _service.ExtractTemplateAsync(entryType, fyCode);
        return Ok(rows);
    }

    /// <summary>Add a new Budget, or add/version an Estimation or Actual entry.</summary>
    [HttpPost("entry")]
    public async Task<ActionResult<SaveResultDto>> AddOrVersionEntry([FromBody] BudgetEntryInputDto input)
    {
        var result = await _service.AddOrVersionEntryAsync(input);
        if (!result.Success) return BadRequest(result);
        return Ok(result);
    }

    /// <summary>Bulk Excel upload — validates every row first; saves all rows only if all rows pass.</summary>
    [HttpPost("upload")]
    public async Task<ActionResult<BulkUploadResponseDto>> BulkUpload([FromBody] BulkUploadRequestDto request)
    {
        var result = await _service.BulkUploadAsync(request);
        return Ok(result); // 200 either way — the payload's Success flag + per-row errors drive the UI
    }
}
