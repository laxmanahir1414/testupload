# Budget Management System — Angular + ASP.NET Core (ADO.NET + stored procedures)

A complete, runnable Budget / Estimation / Actual management app.

- **No authentication** (as requested) — every endpoint is open, plain JSON in / JSON out.
- **API**: ASP.NET Core 8 with **plain ADO.NET** (`Microsoft.Data.SqlClient`) calling
  real **stored procedures** — no Entity Framework, no LINQ-to-SQL, no LINQ query
  operators anywhere in the code, and no SQL text embedded in C# strings. Every table,
  procedure and seed row lives in an actual `.sql` file under `api/Database/`, which the
  API runs as-is at startup (and which you can just as easily run yourself in SSMS).
- **UI**: Angular 17 (standalone components, no NgModules), with:
  - A product-wise **Budget grid** with search + filters (Product, Financial Year, Quarter, Stage)
  - A **View** button on every row opening a modal with **quarter-wise Budget vs.
    Estimation vs. Actual**
  - A **New Entry** modal for a single Budget / Estimation / Actual record
  - An **Upload Excel** modal — for Budget, downloads a blank template; for Estimation
    and Actual, **extracts the current data straight from the database** into the same
    template so you edit real figures instead of starting blank (see workflow below)

```
budget-management/
  api/
    Database/             REAL .sql files — schema, stored procedures, seed data
    Controllers/           HTTP endpoints
    Services/               ADO.NET + business logic (BudgetService.cs)
    Data/                    SqlConnectionFactory + DbInitializer (runs the .sql files)
    Models/, Dtos/
  angular-client/         Angular 17 app (npm-installed + build-tested in the sandbox
                          this was built in — you just need Node.js 18+ locally)
```

---

## 1. Set up SQL Server

Requires SQL Server (Developer/Express edition is fine, local or remote). You do **not**
need to run anything manually — the API runs the real `.sql` scripts in
`api/Database/` for you on first launch (in order: `01_schema.sql`,
`03_stored_procedures.sql`, `02_seed_data.sql`). If you'd rather set it up yourself,
just run those three files in SSMS, in that order, against your target database.

Check the connection string in `api/appsettings.json`:

```
Server=localhost;Database=BudgetManagementDemo;Trusted_Connection=True;TrustServerCertificate=True;
```

- `Server=` → your SQL Server instance (`localhost`, `localhost\SQLEXPRESS`, a remote
  host, a named instance…).
- `Database=` → any name; created automatically if it doesn't exist.
- Not using Windows auth? Replace `Trusted_Connection=True` with `User Id=...;Password=...`.

## 2. Run the API

Requires the **.NET 8 SDK**.

```bash
cd api
dotnet restore
dotnet run
```

- Starts on **http://localhost:5080**; Swagger UI at `http://localhost:5080/swagger`.
- On first run it creates the database, runs the schema + stored-procedure scripts, and
  seeds 3 sample Budget Codes so the grid isn't empty.
- To reset all data, drop the `BudgetManagementDemo` database in SSMS and run again.
- **Every stored procedure is in `api/Database/03_stored_procedures.sql`** —
  `sp_BudgetEntries_GetActive`, `sp_BudgetEntries_GetLatestActive`,
  `sp_BudgetEntries_Insert`, `sp_BudgetEntries_MarkSuperseded`,
  `sp_BudgetEntries_GetNextCode`, plus lookup procs. `Services/BudgetService.cs` calls
  each one via `SqlCommand` with `CommandType.StoredProcedure` — open it side-by-side
  with the `.sql` file and every call maps 1:1 to a procedure.

## 3. Run the Angular app

Requires **Node.js 18+**.

```bash
cd angular-client
npm install
npm start
```

Opens on **http://localhost:4200**. API base URL is set in
`src/app/services/budget.service.ts` (`API_BASE_URL`).

---

## The Budget → Estimation → Actual workflow

This is the core rule set, enforced in `Services/BudgetService.cs` and mirrored in the
stored procedures:

1. **Budget** is entered **exactly once** per Budget Code, in whichever quarter you
   first enter it (Q1, Q2 — any one quarter). A second attempt to enter Budget for the
   same code is rejected; corrections go through Estimation instead. Budget is entered
   via the Excel upload with a **blank template** (`Download Template` in the Budget tab).

2. **Estimation** is a single, ongoing revision of the Budget for the *rest* of the
   quarters — not re-entered per quarter. Every new Estimation submission supersedes the
   *previous* Estimation, no matter which quarter either was made in. To enter it via
   Excel, pick the **Estimation** tab and click **Extract Current Data**: this pulls
   every Budget Code's current figures (latest Estimation if one exists, otherwise the
   original Budget) into the same template, already filled in — you edit only what
   changed, then upload.

3. **Actual** is genuinely quarter-specific — one Actual figure per quarter, versioned
   independently per quarter. The **first** Actual for a Budget Code is compared against
   the **Budget**; once an Estimation exists, later Actuals compare against the **latest
   Estimation** instead. To enter it via Excel, pick the **Actual** tab and click
   **Extract Current Data** — same idea: pulls Budget/Estimation figures as your
   baseline, you fill in the real `Amount` per quarter, then upload.

Both the **Extract** and the plain **Download Template** button live in the same Upload
Excel modal — the label and behavior switch automatically based on which
Budget/Estimation/Actual tab is selected.

Fields left blank on an Estimation/Actual entry (single-entry form *or* Excel row) are
automatically **imported from the previous stage's saved values** — you never have to
retype the whole record to change one number.

Bulk Excel upload validates **every row first**, inside a single SQL transaction; if any
row fails, the whole transaction is rolled back and **nothing is saved** — you get the
full list of per-row errors back to fix in Excel and re-upload.

## What's simplified vs. a full enterprise system

This is a self-contained demo schema. Specifically left out (straightforward to add if
you need them):

- Financial Year / Quarter **Open / Frozen / Closed** status gating — the demo FY is
  always open.
- Role-based **Maker/Checker/Controller** permission checks and an approval workflow
  (every submission here is immediately final, there's no "Pending" status).
- **Audit trail** logging.
- Auto-creation of new Project/Company/Industry master rows on the fly — the demo
  stores these as free text directly on the entry rather than normalizing them into
  their own master tables (Product, Issue Type, and Industry Coverage Group *are*
  proper master tables with codes, since Excel/the form reference them by name and the
  API resolves the code server-side).
